pipeline {
    agent { label 'docker' }
    environment {
        app_name = 'matayeled-server'
        docker_repo = 'repo.treescale.com/matadocker'
    }
    options { timestamps() }

    stages {
        stage('Maven Build') {
            agent {
                docker {
                    image 'maven:3-alpine'
                    args '-v $HOME/.m2:/root/.m2'
                }
            }
            steps {
                sh 'mvn -V -B -U -e clean install -DskipTests'
            }
        }
        stage('Build Docker image') {
            agent { label 'docker' }
            steps {
                script {
                    pom = readMavenPom file: 'pom.xml'
                    jar_file = 'target/' + pom.name + '-' + pom.version + '.jar'
                    docker.withRegistry("https://${docker_repo}", "docker-repo-credentials") {
                        def dockerImage = docker.build("${docker_repo}/${app_name}:${BUILD_NUMBER}", "--build-arg JAR_PATH=${jar_file} .")
                        dockerImage.push()
                        dockerImage.push('latest')
                    }
                }
            }
        }
        stage ('Start deploy_test job') {
            steps {
                build job: 'deploy_test', propagate: false, wait: false
            }
        }
    }
    post {
        always {
            cleanWs()
            script {
                sh "docker rmi ${docker_repo}/${app_name}:${BUILD_NUMBER}"
                sh "docker rmi ${docker_repo}/${app_name}:latest"
            }
        }
        success {
            echo "Success"
        }
        failure {
            echo "Failure"
        }
    }
}