package com.sofuit.matayeled.group;

import com.sofuit.matayeled.MatayeledServerApplication;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import static junit.framework.TestCase.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by osher on 9/4/16.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = MatayeledServerApplication.class)
@WebAppConfiguration
public class GroupServiceTest {

    private static final Logger classLogger = LoggerFactory.getLogger(GroupServiceTest.class);

    @Autowired
    @InjectMocks
    GroupService mockGroupService;

    @Mock
    GroupRepo mockGroupRepo;

    @Autowired
    GroupRepo realGroupRepo;

    @Before
    public void before() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    @Ignore
    public void creatingAGroup() {
        //Tournament tournament = Tournament.builder().id("testTour1").name("UEFA").build();
        //User user = User.builder().id("testUSer1").email("test@test.com").firstName("popo").lastName("man").
        /*Group group1 = new Group();
        group1.setName("testGroup1");

        group1 = mockGroupService.createGroup(group1);
        assertNotNull(group1.getId());

        // Delete the group we created
        realGroupRepo.delete(group1);
        classLogger.debug("Deleted the group the test created.");*/
    }

    @Ignore
    @Test(expected = IllegalArgumentException.class)
    public void creatingAGroupWithExistingGroupId() {
        /*Group group1 = new Group();
        group1.setId("testGroup1");
        group1.setName("testGroup1");

        when(mockGroupRepo.save(group1)).thenReturn(group1);
        mockGroupService.createGroup(group1);*/
    }
}
