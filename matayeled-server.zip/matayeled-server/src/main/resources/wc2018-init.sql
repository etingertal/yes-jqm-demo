# Remove all the invitations except the general one
DELETE FROM `invitation` WHERE `assigned_group_id` IS NOT NULL;

# Delete user's scorer and team bets
UPDATE `user` SET `top_scorer_id`=NULL;
UPDATE `user` SET `winning_team_id`=NULL;

UPDATE `tournament` SET `name`='מונדיאל 2018';

# Remove all the specific-tournament data
TRUNCATE `ad`;
TRUNCATE `bet`;
DELETE FROM `scorer`;
DELETE FROM `game`;
DELETE FROM `team`;

# Change groups promotion level and all of them from tournament start
UPDATE `user_group` SET `points_calc_from_tournament_start`=1;
UPDATE `user_group` SET `promotion_level`=0;

# Init user score reduces
UPDATE `user_group_stats` SET `bullseye_reduce`=0;
UPDATE `user_group_stats` SET `game_reduce`=0;
UPDATE `user_group_stats` SET `hits_reduce`=0;
UPDATE `user_group_stats` SET `score_reduce`=0;

# Init user scores
UPDATE `user_score` SET `missed_games`=0;
UPDATE `user_score` SET `total_bulls_eye`=0;
UPDATE `user_score` SET `total_hits`=0;
UPDATE `user_score` SET `total_score`=0;

### Specific World Cup 2018

## Teams
INSERT INTO `team` (`id`, `name`, `pic`,`points`)
VALUES
  ('team1','רוסיה','011_Russia.png',6),
  ('team10','אנגליה','007_England.png',6),
  ('team11','ספרד','003_Spain.png',4),
  ('team12','ניגריה','022_Nigeria.png',10),
  ('team13','קוסטה ריקה','027_CostaRica.png',15),
  ('team14','פולין','013_Poland.png',8),
  ('team15','מצרים','023_Egypt.png',10),
  ('team16','סרביה','017_Serbia.png',8),
  ('team17','איסלנד','021_Island.png',10),
  ('team18','צרפת','004_France.png',4),
  ('team19','פורטוגל','008_Portugal.png',6),
  ('team2','ברזיל','001_Brazil.png',4),
  ('team20','אורגוואי','009_Orugwai.png',6),
  ('team21','ארגנטינה','005_Argentina.png',4),
  ('team22','קולומביה','012_Colombia.png',6),
  ('team23','פנמה','031_Panama.png',15),
  ('team24','סנגל','020_Senegal.png',10),
  ('team25','תוניסיה','029_Tunisya.png',15),
  ('team26','מרוקו','025_Marroco.png',10),
  ('team27','שוויץ','014_Swiss.png',8),
  ('team28','קרואטיה','010_Crotia.png',6),
  ('team29','שוודיה','018_Swiden.png',8),
  ('team3','איראן','028_Iran.png',15),
  ('team30','דנמרק','016_Denemark.png',8),
  ('team31','אוסטרליה','026_Ausrelia.png',10),
  ('team32','פרו','019_Peru.png',10),
  ('team4','יפן','024_Japan.png',10),
  ('team5','מקסיקו','015_Mexico.png',8),
  ('team6','בלגיה','006_Belgium.png',6),
  ('team7','קוריאה הדרומית','030_South_Korea.png',15),
  ('team8','ערב הסעודית','032_Saudia_Arabia.png',15),
  ('team9','גרמניה','002_Germany.png',4);

## Scorers
INSERT INTO `scorer` (`id`, `is_top_scorer`, `name`, `pic_url`, `team`, `points`)
VALUES
  ('scorer01', 0, 'מסי','t1.png', 'ארגנטינה', 4),
  ('scorer02', 0, 'אנטואן גריזמן','t2.png', 'צרפת', 4),
  ('scorer03', 0, 'ניימאר','t3.png', 'ברזיל', 4),
  ('scorer04', 0, 'כריסטיאנו רונאלדו','t4.png', 'פורטוגל', 4),
  ('scorer05', 0, 'הארי קיין','t5.png', 'אנגליה', 4),
  ('scorer06', 0, 'גבריאל ז''סוס','t6.png', 'ברזיל', 6),
  ('scorer07', 0, 'רומלו לוקאקו','t7.png', 'בלגיה', 6),
  ('scorer08', 0, 'טימו ורנר','t8.png', 'גרמניה', 6),
  ('scorer09', 0, 'אלברו מוראטה','t9.png', 'ספרד', 6),
  ('scorer10', 0, 'סרחיו אגוארו','t10.png', 'ארגנטינה', 6),
  ('scorer11', 0, 'מוחמד סלאח','t11.png', 'מצרים', 6),
  ('scorer12', 0, 'אדינסון קבאני','t12.png', 'אורגוואי', 8),
  ('scorer13', 0, 'תומאס מילר','t13.png', 'גרמניה', 8),
  ('scorer14', 0, 'לואיס אלברטו סוארס','t14.png', 'אורגוואי', 8),
  ('scorer15', 0, 'רוברט לבנדובסקי','t15.png', 'פולין', 8),
  ('scorer16', 0, 'דייגו קוסטה','t16.png', 'ספרד', 8),
  ('scorer17', 0, 'רדאמל פלקאו','t17.png', 'קולומביה', 8),
  ('scorer18', 0, 'קיליאן מבאפה','t18.png', 'צרפת', 8),
  ('scorer19', 0, 'אוליבייה ז''ירו','t19.png', 'צרפת', 10),
  ('scorer20', 0, 'גונסאלו היגוואין','t20.png', 'ארגנטינה', 10),
  ('scorer21', 0, 'אלכסנדר לקאזט','t21.png', 'צרפת', 10),
  ('scorer22', 0, 'דריס מרטנס','t22.png', 'בלגיה', 10),
  ('scorer23', 0, 'לירוי סאנה','t23.png', 'גרמניה', 10),
  ('scorer24', 0, 'סנדרו וגנר','t24.png', 'גרמניה', 10),
  ('scorer25', 0, 'אדן הזאר','t25.png', 'בלגיה', 10),
  ('scorer26', 0, 'אנדרה סילבה','t26.png', 'פורטוגל', 10),
  ('scorer27', 0, 'פיליפה קוטיניו','t27.png', 'ברזיל', 12),
  ('scorer28', 0, 'עוסמאן דמבלה','t28.png', 'צרפת', 12),
  ('scorer29', 0, 'פאולו דיבאלה','t29.png', 'ארגנטינה', 12),
  ('scorer30', 0, 'פרנסיסקו איסקו','t30.png', 'ספרד', 12),
  ('scorer31', 0, 'חאמס רודריגס','t31.png', 'קולומביה', 12),
  ('scorer32', 0, 'דריו בנדטו','t32.png', 'ארגנטינה', 12),
  ('scorer33', 0, 'רוברטו פירמינו','t33.png', 'ברזיל', 12),
  ('scorer34', 0, 'מאורו איקרדי','t34.png', 'ארגנטינה', 12),
  ('scorer35', 0, 'ג''יימי ורדי','t35.png', 'אנגליה', 12),
  ('scorer36', 0, 'אף אחד','t36.png', 'ברזיל', 2);

## Games
# Group Stage
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game1', '2018-06-14 18:00:00', 'team1', 'team8', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game2', '2018-06-15 15:00:00', 'team15', 'team20', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game3', '2018-06-15 18:00:00', 'team26', 'team3', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game4', '2018-06-15 21:00:00', 'team19', 'team11', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game5', '2018-06-16 13:00:00', 'team18', 'team31', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game6', '2018-06-16 16:00:00', 'team21', 'team17', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game7', '2018-06-16 19:00:00', 'team32', 'team30', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game8', '2018-06-16 22:00:00', 'team28', 'team12', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game9', '2018-06-17 15:00:00', 'team13', 'team16', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game10', '2018-06-17 18:00:00', 'team9', 'team5', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game11', '2018-06-17 21:00:00', 'team2', 'team27', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game12', '2018-06-18 15:00:00', 'team29', 'team7', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game13', '2018-06-18 18:00:00', 'team6', 'team23', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game14', '2018-06-18 21:00:00', 'team25', 'team10', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game15', '2018-06-19 15:00:00', 'team22', 'team4', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game16', '2018-06-19 18:00:00', 'team14', 'team24', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game17', '2018-06-19 21:00:00', 'team1', 'team15', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game18', '2018-06-20 15:00:00', 'team19', 'team26', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game19', '2018-06-20 18:00:00', 'team20', 'team8', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game20', '2018-06-20 21:00:00', 'team3', 'team11', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game21', '2018-06-21 15:00:00', 'team30', 'team31', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game22', '2018-06-21 18:00:00', 'team18', 'team32', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game23', '2018-06-21 21:00:00', 'team21', 'team28', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game24', '2018-06-22 15:00:00', 'team2', 'team13', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game25', '2018-06-22 18:00:00', 'team12', 'team17', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game26', '2018-06-22 21:00:00', 'team16', 'team27', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game27', '2018-06-23 15:00:00', 'team25', 'team6', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game28', '2018-06-23 18:00:00', 'team5', 'team7', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game29', '2018-06-23 21:00:00', 'team9', 'team29', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game30', '2018-06-24 15:00:00', 'team10', 'team23', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game31', '2018-06-24 18:00:00', 'team4', 'team24', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game32', '2018-06-24 21:00:00', 'team14', 'team22', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game33', '2018-06-25 17:00:00', 'team20', 'team1', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game34', '2018-06-25 17:00:00', 'team8', 'team15', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game35', '2018-06-25 21:00:00', 'team3', 'team19', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game36', '2018-06-25 21:00:00', 'team11', 'team26', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game37', '2018-06-26 17:00:00', 'team18', 'team30', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game38', '2018-06-26 17:00:00', 'team31', 'team32', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game39', '2018-06-26 21:00:00', 'team21', 'team12', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game40', '2018-06-26 21:00:00', 'team17', 'team28', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game41', '2018-06-27 17:00:00', 'team7', 'team9', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game42', '2018-06-27 17:00:00', 'team5', 'team29', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game43', '2018-06-27 21:00:00', 'team2', 'team16', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game44', '2018-06-27 21:00:00', 'team13', 'team27', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game45', '2018-06-28 17:00:00', 'team4', 'team14', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game46', '2018-06-28 17:00:00', 'team24', 'team22', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game47', '2018-06-28 21:00:00', 'team6', 'team10', 'שלב הבתים');
INSERT INTO `game` (id, start_time, team1_id, team2_id, stage_name) VALUES ('game48', '2018-06-28 21:00:00', 'team23', 'team25', 'שלב הבתים');

UPDATE `game` SET `hit_score`=1;
UPDATE `game` SET `bullseye_score`=3;

# Knockout Stage
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game49', '2018-06-30 17:00:00', 'שמינית גמר', 2, 4);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game50', '2018-06-30 21:00:00', 'שמינית גמר', 2, 4);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game51', '2018-07-01 17:00:00', 'שמינית גמר', 2, 4);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game52', '2018-07-01 21:00:00', 'שמינית גמר', 2, 4);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game53', '2018-07-02 17:00:00', 'שמינית גמר', 2, 4);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game54', '2018-07-02 21:00:00', 'שמינית גמר', 2, 4);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game55', '2018-07-03 17:00:00', 'שמינית גמר', 2, 4);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game56', '2018-07-03 21:00:00', 'שמינית גמר', 2, 4);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game57', '2018-07-06 17:00:00', 'רבע גמר', 3, 6);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game58', '2018-07-06 21:00:00', 'רבע גמר', 3, 6);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game59', '2018-07-07 17:00:00', 'רבע גמר', 3, 6);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game60', '2018-07-07 21:00:00', 'רבע גמר', 3, 6);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game61', '2018-07-10 21:00:00', 'חצי גמר', 4, 8);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game62', '2018-07-11 21:00:00', 'חצי גמר', 4, 8);
INSERT INTO `game` (id, start_time, stage_name, hit_score, bullseye_score) VALUES ('game63', '2018-07-15 18:00:00', 'גמר', 5, 10);

UPDATE `game` SET `tournament_id`='tournament1';
UPDATE `game` SET `is_locking`=0;
UPDATE `game` SET `is_finished`=0;
UPDATE `game` SET `is_bets_calculated`=0;
UPDATE `game` SET `is_locking`=1 WHERE id='game10';