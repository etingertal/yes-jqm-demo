package com.sofuit.matayeled.shtutController;

import com.sofuit.matayeled.bet.Bet;
import com.sofuit.matayeled.bet.BetClient;
import com.sofuit.matayeled.bet.BetRepo;
import com.sofuit.matayeled.bet.BetService;
import com.sofuit.matayeled.config.IdentityService;
import com.sofuit.matayeled.exceptions.ForbiddenException;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.game.Game;
import com.sofuit.matayeled.game.GameClient;
import com.sofuit.matayeled.game.GameRepo;
import com.sofuit.matayeled.game.GameService;
import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.group.GroupClient;
import com.sofuit.matayeled.group.GroupRepo;
import com.sofuit.matayeled.group.GroupService;
import com.sofuit.matayeled.score.ScoreCalculation;
import com.sofuit.matayeled.stat.UserGroupStatsClient;
import com.sofuit.matayeled.stat.UserGroupStatsRepo;
import com.sofuit.matayeled.stat.UserGroupStatsService;
import com.sofuit.matayeled.team.TeamRepo;
import com.sofuit.matayeled.tournament.TournamentRepo;
import com.sofuit.matayeled.user.*;
import com.sofuit.matayeled.utilities.Const;
import org.mindrot.jbcrypt.BCrypt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * Created by osher on 10/6/16.
 */
//@Profile({ "osher-dev", "tal-dev" })
@RestController
@RequestMapping("/api/shtut")
public class shtutController {

    private static final Logger classLogger = LoggerFactory.getLogger(shtutController.class);

    @Autowired
    ScoreCalculation scoreCalculation;

    @Autowired
    UserRepo userRepo;

    @Autowired
    UserService userService;

    @Autowired
    BetRepo betRepo;

    @Autowired
    BetService betService;

    @Autowired
    GameRepo gameRepo;

    @Autowired
    GroupRepo groupRepo;

    @Autowired
    TeamRepo teamRepo;

    @Autowired
    TournamentRepo tournamentRepo;

    @Autowired
    GameService gameService;

    @Autowired
    GroupService groupService;

    @Autowired
    UserGroupStatsService userGroupStatsService;

    @Autowired
    UserGroupStatsRepo userGroupStatsRepo;

    @Autowired
    UserScoreService userScoreService;

    @Autowired
    UserScoreRepo userScoreRepo;

    private String game1Id = "";
    private String game2Id = "";
    private String game3Id = "";
    private String game4Id = "";

    // Get teams
    /*@RequestMapping(value = "/do1", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> do1() throws ResourceNotFoundException, ForbiddenException{

        adminOrThrow();

        // Delete stuff
        try {
            //userRepo.delete(userService.findByEmail("oshernet@gmail.com"));
        } catch (Exception e) {

        }
        // Create games
        Game game1 = new Game();
        game1.setBullseyeScore(3);
        game1.setHitScore(1);
        game1.setIsFinished(false);
        game1.setIsLocking(false);
        game1.setTeam1(teamRepo.findOne("team1"));
        game1.setTeam2(teamRepo.findOne("team2"));
        game1.setTournament(tournamentRepo.findOne("tournament1"));
        game1.setStageName("tfu");
        Timestamp game1ts = Timestamp.valueOf(LocalDateTime.now().minus(1, ChronoUnit.DAYS));
        game1.setStartTime(game1ts);
        game1 = gameRepo.save(game1);
        game1Id = game1.getId();

        Game game2 = new Game();
        game2.setBullseyeScore(3);
        game2.setHitScore(1);
        game2.setIsFinished(false);
        game2.setIsLocking(false);
        game2.setTeam1(teamRepo.findOne("team3"));
        game2.setTeam2(teamRepo.findOne("team4"));
        game2.setTournament(tournamentRepo.findOne("tournament1"));
        game2.setStageName("tfu");
        Timestamp game2ts = Timestamp.valueOf(LocalDateTime.now().minus(1, ChronoUnit.DAYS));
        game2.setStartTime(game2ts);
        game2 = gameRepo.save(game2);
        game2Id = game2.getId();

        Game game3 = new Game();
        game3.setBullseyeScore(3);
        game3.setHitScore(1);
        game3.setIsFinished(false);
        game3.setIsLocking(false);
        game3.setTeam1(teamRepo.findOne("team4"));
        game3.setTeam2(teamRepo.findOne("team5"));
        game3.setTournament(tournamentRepo.findOne("tournament1"));
        game3.setStageName("tfu");
        Timestamp game3ts = Timestamp.valueOf(LocalDateTime.now().plus(1, ChronoUnit.DAYS));
        game3.setStartTime(game3ts);
        game3 = gameRepo.save(game3);
        game3Id = game3.getId();

        Game game4 = new Game();
        game4.setBullseyeScore(6);
        game4.setHitScore(3);
        game4.setIsFinished(false);
        game4.setIsLocking(false);
        game4.setTeam1(teamRepo.findOne("team6"));
        game4.setTeam2(teamRepo.findOne("team7"));
        game4.setTournament(tournamentRepo.findOne("tournament1"));
        game4.setStageName("tfu2");
        Timestamp game4ts = Timestamp.valueOf(LocalDateTime.now().plus(2, ChronoUnit.DAYS));
        game4.setStartTime(game4ts);
        game4 = gameRepo.save(game4);
        game4Id = game4.getId();

        Timestamp userts = Timestamp.valueOf(LocalDateTime.now().minus(2, ChronoUnit.DAYS));

        // Create users (first name is bets ltr)
        User user1 = new User();
        user1.setEmail("oshernet@gmail.com");
        user1.setFirstName("31-11-21"); // bull hit none
        user1.setLastName("last");
        user1.setPassword(BCrypt.hashpw("123456", BCrypt.gensalt()));
        user1.setRegistrationDate(userts);

        //user1.setMissedGames(0);

        user1 = userRepo.save(user1);

        User user2 = new User();
        user2.setEmail("oshera@gmail.com");
        user2.setFirstName("21-22-01"); // hit hit hit
        user2.setLastName("last");
        user2.setPassword(BCrypt.hashpw("123456", BCrypt.gensalt()));
        user2.setRegistrationDate(userts);

        // user2.setMissedGames(0);

        user2 = userRepo.save(user2);

        User user3 = new User();
        user3.setEmail("titaniumz@gmail.com");
        user3.setFirstName("11-33-10"); // none bull none
        user3.setLastName("last");
        user3.setPassword(BCrypt.hashpw("123456", BCrypt.gensalt()));
        user3.setRegistrationDate(userts);

        //user3.setMissedGames(0);
        user3 = userRepo.save(user3);

        // Create bets
        // user1 31-11-21
        BetClient user1bc1 = new BetClient();
        user1bc1.setIsGenerated(false);
        user1bc1.setTeam1Score(3);
        user1bc1.setTeam2Score(1);
        user1bc1 = betService.updateBet(user1bc1, game1, user1);

        BetClient user1bc2 = new BetClient();
        user1bc2.setIsGenerated(false);
        user1bc2.setTeam1Score(1);
        user1bc2.setTeam2Score(1);
        user1bc2 = betService.updateBet(user1bc2, game2, user1);

        BetClient user1bc3 = new BetClient();
        user1bc3.setIsGenerated(false);
        user1bc3.setTeam1Score(2);
        user1bc3.setTeam2Score(1);
        user1bc3 = betService.updateBet(user1bc3, game3, user1);

        // user2 21-22-01
        BetClient user2bc1 = new BetClient();
        user2bc1.setIsGenerated(false);
        user2bc1.setTeam1Score(2);
        user2bc1.setTeam2Score(1);
        user2bc1 = betService.updateBet(user2bc1, game1, user2);

        BetClient user2bc2 = new BetClient();
        user2bc2.setIsGenerated(false);
        user2bc2.setTeam1Score(2);
        user2bc2.setTeam2Score(2);
        user2bc2 = betService.updateBet(user2bc2, game2, user2);

        BetClient user2bc3 = new BetClient();
        user2bc3.setIsGenerated(false);
        user2bc3.setTeam1Score(0);
        user2bc3.setTeam2Score(1);
        user2bc3 = betService.updateBet(user2bc3, game3, user2);

        // user3 11-33-10
        BetClient user3bc1 = new BetClient();
        user3bc1.setIsGenerated(false);
        user3bc1.setTeam1Score(1);
        user3bc1.setTeam2Score(1);
        user3bc1 = betService.updateBet(user3bc1, game1, user3);

        BetClient user3bc2 = new BetClient();
        user3bc2.setIsGenerated(false);
        user3bc2.setTeam1Score(3);
        user3bc2.setTeam2Score(3);
        user3bc2 = betService.updateBet(user3bc2, game2, user3);

        BetClient user3bc3 = new BetClient();
        user3bc3.setIsGenerated(false);
        user3bc3.setTeam1Score(1);
        user3bc3.setTeam2Score(0);
        user3bc3 = betService.updateBet(user3bc3, game3, user3);

        // Create group
        GroupClient gc1 = new GroupClient();
        gc1.setBetTopScorer(true);
        gc1.setBetWinningTeam(true);
        gc1.setManagerId(null);
        gc1.setCreatorId(user1.getId());
        gc1.setLeaderId(user1.getId());
        gc1.setLeaderStatus("popo");
        gc1.setManagerName(user1.getFullName());
        gc1.setName("Group1");
        gc1.setPrivacy(Const.GroupPrivacy.VIEWABLE);
        gc1.setPointsCalcFromTournamentStart(true);

        gc1 = groupService.createGroup(gc1, user1.getId());
        groupService.addUsersToGroup(gc1.getId(), new String[]{user1.getId()});
        groupService.addUsersToGroup(gc1.getId(), new String[]{user2.getId()});
        groupService.addUsersToGroup(gc1.getId(), new String[]{user3.getId()});

        // Update 1 game partial
        List<GameClient> gameList = new ArrayList<>();
        GameClient gameClient1 = new GameClient(game1);
        gameClient1.setTeam1Score(2);
        gameClient1.setTeam2Score(1);

        GameClient gameClient2 = new GameClient(game2);
        gameClient2.setTeam1Score(3);
        gameClient2.setTeam2Score(3);

        gameList.add(gameClient1);
        gameList.add(gameClient2);
        //scoreCalculation.updateAndCalc(gameList);

        return new ResponseEntity<Void>(HttpStatus.OK);
    }*/

    // Get teams
    /*@RequestMapping(value = "/do2", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> do2() throws ResourceNotFoundException, ForbiddenException {

        adminOrThrow();

        Game game1 = gameService.findById(game1Id);

        // Update 1 game partial
        List<GameClient> gameList = new ArrayList<>();
        GameClient gameClient1 = new GameClient(game1);
        gameClient1.setTeam1Score(3);
        gameClient1.setTeam2Score(1);
        gameClient1.setIsFinished(true);

        gameList.add(gameClient1);
        //scoreCalculation.updateAndCalc(gameList);

        return new ResponseEntity<Void>(HttpStatus.OK);
    }*/

    // Get teams
    /*@RequestMapping(value = "/do3", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> do3() throws ResourceNotFoundException, ForbiddenException {

        adminOrThrow();

        Game game2 = gameService.findById(game2Id);

        // Update 1 game partial
        List<GameClient> gameList = new ArrayList<>();

        GameClient gameClient2 = new GameClient(game2);
        gameClient2.setTeam1Score(3);
        gameClient2.setTeam2Score(3);
        gameClient2.setIsFinished(true);
        gameList.add(gameClient2);
        //scoreCalculation.updateAndCalc(gameList);

        return new ResponseEntity<Void>(HttpStatus.OK);
    }*/

    // set game is finished to 1, state to 1, make sure score is correct.
//    @RequestMapping(value = "/calcGame27", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<Void> calcGame27() throws ResourceNotFoundException, ForbiddenException {
//
//        adminOrThrow();
//
//        calculateGameScore(Arrays.asList("game27"));
//
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }

    // Run after user calc
    @RequestMapping(value = "/recalcGroupLeaders", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> recalcGroupLeaders() throws ResourceNotFoundException, ForbiddenException {

        adminOrThrow();

        classLogger.info("Starting Leader calculation!");
        int popo=0;

        try {
            // Get group(if it does not exist we will fly)
            Iterator<Group> groups = groupRepo.findAll().iterator();

            while (groups.hasNext()) {
                Group group = groups.next();

                Pageable pageable = new PageRequest(0, 1);
                List<UserGroupStatsClient> stat = userGroupStatsService.getOrderedGroupStats(group.getId(), pageable, false);

                if ((stat != null) && (stat.size() > 0)) {
                    User user = userService.findById(stat.get(0).getUserId());
                    group.setLeader(user);
                    groupRepo.save(group);
                    classLogger.info("Done with gruop: {}",++popo);
                }
            }
        } catch (Exception e) {
            classLogger.error("Error while calcing group leaders:", e);
            throw e;
        }

        classLogger.info("Finished Leader calculation!");

        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    /*private void calculateGameScore(List<String> gameids)
            throws ResourceNotFoundException {

        // Enable calc more than 1 game
        List<Game> games = new ArrayList<>();
        for (String gameid : gameids) {
            classLogger.info("Start user score calculation for game: {}", gameid);
            Game myGame = gameService.findById(gameid);
            games.add(myGame);
        }

        try {
            int popo = 0;
            // Get all users
            Iterator<User> iterator = userRepo.findAll().iterator();

            while (iterator.hasNext()) {
                User currUser = iterator.next();

                // Aggregators for current user
                Integer scoreKeeper = 0;
                Integer hitsCounter = 0;
                Integer bullseyeCounter = 0;

                for (Game game : games) {

                    Optional<Bet> optBet = betService.findByUserAndGame(currUser, game);
                    Bet gameBet;
                    if (optBet.isPresent()) {
                        gameBet = optBet.get();

                        if (gameBet.getScore() == 0) {
                            if (gameBet.getTeam1Score() == game.getTeam1Score() &&
                                    gameBet.getTeam2Score() == game.getTeam2Score()) {

                                // Bullseye
                                gameBet.setScore(game.getBullseyeScore());
                                gameBet.setIsBullsEye(true);
                                scoreKeeper += game.getBullseyeScore();
                                bullseyeCounter++;
                                hitsCounter++;
                            } else if (((gameBet.getTeam1Score() - gameBet.getTeam2Score()) == 0 &&
                                    (game.getTeam1Score() - game.getTeam2Score()) == 0)
                                    || (((gameBet.getTeam1Score() - gameBet.getTeam2Score()) != 0 &&
                                    (game.getTeam1Score() - game.getTeam2Score()) != 0) &&
                                    ((gameBet.getTeam1Score() - gameBet.getTeam2Score()) < 0 ==
                                            ((game.getTeam1Score() - game.getTeam2Score()) < 0)))) {
                                // Hit
                                gameBet.setScore(game.getHitScore());
                                scoreKeeper += game.getHitScore();
                                hitsCounter++;
                            }

                            betService.save(gameBet);
                        }
                    }
                }

                // Update user score
                //currUser.setTotalBullsEye(currUser.getTotalBullsEye() + bullseyeCounter);
                //currUser.setTotalScore(currUser.getTotalScore() + scoreKeeper);
                //currUser.setTotalHits(currUser.getTotalHits() + hitsCounter);
                userRepo.save(currUser);

                classLogger.info("Finished user: {}",++popo);
            }
        } catch(Exception e) {
            classLogger.error("Error in score calc!", e);
            throw e;
        }

        classLogger.info("Finished user score calculation.");
    }*/

    // Zero all reduces
    /*@RequestMapping(value = "/recalcAllReduce", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> recalcAllReduce() throws ResourceNotFoundException, ForbiddenException {

        adminOrThrow();

        classLogger.info("Reduce calculation started");

        //List<Group> groups = groupRepo.findByPointsCalcFromTournamentStart(false);
        List<Group> groups = new ArrayList<>();
        int popo=0;
        for (Group group : groups) {

            List<UserGroupStats> userGroupStatsList = group.getUsersStats();

            for (UserGroupStats userGroupStats : userGroupStatsList) {
                List<Bet> irrelevantBetsForUser = betService.getBetsByUserAndGameStartTimeLessThanEqual(
                        userGroupStats.getUser(),
                        userGroupStats.getGroup().getOpenDate());

                if (irrelevantBetsForUser != null && irrelevantBetsForUser.size() > 0) {

                    int gameReduce = 0;
                    int scoreReduce = 0;
                    int hitsReduce = 0;
                    int bullsEyeReduce = 0;

                    for (Bet currBet : irrelevantBetsForUser) {
                        gameReduce += 1;
                        if (currBet.getScore() != 0) {
                            scoreReduce += currBet.getScore();
                            hitsReduce += 1;
                            if (currBet.getIsBullsEye()) {
                                bullsEyeReduce += 1;
                            }
                        }
                    }

                    userGroupStats.setGameReduce(gameReduce);
                    userGroupStats.setScoreReduce(scoreReduce);
                    userGroupStats.setHitsReduce(hitsReduce);
                    userGroupStats.setBullseyeReduce(bullsEyeReduce);
                    userGroupStatsRepo.save(userGroupStats);

                    classLogger.info("done with: {}", ++popo);
                }
            }
        }

        classLogger.info("Reduce calculation finished");

        return new ResponseEntity<Void>(HttpStatus.OK);
    }*/

    @RequestMapping(value = "/bets/init", method = RequestMethod.POST)
    public ResponseEntity<String> initBetsForUser(@RequestBody List<String> userIds)
            throws ResourceNotFoundException, ForbiddenException {

        adminOrThrow();

        // Get all users
        int userCount = 1;

        List<Game> nextGames = gameService.getNextGames();

        for (String userId : userIds) {
            User user = userService.findById(userId);

            if (user.getConfirmationId() == null) {
                classLogger.info("Start Generate Bets for user: {}", user.getId());
                Random rand = new Random();

                for (Game nextGame : nextGames) {
                    Optional<Bet> bet = betService.findByUserAndGame(user, nextGame);

                    if (!bet.isPresent()) {
                        Bet currBet = new Bet();
                        currBet.setId(null);
                        currBet.setUser(user);
                        currBet.setGame(nextGame);
                        currBet.setTeam1Score(rand.nextInt(5));
                        currBet.setTeam2Score(rand.nextInt(5));
                        currBet.setIsGenerated(Boolean.TRUE);
                        betRepo.save(currBet);
                    }
                }

                classLogger.info("Finished Generate Bets for user: {}", user.getId());
                classLogger.info("Generate Bets Current user number: {}", userCount++);
            }
        }

        return new ResponseEntity<>("ok", HttpStatus.OK);
    }

    private void adminOrThrow() throws ResourceNotFoundException, ForbiddenException{

        User user = userService.findById(IdentityService.getUser());

        // Only admins allowed
        if (!(user.getRole() != null && user.getRole().equals(Const.ROLE_ADMIN))) {
            throw new ForbiddenException("Nono");
        }


    }
}
