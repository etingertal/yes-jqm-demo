package com.sofuit.matayeled.ad;

import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by etingertal on 6/17/16.
 */
@Service
public class AdService {

    private static final Logger classLogger = LoggerFactory.getLogger(AdService.class);

    @Autowired
    AdRepo adRepo;

    public Ad findById(String id) throws ResourceNotFoundException {
        return adRepo.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("ad with id:" + id));
    }

    public List<Ad> findByTypeAndIsActive(String type, Boolean isActive) {
        return adRepo.findByTypeAndIsActive(type, isActive);
    }

    public void addOneClick(Ad ad) {
        ad.setClicks(ad.getClicks() + 1);
        adRepo.save(ad);
    }

    public void addOneImpression(Ad ad) {
        ad.setImpressions(ad.getImpressions() + 1);
        adRepo.save(ad);
    }

    @Async
    public void addOneImpressionList(List<Ad> ads) {
        for (Ad ad : ads) {
            ad.setImpressions(ad.getImpressions() + 1);
            adRepo.save(ad);
        }
    }
}
