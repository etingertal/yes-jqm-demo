package com.sofuit.matayeled.benefit;

import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BenefitService {

    private static final Logger classLogger = LoggerFactory.getLogger(BenefitService.class);

    @Autowired
    BenefitRepo benefitRepo;

    public Benefit findById(String id) throws ResourceNotFoundException {
        return benefitRepo.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("benefit with id:" + id));
    }

    public List<Benefit> findAll() {
        List<Benefit> list = new ArrayList<>();
        benefitRepo.findAll().iterator().forEachRemaining(list::add);
        return list;
    }

    public void addOneClick(Benefit benefit) {
        benefit.setClicks(benefit.getClicks() + 1);
        benefitRepo.save(benefit);
    }
}
