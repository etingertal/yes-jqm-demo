package com.sofuit.matayeled.game;

import com.sofuit.matayeled.bet.BetService;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.group.GroupService;
import com.sofuit.matayeled.stat.UserGroupStatsRepo;
import com.sofuit.matayeled.statistics.GameStatsService;
import com.sofuit.matayeled.user.User;
import com.sofuit.matayeled.user.UserRepo;
import com.sofuit.matayeled.user.UserService;
import com.sofuit.matayeled.utilities.Const;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.*;

/**
 * Created by etingertal on 4/11/16.
 */
@Service
public class GameService {

    private static final Logger classLogger = LoggerFactory.getLogger(GameService.class);

    @Autowired
    GameRepo gameRepo;

    @Autowired
    UserRepo userRepo;

    @Autowired
    BetService betService;

    @Autowired
    UserGroupStatsRepo userGroupStatsRepo;

    @Autowired
    UserService userService;

    @Autowired
    GroupService groupService;

    @Autowired
    GameStatsService gameStatsService;

    public Game findById(String gameId) throws ResourceNotFoundException {
        return gameRepo.findById(gameId).orElseThrow(() -> new ResourceNotFoundException("game id:" + gameId));
    }

    public List<Game> getNextGames() {
        return gameRepo.findByStartTimeGreaterThanEqualOrderByStartTimeAsc(new Timestamp(new Date().getTime()));
    }

    public Game getLastGame() {
        return gameRepo.findTopByGameCalcStatusOrderByStartTimeDesc(Const.GameCalcStatus.CALCULATION_FINISHED);
    }

    public List<Game> getGamesHistory() {
        return gameRepo.findByStartTimeLessThanEqualOrderByStartTimeAsc(new Timestamp(new Date().getTime()));
    }

    public List<Game> getGamesHistoryByGroupOpenDate(Timestamp openDate) {
        return gameRepo.findByStartTimeLessThanEqualAndStartTimeGreaterThanEqualOrderByStartTimeAsc(new Timestamp(new Date().getTime()), openDate);
    }

    public Page<Game> getGamesHistoryReversePageable(Pageable page) {
        return gameRepo.findByStartTimeLessThanEqualOrderByStartTimeDesc(new Timestamp(new Date().getTime()), page);
    }

    public Integer getHistoryGamesCount() {
        return gameRepo.countByStartTimeLessThanEqual(new Timestamp((new Date().getTime())));
    }

    public Integer getCalculatedGamesCount() {
        return gameRepo.countByGameCalcStatus(Const.GameCalcStatus.CALCULATION_FINISHED);
    }

    public Game getUserFirstLockingGame(User user) {
        return gameRepo.findTopByStartTimeGreaterThanEqualOrderByStartTimeAsc(user.getRegistrationDate());
    }

    public long getAllGamesCount() {
        return gameRepo.count();
    }

    public List<Game> getAllGames() {
        List<Game> resGames = new ArrayList<>();
        Iterator<Game> games = gameRepo.findAll().iterator();
        games.forEachRemaining(game -> resGames.add(game));
        return resGames;
    }

    public Game getFirstGame() {
        return gameRepo.findTopByOrderByStartTimeAsc();
    }

    public Game getBetsLockingGame(Boolean isLockingGame) {
        return gameRepo.findByIsLocking(isLockingGame);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public void updateGameWithCalculationFinish(List<Game> games) {
        for (Game game : games) {
            game.setGameCalcStatus(Const.GameCalcStatus.CALCULATION_FINISHED);
            gameRepo.save(game);
        }
    }

    public void updateGameWithBetCalculated(Game game) {
        game.setIsBetsCalculated(true);
        gameRepo.save(game);
    }

    public void resetGameCalculationData(Game game) {
        game.setIsBetsCalculated(false);
        game.setIsFinished(false);
        game.setGameCalcStatus(null);
        gameRepo.save(game);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateGamesWithCalcError(List<Game> games) {
        // Set status to error in user calc
        for (Game game : games) {
            game.setGameCalcStatus(Const.GameCalcStatus.CALCULATION_ERROR);
            gameRepo.save(game);
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public List<Game> updateGames(List<GameClient> gameClients) {

        List<Game> finishedGames = new ArrayList<>();
        List<Game> gameToStats = new ArrayList<>();

        for (GameClient gameClient : gameClients) {
            Optional<Game> game = gameRepo.findById(gameClient.getId());

            if (game.isPresent()) {
                Game currGame = game.get();
                if (currGame.getIsFinished()) {
                    classLogger.warn(Const.securityMarker, "Tried to re-update of finished game: {}", currGame.getId());
                } else {
                    currGame.setTeam1Score(gameClient.getTeam1Score());
                    currGame.setTeam2Score(gameClient.getTeam2Score());
                    currGame.setIsFinished(gameClient.getIsFinished());
                    currGame.setGameCalcStatus(Const.GameCalcStatus.CALCULATING); // case it was in error state from prevois update attemp;
                    gameRepo.save(currGame);

                    if (gameClient.getIsFinished()) {
                        finishedGames.add(currGame);
                    }

                    // Check if the update is after the games started
                    if (currGame.getStartTime().before(new Timestamp(new Date().getTime())))
                        gameToStats.add(currGame);
                }
            }
        }

        // Update user game stats (if needed)
        gameStatsService.updateUserGamesStats(gameToStats);

        return finishedGames;
    }

    public Boolean isGameStarted(String gameId) throws ResourceNotFoundException {
        Game game = this.findById(gameId);
        if (game.getStartTime().before(new Timestamp(new Date().getTime()))) {
            return true;
        }

        return false;
    }
}
