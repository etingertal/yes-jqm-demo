package com.sofuit.matayeled.user;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Created by osher on 18/6/16.
 */
@Data
@Entity
public class UserScore {

    @Id
    private String id;

    private Integer totalScore = 0;

    private Integer totalHits = 0;

    private Integer totalBullsEye = 0;

    private Integer missedGames = 0;

}
