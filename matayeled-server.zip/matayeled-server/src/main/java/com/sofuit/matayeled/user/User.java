package com.sofuit.matayeled.user;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.scorer.Scorer;
import com.sofuit.matayeled.team.Team;
import lombok.Data;
import org.hibernate.annotations.*;

import javax.persistence.*;
import javax.persistence.Entity;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created by osher on 7/4/16.
 */
@Data
@DynamicUpdate
@Entity
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class User {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @Column(unique=true)
    private String email;

    private String facebookId;

    private String firstName;

    private String lastName;

    private String fullName;

    private String phone;

    private Timestamp registrationDate;

    @Column
    @Type(type="text")
    private String pic;

    private String password;

    private String role;

    @Column(unique=true)
    private String confirmationId;

    @Column(unique=true)
    private String resetPasswordId;

    private Timestamp lastResetPasswordSent;

    @ManyToOne(fetch= FetchType.LAZY)
    private Scorer topScorer;

    @ManyToOne(fetch=FetchType.LAZY)
    private Team winningTeam;

    private Integer mailsSentCount = 0;

    private Timestamp lastMailSent;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name="UserGroupStats",
            joinColumns=
                @JoinColumn(name="user_id"),
            inverseJoinColumns=
                @JoinColumn(name="group_id")
    )
    private List<Group> groups;
}
