package com.sofuit.matayeled.group;

import com.sofuit.matayeled.user.User;
import com.sofuit.matayeled.utilities.Const;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

/**
 * Created by etingertal on 4/15/16.
 */

/*
    no manager
    no tournament
    no user stats
 */
@NoArgsConstructor
@Data
public class GroupClient {

    private String id;
    private String name;
    private String pic;
    private String leaderId;
    private String leaderPic;
    private String leaderStatus;
    private Const.GroupPrivacy privacy;
    private Boolean pointsCalcFromTournamentStart;
    private Boolean betWinningTeam;
    private Boolean betTopScorer;
    private String managerId;
    private String managerName;
    private String creatorId;
    private Integer userCount;
    private Timestamp openDate;

    public GroupClient(Group group) {
        this.id = group.getId();
        this.name = group.getName();
        this.pic = group.getPic();
        User leader = group.getLeader();
        this.leaderId = leader.getId();
        this.leaderPic = leader.getPic();
        this.leaderStatus = group.getLeaderStatus();
        this.privacy = group.getPrivacy();
        this.pointsCalcFromTournamentStart = group.getPointsCalcFromTournamentStart();
        this.betWinningTeam = group.getBetWinningTeam();
        this.betTopScorer = group.getBetTopScorer();
        User manager = group.getManager();
        this.managerId = manager == null ? null : manager.getId();
        this.managerName = manager == null ? null : manager.getFullName();
        this.creatorId = group.getCreator().getId();
        this.userCount = group.getUsersStats() == null ? 0 : group.getUsersStats().size();
        this.openDate = group.getOpenDate();
    }
}
