package com.sofuit.matayeled.team;

import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

/**
 * Created by etingertal on 5/9/16.
 */
public interface TeamRepo extends CrudRepository<Team, String> {

    Optional<Team> findById(String teamId);
}
