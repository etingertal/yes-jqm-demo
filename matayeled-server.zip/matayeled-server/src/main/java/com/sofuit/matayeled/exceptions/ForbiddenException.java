package com.sofuit.matayeled.exceptions;

/**
 * Created by osher on 10/4/16.
 */
public class ForbiddenException extends Exception {
    public ForbiddenException(String message) {
        super(message);
    }
}
