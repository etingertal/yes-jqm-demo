package com.sofuit.matayeled.invitation;

import com.sofuit.matayeled.group.Group;
import lombok.Data;

/**
 * Created by etingertal on 4/24/16.
 */
@Data
public class InvitationClient {

    private String id;

    private String link;

    private Integer clicksCounter;

    public InvitationClient() {}

    public InvitationClient(Invitation invitation) {
        this.id = invitation.getId();
        this.link = invitation.getLink();
        this.clicksCounter = invitation.getClicksCounter();
    }

    public Invitation convertToInvitation(Group group) {
        Invitation invitation = new Invitation();
        invitation.setId(this.getId());
        invitation.setClicksCounter(this.getClicksCounter());
        invitation.setLink(this.getLink());
        invitation.setAssignedGroup(group);
        return invitation;
    }
}
