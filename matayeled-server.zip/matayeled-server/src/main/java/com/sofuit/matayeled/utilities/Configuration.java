package com.sofuit.matayeled.utilities;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Created by osher on 26/4/16.
 */
@Data
@Component
@ConfigurationProperties(prefix="matayeled")
public class Configuration {

    private String securityKey;
    private String mailFrom;
    private String confirmationLinkPrefix;
    private String resetPassLinkPrefix;
    private String smtpHost;
    private String smtpUser;
    private String smtpPassword;
    private String invitationLinkPrefix;
    private String facebookAppId;
    private String facebookAppSecret;
    private String facebookRedirectUrl;
    private String adLinkPrefix;

}
