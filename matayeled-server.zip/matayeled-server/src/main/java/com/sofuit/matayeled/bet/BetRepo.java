package com.sofuit.matayeled.bet;

import com.sofuit.matayeled.game.Game;
import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.user.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

/**
 * Created by etingertal on 4/12/16.
 */
public interface BetRepo extends CrudRepository<Bet, String> {

    Optional<Bet> findByUserAndGame(User user, Game game);

    List<Bet> findBetsByUserAndGameStartTimeLessThanEqual(User user, Timestamp startTime);

    List<Bet> findByUser(User user);

    List<Bet> findByGame(Game game);

    Integer countByGameAndIsGenerated(Game game, Boolean isGenerated);

    Integer countByGameAndIsGeneratedAndIsBullsEye(Game game, Boolean isGenerated, Boolean isBullsEye);

    Page<Bet> findByIsBullsEyeAndIsGeneratedAndGameIn(
            Boolean isBullseye, Boolean isGenerated, List<Game> games, Pageable pageable);

    @Query(value = "select count(id) from Bet AS b " +
            "where b.team1Score > b.team2Score " +
            "and b.isGenerated=0 " +
            "and b.game=:game")
    Integer getTeam1BetsCount(@Param("game") Game game);

    @Query(value = "select count(id) from Bet AS b " +
            "where b.team1Score < b.team2Score " +
            "and b.isGenerated=0 " +
            "and b.game=:game")
    Integer getTeam2BetsCount(@Param("game") Game game);

    @Query(value = "select b from Bet AS b " +
            "where b.isBullsEye=1 " +
            "and b.isGenerated=0 " +
            "and b.game in (:games) " +
            "group by b.user " +
            "having count(id) = :gamesCount")
    List<Bet> getBullsEyesByDate(@Param("games") List<Game> games, @Param("gamesCount") Long gamesCount);
}
