package com.sofuit.matayeled.user;

import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;

/**
 * Created by osher on 7/4/16.
 */
@Data
public class UserClient {

    private String id;
    private String email;
    private String facebookId;
    private String firstName;
    private String lastName;
    private String phone;
    private Timestamp registrationDate;
    private String userPic;
    private String password;
    private Integer totalScore;
    private Integer totalHits;
    private Integer totalBullsEye;

    public UserClient() {

    }

    public UserClient(User user, UserScore score) throws ResourceNotFoundException {
        this.id = user.getId();
        this.email = user.getEmail();
        this.facebookId = user.getFacebookId();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.phone = user.getPhone();
        this.password = "";
        this.userPic = user.getPic();
        this.totalScore = score.getTotalScore();
        this.totalHits = score.getTotalHits();
        this.totalBullsEye = score.getTotalBullsEye();
    }

    public User convertToUser(User user) {
        if (user == null) {
            user = new User();
            user.setId(null);
            user.setGroups(null);
            user.setTopScorer(null);
            user.setWinningTeam(null);
            user.setPassword(this.getPassword());
        }
        user.setEmail(this.getEmail());
        user.setFacebookId(this.getFacebookId());
        user.setFirstName(this.getFirstName());
        user.setLastName(this.getLastName());
        user.setFullName(this.getFirstName() + " " + this.getLastName());
        user.setPhone(this.getPhone());
        user.setRegistrationDate(this.getRegistrationDate());
        user.setPic(this.getUserPic());
        return user;
    }
}