package com.sofuit.matayeled.game;

import com.sofuit.matayeled.utilities.Const;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

/**
 * Created by etingertal on 4/11/16.
 */
public interface GameRepo extends CrudRepository<Game, String> {

    Optional<Game> findById(String gameId);
    List<Game> findByStartTimeGreaterThanEqualOrderByStartTimeAsc(Timestamp startTime);
    List<Game> findByIsFinishedAndStartTimeGreaterThan(Boolean isFinished, Timestamp startTime);
    List<Game> findByStartTimeLessThanEqualOrderByStartTimeAsc(Timestamp startTime);
    List<Game> findByStartTimeLessThanEqualAndStartTimeGreaterThanEqualOrderByStartTimeAsc(Timestamp startTime, Timestamp openDate);
    Page<Game> findByStartTimeLessThanEqualOrderByStartTimeDesc(Timestamp startTime, Pageable page);
    Integer countByStartTimeLessThanEqual(Timestamp startTime);
    Integer countByGameCalcStatus(Const.GameCalcStatus gameCalcStatus);
    Game findTopByOrderByStartTimeAsc();
    Game findTopByGameCalcStatusOrderByStartTimeDesc(Const.GameCalcStatus status);
    Game findByIsLocking(Boolean isLocking);
    Game findTopByStartTimeGreaterThanEqualOrderByStartTimeAsc(Timestamp registerationTime);
    List<Game> findByIsFinished(Boolean isFinished);
    List<Game> findAllByOrderByStartTimeAsc();

}
