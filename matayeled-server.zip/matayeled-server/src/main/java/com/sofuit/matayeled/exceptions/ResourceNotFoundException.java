package com.sofuit.matayeled.exceptions;

/**
 * Created by osher on 9/4/16.
 */
public class ResourceNotFoundException extends Exception {

    public ResourceNotFoundException(String resource) {
        super("Tried to find nonexistent resource: " + resource);
    }
}
