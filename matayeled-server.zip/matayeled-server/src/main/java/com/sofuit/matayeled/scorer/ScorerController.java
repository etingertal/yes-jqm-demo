package com.sofuit.matayeled.scorer;

import com.sofuit.matayeled.config.IdentityService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Created by etingertal on 5/9/16.
 */
@RestController
@RequestMapping("/api/scorers")
public class ScorerController {

    private static final Logger classLogger = LoggerFactory.getLogger(ScorerController.class);

    @Autowired
    ScorerService scorerService;

    // Get scorers
    @RequestMapping(value = "", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Scorer>> getScorers() {
        classLogger.trace("User: {} is fetching scorers", IdentityService.getUser());
        return new ResponseEntity<>(scorerService.getScorers(), HttpStatus.OK);
    }
}
