package com.sofuit.matayeled.utilities;

import com.sofuit.matayeled.user.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Created by osher on 30/5/16.
 */
@Component
public class BackgroundExecution {

    private static final Logger classLogger = LoggerFactory.getLogger(BackgroundExecution.class);

    @Autowired
    UserService userService;

//    @Scheduled(cron = "0 4 * * * *")
//    public void cleanUnconfirmedAccounts() {
//        classLogger.info("cleanUnconfirmedAccounts method start run!");
//        userService.deleteUnconfirmedAccounts(Const.DAYS_TO_CONFIRM_ACCOUNT);
//    }
}
