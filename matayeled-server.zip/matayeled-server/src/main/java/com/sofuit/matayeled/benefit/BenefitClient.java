package com.sofuit.matayeled.benefit;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BenefitClient {

    private String id;

    private String code;

    private String description;

    private String pic;

    private String url;

    public BenefitClient(Benefit benefit) {
        if (benefit != null) {
            this.setId(benefit.getId());
            this.setCode(benefit.getCode());
            this.setDescription(benefit.getDescription());
            this.setPic(benefit.getPic());
            this.setUrl(benefit.getUrl());
        }
    }
}
