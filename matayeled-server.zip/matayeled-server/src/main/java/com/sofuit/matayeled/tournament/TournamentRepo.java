package com.sofuit.matayeled.tournament;

import org.springframework.data.repository.CrudRepository;

/**
 * Created by osher on 16/4/16.
 */
public interface TournamentRepo extends CrudRepository<Tournament, String> {
}
