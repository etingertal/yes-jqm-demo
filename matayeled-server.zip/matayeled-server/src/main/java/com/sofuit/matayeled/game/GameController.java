package com.sofuit.matayeled.game;

import com.sofuit.matayeled.bet.Bet;
import com.sofuit.matayeled.bet.BetClient;
import com.sofuit.matayeled.bet.BetService;
import com.sofuit.matayeled.config.IdentityService;
import com.sofuit.matayeled.exceptions.ForbiddenException;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.group.GroupService;
import com.sofuit.matayeled.model.GameClientWithTeams;
import com.sofuit.matayeled.model.GameWithUserBet;
import com.sofuit.matayeled.score.ScoreCalculation;
import com.sofuit.matayeled.statistics.GameStatsService;
import com.sofuit.matayeled.user.User;
import com.sofuit.matayeled.user.UserScore;
import com.sofuit.matayeled.user.UserScoreService;
import com.sofuit.matayeled.user.UserService;
import com.sofuit.matayeled.utilities.Const;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * Created by etingertal on 4/11/16.
 */
@RestController
@RequestMapping("/api/games")
public class GameController {

    private static final Logger classLogger = LoggerFactory.getLogger(GameController.class);

    @Autowired
    ScoreCalculation scoreCalculation;

    @Autowired
    GameService gameService;

    @Autowired
    UserService userService;

    @Autowired
    UserScoreService userScoreService;

    @Autowired
    GroupService groupService;

    @Autowired
    BetService betService;

    @Autowired
    GameStatsService gameStatsService;

    // Get next games
    @RequestMapping(value = "/{gameId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GameClientWithTeams> getGameById(@PathVariable("gameId") String gameId)
            throws ResourceNotFoundException {
        String userId = IdentityService.getUser();
        classLogger.trace("User: {} is fetching game: {}", userId, gameId);

        Game game = gameService.findById(gameId);
        GameClientWithTeams gameClientWithTeams = new GameClientWithTeams(game, game.getTeam1(), game.getTeam2());

        return new ResponseEntity<>(gameClientWithTeams, HttpStatus.OK);
    }

    // Get next games
    @RequestMapping(value = "/next", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<GameWithUserBet>> getNextGamesWithUserBets()
            throws ResourceNotFoundException {
        String userId = IdentityService.getUser();
        classLogger.trace("User: {} is fetching next games", userId);

        User user = userService.findById(userId);
        List<GameWithUserBet> gameWithUserBets = getGamesWithUserBetsList(gameService.getNextGames(), user, true);

        return new ResponseEntity<>(gameWithUserBets, HttpStatus.OK);
    }

    // Get games history
    @RequestMapping(value = "/history", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<GameWithUserBet>> getGamesHistoryWithUserBets(@RequestParam int page)
            throws ResourceNotFoundException {
        String userId = IdentityService.getUser();
        classLogger.trace("User: {} is fetching next games", userId);

        User user = userService.findById(userId);
//        int maxSize = gameService.getHistoryGamesCount() - ((page) * 5);
        Pageable pageable = new PageRequest(page, 2);
        List<Game> historyGames = new ArrayList<>();
        gameService.getGamesHistoryReversePageable(pageable).forEach(game -> historyGames.add(game));
        List<GameWithUserBet> gameWithUserBets = getGamesWithUserBetsList(historyGames, user, false);

        return new ResponseEntity<>(gameWithUserBets, HttpStatus.OK);
    }

    // Get games history
    @RequestMapping(value = "/past/{groupId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<GameClientWithTeams>> getGamesHistory(@PathVariable("groupId") String groupId)
            throws ResourceNotFoundException {
        String userId = IdentityService.getUser();
        classLogger.trace("User: {} is fetching history games", userId);

        // Get group
        Group group = groupService.findById(groupId);

        List<GameClientWithTeams> res = new ArrayList<>();

        if (!group.getPointsCalcFromTournamentStart()) {
            gameService.getGamesHistoryByGroupOpenDate(group.getOpenDate()).forEach(game ->
                    res.add(new GameClientWithTeams(game, game.getTeam1(), game.getTeam2())));
        } else {
            gameService.getGamesHistory().forEach(game ->
                    res.add(new GameClientWithTeams(game, game.getTeam1(), game.getTeam2())));
        }

        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    // Get first game
    @RequestMapping(value = "/first", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GameClient> getFirstGame()
            throws ResourceNotFoundException {
        String userId = IdentityService.getUser();
        classLogger.trace("User: {} is fetching first game", userId);

        GameClient res = new GameClient(gameService.getFirstGame());

        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    // Get first game
    @RequestMapping(value = "/userLocking", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GameClient> getUserFirstLockingGame()
            throws ResourceNotFoundException {
        User user = userService.findById(IdentityService.getUser());
        classLogger.trace("User: {} is fetching his first locking game", user.getId());

        Game userLocking = gameService.getUserFirstLockingGame(user);
        Game appLocking = gameService.getBetsLockingGame(Boolean.TRUE);

        GameClient res;
        if ((user.getWinningTeam() == null) || (user.getTopScorer() == null))
            res = new GameClient(appLocking);
        else if ((userLocking != null) && (userLocking.getStartTime().toLocalDateTime().isBefore(appLocking.getStartTime().toLocalDateTime())))
            res = new GameClient(userLocking);
        else
            res = new GameClient(appLocking);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    // Get all games
    @RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<GameClientWithTeams>> getGames()
            throws ResourceNotFoundException, ForbiddenException {
        User user = userService.findById(IdentityService.getUser());
        List<GameClientWithTeams> res = new ArrayList<>();

        // Only admins allowed
        if ((user.getRole() != null) &&
                (user.getRole().equals(Const.ROLE_ADMIN))) {
            classLogger.trace("User: {} is fetching all games", user.getId());

            gameService.getAllGames().forEach(game -> res.add(new GameClientWithTeams(game, game.getTeam1(), game.getTeam2())));
        } else {
            classLogger.warn(Const.securityMarker, "Non-admin user trying to get all admin games: {}", user.getId());
            throw new ForbiddenException("Non-admin user trying to get all admin games");
        }

        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    // Get user total games
    @RequestMapping(value = "/userCount/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getUserTotalGames(@PathVariable("userId") String userId)
            throws ResourceNotFoundException {
        UserScore uscore = userScoreService.findById(userId);

        classLogger.trace("User: {} is fetching total games count for: {}", IdentityService.getUser(), uscore.getId());

        Integer getUserTotalGames = gameService.getCalculatedGamesCount() - uscore.getMissedGames();

        return new ResponseEntity<>("{\"count\": " + getUserTotalGames + "}", HttpStatus.OK);
    }

    // Get bets locking game
    @RequestMapping(value = "/locking", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GameClient> getBetsLockingGame()
            throws ResourceNotFoundException {
        String userId = IdentityService.getUser();
        classLogger.trace("User: {} is fetching locking game", userId);

        Game res = gameService.getBetsLockingGame(Boolean.TRUE);

        // If we didnt set locking game, take the first one
        if (res == null)
            res = gameService.getFirstGame();

        return new ResponseEntity<>(new GameClient(res), HttpStatus.OK);
    }

    // Get current time
    @RequestMapping(value = "/getCurrentTime", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getCurrentTime() throws ResourceNotFoundException {
        classLogger.trace("User: {} is fetching current time", IdentityService.getUser());
        return new ResponseEntity<>("{\"currentTime\": \"" + new Timestamp(new Date().getTime()) + "\"}", HttpStatus.OK);
    }

    private List<GameWithUserBet> getGamesWithUserBetsList(List<Game> games, User user, boolean hideGeneratedBets) {
        List<GameWithUserBet> gameWithUserBets = new ArrayList<>();

        for (Game game : games) {
            GameWithUserBet gameWithUserBet = new GameWithUserBet();
            gameWithUserBet.setGame(new GameClient(game));
            gameWithUserBet.setTeam1(game.getTeam1());
            gameWithUserBet.setTeam2(game.getTeam2());
            Optional<Bet> currBet = betService.findByUserAndGame(user, game);

            if (currBet.isPresent()) {
                BetClient betClient = new BetClient(currBet.get());

                // Hide bets if neccesary
                if (hideGeneratedBets)
                    if (currBet.get().getIsGenerated()) {
                        betClient.setTeam1Score(null);
                        betClient.setTeam2Score(null);
                    }

                gameWithUserBet.setBet(betClient);
            } else
                gameWithUserBet.setBet(null);

            gameWithUserBets.add(gameWithUserBet);
        }

        return gameWithUserBets;
    }

    // Update games with score
    @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void updateGames(@RequestBody List<GameClient> games, HttpServletResponse response)
        throws ResourceNotFoundException, ForbiddenException, IOException, Exception{

        User user = userService.findById(IdentityService.getUser());

        // Only admins allowed
        if ((user.getRole() != null) &&
            (user.getRole().equals(Const.ROLE_ADMIN))) {
            classLogger.info("User {}({}) is updating games!", user.getFullName(), user.getId());
            if (games != null && games.size() > 0) {
                PrintWriter wr = null;
                try {
                    wr = response.getWriter();
                    response.setStatus(200);
                    wr.flush();
                    wr.close();
                } catch (IOException e) {
                    classLogger.error("Error while admin update game:", e);
                } finally {
                    if (wr != null) {
                        wr.close();
                    }
                }

                scoreCalculation.updateAndCalc(games);

                // Update user game stats with bullseyes
                gameStatsService.updateUserGamesStatsWithBullsEyes(games);
            }

        } else {
            classLogger.warn(Const.securityMarker, "Non-admin user trying to update games: {}", user.getId());
            throw new ForbiddenException("Non-admin user trying to update games");
        }
    }

    // Update games with score
    @RequestMapping(value = "/reset/{gameId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GameClient> resetGame(@PathVariable("gameId") String gameId)
            throws ResourceNotFoundException, ForbiddenException {

        User user = userService.findById(IdentityService.getUser());
        Game game = null;

        // Only admins allowed
        if ((user.getRole() != null) &&
                (user.getRole().equals(Const.ROLE_ADMIN))) {
            classLogger.info("User {}({}) is resetting game!", user.getFullName(), user.getId());

            game = gameService.findById(gameId);
            gameService.resetGameCalculationData(game);

        } else {
            classLogger.warn(Const.securityMarker, "Non-admin user trying to reset game: {}", user.getId());
            throw new ForbiddenException("Non-admin user trying to reset game");
        }

        return new ResponseEntity<>(new GameClient(game), HttpStatus.OK);
    }
}
