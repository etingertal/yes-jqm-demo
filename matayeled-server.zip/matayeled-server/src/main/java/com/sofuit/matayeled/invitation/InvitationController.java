package com.sofuit.matayeled.invitation;

import com.sofuit.matayeled.config.IdentityService;
import com.sofuit.matayeled.exceptions.ForbiddenException;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.group.GroupService;
import com.sofuit.matayeled.utilities.Configuration;
import com.sofuit.matayeled.utilities.Const;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

/**
 * Created by etingertal on 4/24/16.
 */
@RestController
@RequestMapping("/api/invitations")
public class InvitationController {

    private static final Logger classLogger = LoggerFactory.getLogger(InvitationController.class);

    @Autowired
    Configuration conf;

    @Autowired
    InvitationService invitationService;

    @Autowired
    GroupService groupService;

    // Send invitation without group (= null)
    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<InvitationClient> getInvitationLink()
            throws ResourceNotFoundException, ForbiddenException {
        return this.getInvitationLinkWithGroup(null);
    }

    // Send invitation
    @RequestMapping(value = "/{groupId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<InvitationClient> getInvitationLinkWithGroup(@PathVariable("groupId") String groupId)
                throws ResourceNotFoundException, ForbiddenException {
        String userId = IdentityService.getUser();
        InvitationClient invitationClient = null;
        classLogger.trace("User: {} inviting someone to group: {}", userId, groupId);

        // Check if the group is null and the user wants the game invitation
        Optional<Invitation> invitation;
        Group group = null;
        if ((groupId != null) && (!groupId.isEmpty())) {
            // Get the group object
            group = groupService.findById(groupId);

            // Check that user is in the group
            if (!groupService.isUserInGroup(userId, groupId)) {
                classLogger.warn(Const.securityMarker, "User: {} tried to send invitation for a group he's not in: {}", userId, groupId);
                throw new ForbiddenException("User tried to send invitation for a group he's not in.");
            } else {
                invitation = invitationService.findByAssignedGroup(group);
            }
        } else {
            invitation = invitationService.findByAssignedGroup(null);
        }

        // Create new invitation if everything went ok but we didn't find one
        if (invitation.isPresent())
            invitationClient = new InvitationClient(invitation.get());
        else {
            invitationClient = new InvitationClient();
            invitationClient.setClicksCounter(0);
            invitationClient = invitationService.createInvitation(invitationClient, group);
            invitationClient.setLink(conf.getInvitationLinkPrefix() + invitationClient.getId());

            Invitation newInvitation = invitationClient.convertToInvitation(group);
            invitationService.updateInvitation(newInvitation);
        }

        return new ResponseEntity<>(invitationClient, HttpStatus.OK);
    }

    @RequestMapping(value = "/activate/{invitationId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> activateInvitationLinkWithGroup(@PathVariable("invitationId") String invitationId)
            throws ResourceNotFoundException, ForbiddenException {
        String userId = IdentityService.getUser();
        classLogger.trace("User: {} activates invitation: {}", userId, invitationId);


        Invitation invitation = invitationService.findById(invitationId);
        Group assignedGroup = invitation.getAssignedGroup();

        if (assignedGroup != null) {
            // Add user to group
            groupService.addUsersToGroup(assignedGroup.getId(), new String[] { userId });
        }

        invitation.setClicksCounter(invitation.getClicksCounter() + 1);
        invitationService.updateInvitation(invitation);

        return new ResponseEntity<>(HttpStatus.OK);
    }
}

