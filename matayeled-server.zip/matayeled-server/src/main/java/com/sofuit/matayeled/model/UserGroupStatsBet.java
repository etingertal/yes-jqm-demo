package com.sofuit.matayeled.model;

import com.sofuit.matayeled.bet.BetClient;
import com.sofuit.matayeled.stat.UserGroupStatsClient;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by osher on 18/4/16.
 */
@Data
@NoArgsConstructor
public class UserGroupStatsBet {

    private UserGroupStatsClient stat;
    private BetClient bet;

    public UserGroupStatsBet(UserGroupStatsClient stat, BetClient bet) {
        this.stat = stat;
        this.bet = bet;
    }
}
