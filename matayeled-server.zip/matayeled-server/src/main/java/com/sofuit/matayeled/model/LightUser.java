package com.sofuit.matayeled.model;

import com.sofuit.matayeled.user.User;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by osher on 18/4/16.
 */
@Data
@NoArgsConstructor
public class LightUser {

    private String id;
    private String firstName;
    private String lastName;
    private String pic;

    public LightUser(User user) {
        this.id = user.getId();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.pic = user.getPic();
    }
}