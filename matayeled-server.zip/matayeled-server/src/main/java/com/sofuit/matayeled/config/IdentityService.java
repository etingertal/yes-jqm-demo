package com.sofuit.matayeled.config;

/**
 * Created by osher on 26/4/16.
 */
public class IdentityService {

    private static final ThreadLocal<String> USER = new ThreadLocal<String>() {
        @Override
        protected String initialValue() {
            return "empty";
        }
    };

    public static void setUser(String subject) {
        USER.set(subject);
    }

    public static String getUser() {
        return USER.get();
    }

    public static void removeUser() {
        USER.remove();
    }
}
