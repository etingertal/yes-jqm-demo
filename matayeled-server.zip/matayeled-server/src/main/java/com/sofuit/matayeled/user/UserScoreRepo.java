package com.sofuit.matayeled.user;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

/**
 * Created by etingertal on 4/10/16.
 */
public interface UserScoreRepo extends CrudRepository<UserScore, String> {

    Optional<UserScore> findById(String id);

    @Query( value = "select u, " +
            "us.totalScore AS calcedScore, " +
            "(((us.totalHits)/(:historyGameCount-(us.missedGames)))*100) AS calcedHitsRatio, " +
            "(us.totalBullsEye) AS calcedBullseye " +
            "from User AS u, UserScore AS us " +
            "where u.id = us.id " +
            "order by calcedScore desc, calcedHitsRatio desc, calcedBullseye desc ",
            countQuery = "select count(u.id) " +
                    "from User AS u, UserScore AS us " +
                    "where u.id = us.id " +
                    "and -1 <> :historyGameCount")
//    List<Object[]> getTop50(@Param("historyGameCount") int historyGameCount);
    Page<Object[]> getTop50(@Param("historyGameCount") int historyGameCount, Pageable pageable);
}
