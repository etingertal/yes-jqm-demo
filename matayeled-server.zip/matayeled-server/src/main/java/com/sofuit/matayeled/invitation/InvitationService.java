package com.sofuit.matayeled.invitation;

import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.group.GroupService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Created by etingertal on 4/24/16.
 */
@Service
public class InvitationService {

    @Autowired
    InvitationRepo invitationRepo;

    @Autowired
    GroupService groupService;

    public Invitation findById(String id) throws ResourceNotFoundException {

        return invitationRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("invitation id:" + id));
    }

    public Optional<Invitation> findByAssignedGroup(Group group) {
        return invitationRepo.findByAssignedGroup(group);
    }

    @Transactional
    public InvitationClient createInvitation(InvitationClient invitationClient, Group group) throws ResourceNotFoundException {

        Invitation newInvitation = new Invitation();
        newInvitation = invitationClient.convertToInvitation(group);
        invitationRepo.save(newInvitation);
        return new InvitationClient(newInvitation);
    }

    @Transactional
    public Invitation updateInvitation(Invitation invitation) throws ResourceNotFoundException {

        return invitationRepo.save(invitation);
    }

    @Transactional
    public void deleteInvitation(Group group) throws ResourceNotFoundException {
        Optional<Invitation> invite = invitationRepo.findByAssignedGroup(group);
        if (invite.isPresent()) {
            invitationRepo.delete(invite.get());
        }
    }
}
