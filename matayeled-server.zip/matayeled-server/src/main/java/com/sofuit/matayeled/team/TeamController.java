package com.sofuit.matayeled.team;

import com.sofuit.matayeled.config.IdentityService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Created by etingertal on 5/9/16.
 */
@RestController
@RequestMapping("/api/teams")
public class TeamController {

    private static final Logger classLogger = LoggerFactory.getLogger(TeamController.class);

    @Autowired
    TeamService teamService;

    // Get teams
    @RequestMapping(value = "", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Team>> getTeams() {
        classLogger.trace("User: {} is fetching teams", IdentityService.getUser());
        return new ResponseEntity<>(teamService.getTeams(), HttpStatus.OK);
    }
}
