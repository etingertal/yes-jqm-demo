package com.sofuit.matayeled.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;

@Profile({ "osher-dev", "tal-dev" })
@Component
public class CORSFilter extends GenericFilterBean {

    /**
     * The Logger for this class.
     */
    private final Logger classLogger = LoggerFactory.getLogger(CORSFilter.class);

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp,
                         FilterChain chain) throws IOException, ServletException {

        if (req instanceof HttpServletRequest) {
            String url = ((HttpServletRequest)req).getRequestURL().toString();
            String queryString = ((HttpServletRequest)req).getQueryString();
            String method = ((HttpServletRequest)req).getMethod();
            classLogger.debug(String.format("in filter, got: %s to: %s, query: %s", method, url, queryString));
        }

        HttpServletResponse response = (HttpServletResponse) resp;
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods",
                "DELETE, GET, OPTIONS, PATCH, POST, PUT");
        response.setHeader("Access-Control-Max-Age", "3600");
        response.setHeader("Access-Control-Allow-Headers",
                "x-requested-with, content-type, Authorization");

        chain.doFilter(req, resp);
    }

}