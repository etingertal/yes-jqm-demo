package com.sofuit.matayeled.statistics;

import com.sofuit.matayeled.bet.BetRepo;
import com.sofuit.matayeled.game.Game;
import com.sofuit.matayeled.game.GameClient;
import com.sofuit.matayeled.game.GameRepo;
import com.sofuit.matayeled.utilities.Const;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class GameStatsService {

    private static final Logger classLogger = LoggerFactory.getLogger(GameStatsService.class);

    @Autowired
    GameStatsRepo gameStatsRepo;

    @Autowired
    GameRepo gameRepo;

    @Autowired
    BetRepo betRepo;

    public List<GameStats> getUserGameStats() {
        List<GameStats> stats = gameStatsRepo.findByOrderByUpdateTimeAsc();
        return stats;
    }

    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateUserGamesStats(List<Game> gamesToStats) {
        // Generate stats for new finished games
        classLogger.info("Updating {} user game stats", gamesToStats.size());
        for (Game currGame : gamesToStats) {
            try {
                GameStats newGameStats = gameStatsRepo.findByGame(currGame);

                if (newGameStats == null) {
                    newGameStats = new GameStats();
                    newGameStats.setGame(currGame);
                    newGameStats.setTotalBets(betRepo.countByGameAndIsGenerated(currGame, Boolean.FALSE));
                    newGameStats.setTeam1BetsCount(betRepo.getTeam1BetsCount(currGame));
                    newGameStats.setTeam2BetsCount(betRepo.getTeam2BetsCount(currGame));
                    newGameStats.setTotalBullsEyes(-1);
                    newGameStats.setUpdateTime(currGame.getStartTime());
                    gameStatsRepo.save(newGameStats);
                }
            } catch (Exception e) {
                classLogger.error("Error in update of user game stats:", e);
                throw e;
            }
        }
    }

    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateUserGamesStatsWithBullsEyes(List<GameClient> gamesToStats) {
        // Generate stats for new finished games
        classLogger.info("Updating {} user game stats with bullseyes", gamesToStats.size());
        for (GameClient currClientGame : gamesToStats) {
            try {
                Optional<Game> game = gameRepo.findById(currClientGame.getId());

                if (game.isPresent()) {
                    Game currGame = game.get();
                    if (currGame.getGameCalcStatus() == Const.GameCalcStatus.CALCULATION_FINISHED) {
                        GameStats newGameStats = gameStatsRepo.findByGame(currGame);
                        newGameStats.setTotalBullsEyes(betRepo.countByGameAndIsGeneratedAndIsBullsEye(currGame, Boolean.FALSE, Boolean.TRUE));

                        gameStatsRepo.save(newGameStats);
                    }
                }
            } catch (Exception e) {
                classLogger.error("Error in update of user game stats:", e);
                throw e;
            }
        }
    }


}
