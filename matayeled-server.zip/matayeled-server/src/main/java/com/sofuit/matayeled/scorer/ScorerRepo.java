package com.sofuit.matayeled.scorer;

import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

/**
 * Created by etingertal on 5/9/16.
 */
public interface ScorerRepo extends CrudRepository<Scorer, String> {

    Optional<Scorer> findById(String scorerId);
}
