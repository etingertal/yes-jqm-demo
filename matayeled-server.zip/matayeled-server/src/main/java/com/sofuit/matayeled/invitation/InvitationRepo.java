package com.sofuit.matayeled.invitation;

import com.sofuit.matayeled.group.Group;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

/**
 * Created by etingertal on 4/24/16.
 */
public interface InvitationRepo extends CrudRepository<Invitation, String> {

    Optional<Invitation> findById(String id);
    Optional<Invitation> findByAssignedGroup(Group group);
}
