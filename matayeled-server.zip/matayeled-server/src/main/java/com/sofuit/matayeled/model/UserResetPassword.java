package com.sofuit.matayeled.model;

import lombok.Data;

/**
 * Created by etingertal on 5/27/16.
 */
@Data
public class UserResetPassword {

    private String resetPasswordId;
    private String newPassword;
}
