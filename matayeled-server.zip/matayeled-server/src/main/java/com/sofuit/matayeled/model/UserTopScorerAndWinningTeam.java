package com.sofuit.matayeled.model;

import com.sofuit.matayeled.scorer.Scorer;
import com.sofuit.matayeled.team.Team;
import com.sofuit.matayeled.user.UserClient;
import lombok.Data;

/**
 * Created by etingertal on 4/26/16.
 */
@Data
public class UserTopScorerAndWinningTeam {

    private UserClient user;
    private Scorer topScorer;
    private Team winningTeam;

    public void setTopScorer(Scorer scorer) {
        this.topScorer = new Scorer();

        if (scorer != null) {
            this.topScorer.setId(scorer.getId());
            this.topScorer.setName(scorer.getName());
            this.topScorer.setPicUrl(scorer.getPicUrl());
        }
    }

    public void setWinningTeam(Team team) {
        this.winningTeam = new Team();

        if (team != null) {
            this.winningTeam.setId(team.getId());
            this.winningTeam.setName(team.getName());
            this.winningTeam.setPic(team.getPic());
        }
    }
}
