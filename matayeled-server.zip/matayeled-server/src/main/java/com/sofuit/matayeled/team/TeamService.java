package com.sofuit.matayeled.team;

import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by etingertal on 5/9/16.
 */
@Service
public class TeamService {

    @Autowired
    TeamRepo teamRepo;

    public Team findById(String teamId) throws ResourceNotFoundException {
        return teamRepo.findById(teamId).orElseThrow(() -> new ResourceNotFoundException("team id:" + teamId));
    }

    public List<Team> getTeams() {
        List<Team> teams = new ArrayList<>();
        teamRepo.findAll().forEach(teams::add);
        return teams;
    }
}
