package com.sofuit.matayeled.statistics;

import com.sofuit.matayeled.ad.Ad;
import com.sofuit.matayeled.ad.AdRepo;
import com.sofuit.matayeled.benefit.Benefit;
import com.sofuit.matayeled.benefit.BenefitRepo;
import com.sofuit.matayeled.bet.Bet;
import com.sofuit.matayeled.bet.BetRepo;
import com.sofuit.matayeled.config.IdentityService;
import com.sofuit.matayeled.exceptions.ForbiddenException;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.game.Game;
import com.sofuit.matayeled.game.GameRepo;
import com.sofuit.matayeled.group.GroupRepo;
import com.sofuit.matayeled.model.GameClientWithTeams;
import com.sofuit.matayeled.model.GameTeamsStats;
import com.sofuit.matayeled.model.LightUser;
import com.sofuit.matayeled.user.User;
import com.sofuit.matayeled.user.UserRepo;
import com.sofuit.matayeled.user.UserService;
import com.sofuit.matayeled.utilities.Const;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by etingertal on 6/26/16.
 */
@RestController
@RequestMapping("/api/statistics")
public class StatisticsController {

    @Autowired
    UserService userService;

    @Autowired
    UserRepo userRepo;

    @Autowired
    GroupRepo groupRepo;

    @Autowired
    AdRepo adRepo;

    @Autowired
    GameRepo gameRepo;

    @Autowired
    BetRepo betRepo;

    @Autowired
    BenefitRepo benefitRepo;

    @Autowired
    GameStatsService gameStatsService;

    @RequestMapping(value = "/users/total", method = RequestMethod.GET)
    public ResponseEntity<String> countTotalUsers()
        throws ResourceNotFoundException, ForbiddenException {
        adminOrThrow();

        return new ResponseEntity<>("{\"count\": \"" + userRepo.count() + "\"}", HttpStatus.OK);
    }

    @RequestMapping(value = "/users/lastWeek", method = RequestMethod.GET)
    public ResponseEntity<String> countTotalUsersLastWeek()
            throws ResourceNotFoundException, ForbiddenException {
        adminOrThrow();

        Timestamp weekAgo = Timestamp.valueOf(LocalDateTime.now().minusDays(7));

        return new ResponseEntity<>("{\"count\": \"" +
                userRepo.countByRegistrationDateGreaterThanEqual(weekAgo) + "\"}", HttpStatus.OK);
    }

    @RequestMapping(value = "/groups/total", method = RequestMethod.GET)
    public ResponseEntity<String> countTotalGroups()
            throws ResourceNotFoundException, ForbiddenException {
        adminOrThrow();

        return new ResponseEntity<>("{\"count\": \"" + groupRepo.count() + "\"}", HttpStatus.OK);
    }

    @RequestMapping(value = "/ads", method = RequestMethod.GET)
    public ResponseEntity<List<Ad>> getAds()
            throws ResourceNotFoundException, ForbiddenException {
        adminOrThrow();

        List<Ad> ads = new ArrayList<>();
        adRepo.findAll().forEach(ad -> ads.add(ad));

        return new ResponseEntity<>(ads, HttpStatus.OK);
    }

    @RequestMapping(value = "/benefits", method = RequestMethod.GET)
    public ResponseEntity<List<Benefit>> getBenefits()
            throws ResourceNotFoundException, ForbiddenException {
        adminOrThrow();

        List<Benefit> benefits = new ArrayList<>();
        benefitRepo.findAll().forEach(benefit -> benefits.add(benefit));

        return new ResponseEntity<>(benefits, HttpStatus.OK);
    }

    @RequestMapping(value = "/bullseyes/{date}", method = RequestMethod.GET)
    public ResponseEntity<List<LightUser>> getBullseyesByDate(@PathVariable("date") String date) //, @RequestParam int page)
            throws ResourceNotFoundException, ForbiddenException {
        adminOrThrow();

        List<LightUser> users = new ArrayList<>();

        if (!date.isEmpty()) {
            DateTimeFormatter df = DateTimeFormatter.ofPattern("ddMMyyyy");
            LocalDate ld = LocalDate.parse(date, df);
            Timestamp tsTodayMidnight = Timestamp.valueOf(ld.atStartOfDay());
            Timestamp tsNextMidnight = Timestamp.valueOf(ld.plusDays(1).atStartOfDay());

            List<Game> games =
                    gameRepo.findByStartTimeLessThanEqualAndStartTimeGreaterThanEqualOrderByStartTimeAsc(tsNextMidnight, tsTodayMidnight);

            if (games.size() > 0) {
//                Pageable pageable = new PageRequest(page, 20);
                List<Bet> bets = betRepo.getBullsEyesByDate(
                        games, Long.valueOf(games.size()));

                bets.forEach(bet -> users.add(new LightUser(bet.getUser())));
            }
        }

        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    @RequestMapping(value = "/gamesStats", method = RequestMethod.GET)
    public ResponseEntity<List<GameTeamsStats>> getGamesStats()
            throws ResourceNotFoundException, ForbiddenException {

        adminOrThrow();

        List<GameTeamsStats> list = new ArrayList<>();
        List<Game> futureGames = gameRepo.findByStartTimeGreaterThanEqualOrderByStartTimeAsc(Timestamp.valueOf(LocalDateTime.now()));
        List<Game> histGames = gameRepo.findByStartTimeLessThanEqualOrderByStartTimeAsc(Timestamp.valueOf(LocalDateTime.now()));
        List<Game> games = new ArrayList<>();

        // Add the 2 nearest past games
        if (futureGames.size() > 0)
            games.add(histGames.get(histGames.size()-1));
        if (futureGames.size() > 1)
            games.add(histGames.get(histGames.size()-2));

        // Add the 2 nearest future games
        if (futureGames.size() > 0)
            games.add(futureGames.get(0));
        if (futureGames.size() > 1)
            games.add(futureGames.get(1));

        for (Game game : games) {
            GameTeamsStats stats = new GameTeamsStats();
            GameClientWithTeams gameClientWithTeams =
                    new GameClientWithTeams(game, game.getTeam1(), game.getTeam2());
            stats.setGameClientWithTeams(gameClientWithTeams);

            // Fetch counters
            stats.setTotalBets(betRepo.countByGameAndIsGenerated(game, Boolean.FALSE));
            stats.setTeam1BetsCount(betRepo.getTeam1BetsCount(game));
            stats.setTeam2BetsCount(betRepo.getTeam2BetsCount(game));
            stats.setTotalBullsEyes(betRepo.countByGameAndIsGeneratedAndIsBullsEye(game, Boolean.FALSE, Boolean.TRUE));

            list.add(stats);
        }

        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @RequestMapping(value = "/user/gamesStats", method = RequestMethod.GET)
    public ResponseEntity<List<GameTeamsStats>> getUserGamesStats()
            throws ResourceNotFoundException, ForbiddenException {
        List<GameTeamsStats> list = new ArrayList<>();
        List<GameStats> histGames = gameStatsService.getUserGameStats();

//        gameStatsService.updateUserGamesStats();

        for (GameStats gameStats : histGames) {
            GameTeamsStats stats = new GameTeamsStats();
            GameClientWithTeams gameClientWithTeams =
                    new GameClientWithTeams(gameStats.getGame(), gameStats.getGame().getTeam1(), gameStats.getGame().getTeam2());
            stats.setGameClientWithTeams(gameClientWithTeams);

            // Fetch counters
            stats.setTotalBets(gameStats.getTotalBets());
            stats.setTeam1BetsCount(gameStats.getTeam1BetsCount());
            stats.setTeam2BetsCount(gameStats.getTeam2BetsCount());
            stats.setTotalBullsEyes(gameStats.getTotalBullsEyes());

            list.add(stats);
        }

        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    private void adminOrThrow() throws ResourceNotFoundException, ForbiddenException {

        User user = userService.findById(IdentityService.getUser());

        // Only admins allowed
        if (!(user.getRole() != null && user.getRole().equals(Const.ROLE_ADMIN))) {
            throw new ForbiddenException("Nono");
        }
    }
}
