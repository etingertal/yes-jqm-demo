package com.sofuit.matayeled.group;

import com.sofuit.matayeled.utilities.Const;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;
import java.util.Optional;

/**
 * Created by osher on 9/4/16.
 */
public interface GroupRepo extends PagingAndSortingRepository<Group, String> {

    Optional<Group> findById(String groupId);

    Page<Group> findByPrivacyOrderByPromotionLevelDesc(Const.GroupPrivacy privacy, Pageable pageable);

    Page<Group> findByPrivacyAndNameLikeOrderByPromotionLevelDesc(Const.GroupPrivacy privacy, String name, Pageable pageable);
}
