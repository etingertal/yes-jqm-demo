package com.sofuit.matayeled.bet;

import com.sofuit.matayeled.game.Game;
import com.sofuit.matayeled.user.User;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by etingertal on 4/15/16.
 */
@Data
@NoArgsConstructor
public class BetClient {

    private String id;
    private Integer team1Score;
    private Integer team2Score;
    private Boolean isGenerated;
    private Integer score;
    private Boolean isBullsEye;

    public BetClient(Bet bet) {
        this.id = bet.getId();
        this.team1Score = bet.getTeam1Score();
        this.team2Score = bet.getTeam2Score();
        this.isGenerated = bet.getIsGenerated();
        this.score = bet.getScore();
        this.isBullsEye = bet.getIsBullsEye();
    }

    public Bet convertToBet(Game game, User user) {
        Bet bet = new Bet();
        bet.setGame(game);
        bet.setUser(user);
        bet.setTeam1Score(this.getTeam1Score());
        bet.setTeam2Score(this.getTeam2Score());
        bet.setIsGenerated(this.getIsGenerated());
        return bet;
    }
}
