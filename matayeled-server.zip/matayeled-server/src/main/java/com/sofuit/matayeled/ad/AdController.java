package com.sofuit.matayeled.ad;

import com.sofuit.matayeled.exceptions.ForbiddenException;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.utilities.Configuration;
import com.sofuit.matayeled.utilities.Const;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by etingertal on 6/17/16.
 */
@RestController
@RequestMapping("/banners")
public class AdController {

    private static final Logger classLogger = LoggerFactory.getLogger(AdController.class);

    @Autowired
    Configuration conf;

    @Autowired
    AdService adService;

    @RequestMapping(value = "/{type}", method = RequestMethod.GET)
    public ResponseEntity<AdClient> getAdToDisplay(@PathVariable("type") String type) {
        List<Ad> ads = adService.findByTypeAndIsActive(type, Boolean.TRUE);

        Random rand = new Random();
        Ad ad = ads.get(rand.nextInt(ads.size()));
        adService.addOneImpression(ad);
        AdClient adClient = new AdClient(ad);

//        if (ad.getUrl().equals("benefit"))
            adClient.setUrl(ad.getUrl());
//        else {
//            adClient.setUrl(conf.getAdLinkPrefix() + ad.getId());
//            adClient.setRealUrl(ad.getUrl());
//        }

        return new ResponseEntity<>(adClient, HttpStatus.OK);
    }

    @RequestMapping(value = "/redirect/{id}", method = RequestMethod.GET)
    public void goToAd(@PathVariable("id") String id, HttpServletResponse response)
            throws ResourceNotFoundException, ForbiddenException, IOException {
        Ad ad = adService.findById(id);
        adService.addOneClick(ad);

//        response.sendRedirect(ad.getUrl());
    }

    @RequestMapping(value = "/promos", method = RequestMethod.GET)
    public ResponseEntity<List<AdClient>> getPromos()
            throws ResourceNotFoundException, ForbiddenException, IOException {
        List<AdClient> adClients = new ArrayList<>();
        List<Ad> promos = adService.findByTypeAndIsActive(Const.PROMOS_TYPE, Boolean.TRUE);
        adService.addOneImpressionList(promos);

        for (Ad promo : promos) {
            AdClient adClient = new AdClient(promo);
            adClient.setUrl(promo.getUrl());
            adClients.add(adClient);
        }
        promos.forEach(ad -> adClients.add(new AdClient(ad)));

        return new ResponseEntity<>(adClients, HttpStatus.OK);
    }
}
