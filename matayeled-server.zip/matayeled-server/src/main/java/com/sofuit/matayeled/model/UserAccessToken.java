package com.sofuit.matayeled.model;

import lombok.Data;

/**
 * Created by etingertal on 5/1/16.
 */
@Data
public class UserAccessToken {

    private String accessToken;
}
