package com.sofuit.matayeled.auth;

import com.sofuit.matayeled.bet.BetService;
import com.sofuit.matayeled.exceptions.ConflictException;
import com.sofuit.matayeled.exceptions.ForbiddenException;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.model.UserAccessToken;
import com.sofuit.matayeled.model.UserLogin;
import com.sofuit.matayeled.model.UserResetPassword;
import com.sofuit.matayeled.user.User;
import com.sofuit.matayeled.user.UserClient;
import com.sofuit.matayeled.user.UserService;
import com.sofuit.matayeled.utilities.Configuration;
import com.sofuit.matayeled.utilities.Const;
import com.sofuit.matayeled.utilities.MailSender;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * Created by osher on 23/4/16.
 */
@RestController
@RequestMapping("/auth")
public class AuthController {

    private static final Logger classLogger = LoggerFactory.getLogger(AuthController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private BetService betService;

    @Autowired
    private Configuration conf;

    @Autowired
    private MailSender mailSender;

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ResponseEntity<String> login(@RequestBody UserLogin userLogin)
            throws ResourceNotFoundException {

        classLogger.debug("Inside login method: ", userLogin.toString());
        if (userLogin.getUserMail() == null || userLogin.getUserMail().trim().isEmpty()) {
            throw new IllegalArgumentException("login username can't be empty");
        }
        if (userLogin.getPassword() == null || userLogin.getPassword().trim().isEmpty()) {
            throw new IllegalArgumentException("login password can't be empty");
        }
        // Check that user had confirmed his account
        if (!userService.isUserVerified(userLogin.getUserMail())) {
            return new ResponseEntity<>("{\"message\": \"verify\"}", HttpStatus.UNAUTHORIZED);
        }
        if (userService.verifyUserPass(userLogin.getUserMail(), userLogin.getPassword())) {
            User user = userService.findByEmail(userLogin.getUserMail());

            // Check user have all the needed bets
            UserClient uc = new UserClient();
            uc.setId(user.getId());

            // Checking user isn't a facebook user
            if (user.getFacebookId() != null && !user.getFacebookId().isEmpty()) {
                classLogger.warn(Const.securityMarker, "User: {} is trying to login with regsitered user instead of his facebook like first time", user.getId());
                return new ResponseEntity<>("{\"message\": \"facebook_user\"}", HttpStatus.UNAUTHORIZED);
            }

            String token = Jwts.builder().setSubject(user.getId()).setIssuedAt(new Date())
                    .signWith(SignatureAlgorithm.HS256, conf.getSecurityKey()).compact();

            String adminStr ="";
            if (user.getRole() != null && user.getRole().equals(Const.ROLE_ADMIN)) {
                adminStr = "\",\"role\": \"" + Const.ROLE_ADMIN;
            }

            String phoneStr = "";
            if (user.getPhone() != null)
                phoneStr = "\",\"phone\": \"" + user.getPhone();

            return new ResponseEntity<>("{\"token\": \"" + token + "\",\"userId\": \"" + user.getId() + phoneStr + adminStr + "\"}", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
        }
    }

    @RequestMapping(value = "/verify", method = RequestMethod.GET)
    public ResponseEntity verifyAccount(@RequestParam String verification)
            throws ResourceNotFoundException {
        UserClient confirmedUser = userService.confirmUser(verification);
        if (confirmedUser != null) {
            return new ResponseEntity<>(null, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }

    }

    @RequestMapping(value = "/reset", method = RequestMethod.GET)
    public ResponseEntity<String> resetPassword(@RequestParam String userMail)
            throws ResourceNotFoundException, ForbiddenException, ConflictException {
        User user = userService.findByEmail(userMail);

        // Check for FB User
        // TODO: Temporary hack - FB user from app can reset his password and change his user to normal login (without FB)
        if (user.getFacebookId() != null) {
//            classLogger.warn(Const.securityMarker, "User: {} is trying to reset his password instead of his facebook", user.getId());
//            throw new ForbiddenException("User is trying to reset his password instead of his facebook");
            classLogger.info("User: {} will be registered instead of FB", user.getId());
        }

        // Check if user need to confirm his account
        if (user.getConfirmationId() != null) {
            classLogger.warn(Const.securityMarker, "User: {} is trying to reset his password before confirmation", user.getId());
            throw new ConflictException("User is trying to reset his password before confirmation");
        }

        // Check if he didnt sent mail last 30 min.
        Duration dur = Duration.ofMinutes(30);
        if (user.getLastResetPasswordSent() != null) {
            dur = Duration.between(user.getLastResetPasswordSent().toLocalDateTime(), LocalDateTime.now());
        }

        if (dur.toMinutes() >= 30)
            userService.sendResetPasswordMail(user);
        else
            return new ResponseEntity<>("{\"message\": \"time_limit\"}", HttpStatus.OK);

        return new ResponseEntity<>("{\"message\": \"sent\"}", HttpStatus.OK);
    }

    public AuthController() {
        super();
    }

    @RequestMapping(value = "/reset", method = RequestMethod.PUT)
    public ResponseEntity<String> resetPasswordActivation(@RequestBody UserResetPassword userResetPassword)
            throws ResourceNotFoundException {
        User user = userService.findByResetPasswordId(userResetPassword.getResetPasswordId());

        // Update user with password and confirmation id null
        userService.resetPassword(user, userResetPassword.getNewPassword());

        return new ResponseEntity<>("{\"message\": \"reset\"}", HttpStatus.OK);
    }

    @RequestMapping(value = "/facebook", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getFacebookURL() {

        String fbUrl = "https://www.facebook.com/dialog/oauth?client_id="
                + conf.getFacebookAppId() + "&redirect_uri=" + conf.getFacebookRedirectUrl() + "&scope=email";

        return new ResponseEntity<>("{\"facebookUrl\": \"" + fbUrl + "\"}", HttpStatus.OK);
    }

    @RequestMapping(value = "/facebook", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> callbackFromFacebook(@RequestBody UserAccessToken accessToken) throws ResourceNotFoundException {

        classLogger.trace("Facebook callback");

        // Get access token for FB API from client
        String fbAccessToken = accessToken.getAccessToken();
        if ((fbAccessToken == null) || fbAccessToken.equals("") || (fbAccessToken.startsWith("{"))) {
            classLogger.warn(Const.securityMarker, "Got invalid facebook access token: {}", fbAccessToken);
            return new ResponseEntity<>("{\"message\": \"fb_connect_error\"}", HttpStatus.UNAUTHORIZED);
        }

        // Check if its first time login or other
        JSONObject fbGraph = getValidatedFBGraph(fbAccessToken);
        if (fbGraph == null) {
            classLogger.warn(Const.securityMarker, "Got invalid facebook graph data: {}", fbGraph);
            return new ResponseEntity<>("{\"message\": \"fb_connect_error\"}", HttpStatus.UNAUTHORIZED);
        }

        UserClient fbUserClient = null;
        String adminStr ="";
        try {
            User existingUser = userService.findByFacebookId(fbGraph.getString("id"));
            fbUserClient = userService.getUserClient(existingUser);

            if (existingUser.getRole() != null && existingUser.getRole().equals(Const.ROLE_ADMIN)) {
                adminStr = "\",\"role\": \"" + Const.ROLE_ADMIN;
            }
        } catch (ResourceNotFoundException ex) {
            UserClient userClient = new UserClient();
            userClient.setId(null);

            if (fbGraph.has("email"))
                userClient.setEmail(fbGraph.getString("email"));
            else // Generate email with id -- just to keep field not null
                userClient.setEmail(fbGraph.getString("id") + "@mt-facebook.com");

            userClient.setFacebookId(fbGraph.getString("id"));
            userClient.setFirstName(fbGraph.getString("first_name"));
            userClient.setLastName(fbGraph.getString("last_name"));
            userClient.setPassword("defaultpassword");
            userClient.setRegistrationDate(new Timestamp(new Date().getTime()));
            userClient.setUserPic("http://graph.facebook.com/" + fbGraph.getString("id") + ",/picture"); // TODO: Get his profile pic
            userClient.setPhone(""); // TODO: Check for phone from FB
            fbUserClient = userService.registerNewUser(userClient, true);
        } finally {
            if (fbUserClient == null) {
                classLogger.warn(Const.securityMarker, "Cannot get user for this facebook login session: {}", fbGraph.toString());
                return new ResponseEntity<>("{\"message\": \"fb_connect_internal_user_error\"}", HttpStatus.UNAUTHORIZED);
            }
        }

        // Add to JWT Token the FB access token
        Claims claims = Jwts.claims();
        claims.setSubject(fbUserClient.getId());
        claims.put("fbAccessToken", fbAccessToken);

        String token = Jwts.builder().setClaims(claims).setIssuedAt(new Date())
                .signWith(SignatureAlgorithm.HS256, conf.getSecurityKey()).compact();

        return new ResponseEntity<>("{\"token\": \"" + token + "\", \"userId\": \"" + fbUserClient.getId() + adminStr + "\"}", HttpStatus.OK);
    }

    private JSONObject getValidatedFBGraph(String accessToken) {
        String graph = null;
        JSONObject fbGraph = null;

        try {

            String g = "https://graph.facebook.com/me?fields=id,email,first_name,last_name,picture.type(large)&access_token=" + accessToken;
            URL u = new URL(g);
            URLConnection c = u.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    c.getInputStream()));
            String inputLine;
            StringBuffer b = new StringBuffer();
            while ((inputLine = in.readLine()) != null)
                b.append(inputLine + "\n");
            in.close();
            graph = b.toString();
            System.out.println(graph);
        } catch (Exception ex) {
            classLogger.warn(Const.securityMarker, "Error while reading graph data response from facebook: {}", ex);
            return fbGraph;
        }


        // Check graph object is not null or empty and check for necessary fields
        if ((graph == null) || (graph.equals(""))) {
            classLogger.warn(Const.securityMarker, "Error while reading graph data response from facebook: {}", graph);
            return fbGraph;
        } else {
            fbGraph = new JSONObject(graph);

            if (!fbGraph.has("id") || !fbGraph.has("first_name") || !fbGraph.has("last_name")) {
                classLogger.warn(Const.securityMarker, "Facebook graph data response doesn't contains necessary fields: {}", fbGraph);
                return null;
            }
        }

        return fbGraph;
    }

    // Create new user
    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<UserClient> createUser(@RequestBody UserClient userClient, UriComponentsBuilder ucBuilder)
            throws ConflictException, ResourceNotFoundException {
        classLogger.trace("Creating new user with email: {}", userClient.getEmail());

        User user = null;
        try {
            user = userService.findByEmail(userClient.getEmail());
        } catch (ResourceNotFoundException ex) { }

        if ((user == null) &&
                (userClient.getPhone() != null) &&
                (!userClient.getPhone().isEmpty())) {
            try {
                user = userService.findByPhone(userClient.getPhone());
            } catch (ResourceNotFoundException ex) { }
        }

        if (user != null) {
            classLogger.warn(Const.securityMarker, "Trying to create a user with a registered mail: {}", userClient.toString());
            throw new ConflictException("User is already registered");
        }

        // Prevent injections
        userClient.setId(null); // When creating new user id must be null
        userClient.setRegistrationDate(new Timestamp(new Date().getTime()));
        userClient.setFacebookId(null);
        userClient.setUserPic(null);
        validateUserClient(userClient);

        // Create user
        UserClient resUserClient = userService.registerNewUser(userClient, false);

        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/user/{userId}").buildAndExpand(userClient.getId()).toUri());
        return new ResponseEntity<>(resUserClient, headers, HttpStatus.CREATED);
    }

    // Resend confirmation mail
    @RequestMapping(value = "/resend", method = RequestMethod.POST)
    public ResponseEntity<String> resendConfirmationMail(@RequestBody String userMail)
            throws ResourceNotFoundException {
        classLogger.trace("User request mail resend: {}", userMail);

        User user = userService.findByEmail(userMail);
        if (user.getConfirmationId() == null) {
            classLogger.warn(Const.securityMarker, "Someone tried to resend confirmation to a confirmed account: {}",
                    userMail);
            return new ResponseEntity<>("", HttpStatus.NOT_FOUND);
        }
        Integer mailsSentCount = user.getMailsSentCount();

        Date canResendFrom = null;
        if (user.getLastMailSent() instanceof Date) {
            canResendFrom = new Date(user.getLastMailSent().getTime() + (4 * 60 * 60 * 1000));
        }

        // TODO: Check if mail is bounce via amazon service
        /*if (mailsSentCount == 0) { // if we fail to send mail to this address we wont retry.
            classLogger.debug("Mail failed to send before, we wont retry.");
            return new ResponseEntity<>(this.JSONizere("message", "mail_send_fail"), HttpStatus.BAD_REQUEST);
        } else*/ if (mailsSentCount >= 3) { // If we already sent confirmation 3 times to that address we wont try again.
            return new ResponseEntity<>(this.JSONizere("message", "maximum_attempts_reached"), HttpStatus.BAD_REQUEST);
        } else if (canResendFrom != null && new Date().compareTo(canResendFrom) < 0) { // If last mail was sent less then 4 hours ago, we wont retry. todo: check last mail send more then 24hours
            classLogger.debug("Last mail was sent less then 4 hours ago.");
            return new ResponseEntity<>(this.JSONizere("message", "minimum_wait_time_not_passed"), HttpStatus.BAD_REQUEST);
        }

        // Try to resend mail
        user = userService.sendConfirmationMail(user);
        if (mailsSentCount == user.getMailsSentCount()) {
            // We fail to send the mail.
            return new ResponseEntity<>(this.JSONizere("message", "mail_send_fail"), HttpStatus.BAD_REQUEST);
        } else {
            return new ResponseEntity<>("", HttpStatus.OK);
        }
    }

    private String JSONizere(String field, String value) {
        return ("{\"" + field + "\": \"" + value + "\"}");
    }

    private void validateUserClient(UserClient userClient) throws IllegalArgumentException {
        if (userClient.getFirstName() == null || userClient.getFirstName().trim().isEmpty()) {
            classLogger.warn(Const.securityMarker, "Trying to create a user with empty first name: {}", userClient.toString());
            throw new IllegalArgumentException("User with empty first name");
        }
        if (userClient.getLastName() == null || userClient.getLastName().trim().isEmpty()) {
            classLogger.warn(Const.securityMarker, "Trying to create a user with empty last name: {}", userClient.toString());
            throw new IllegalArgumentException("User with empty last name");
        }
        if (userClient.getEmail() == null || userClient.getEmail().trim().isEmpty()) {
            classLogger.warn(Const.securityMarker, "Trying to create a user with empty email: {}", userClient.toString());
            throw new IllegalArgumentException("User with empty email");
        }
    }
}