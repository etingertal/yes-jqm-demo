package com.sofuit.matayeled.bet;

import com.sofuit.matayeled.config.IdentityService;
import com.sofuit.matayeled.exceptions.ForbiddenException;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.game.Game;
import com.sofuit.matayeled.game.GameService;
import com.sofuit.matayeled.group.GroupService;
import com.sofuit.matayeled.model.UserGroupStatsBet;
import com.sofuit.matayeled.stat.UserGroupStatsClient;
import com.sofuit.matayeled.stat.UserGroupStatsService;
import com.sofuit.matayeled.user.User;
import com.sofuit.matayeled.user.UserScoreService;
import com.sofuit.matayeled.user.UserService;
import com.sofuit.matayeled.utilities.Const;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Created by etingertal on 4/12/16.
 */
@RestController
@RequestMapping("/api/bets")
public class BetController {

    private static final Logger classLogger = LoggerFactory.getLogger(BetController.class);

    @Autowired
    BetService betService;

    @Autowired
    GroupService groupService;

    @Autowired
    GameService gameService;

    @Autowired
    UserService userService;

    @Autowired
    UserScoreService userScoreService;

    @Autowired
    UserGroupStatsService userGroupStatsService;

    @RequestMapping(value = "/{gameId}", method = RequestMethod.POST)
    public ResponseEntity<BetClient> updateUserBet(@PathVariable("gameId") String gameId, @RequestBody BetClient betClient)
        throws ResourceNotFoundException, ForbiddenException {
        String userId = IdentityService.getUser();
        classLogger.trace("User: {} is updating or creating bet for game {}", userId, gameId);

        if (!(betClient.getTeam1Score() != null && betClient.getTeam1Score() >= 0 && betClient.getTeam1Score() <= 10 &&
                betClient.getTeam2Score() != null && betClient.getTeam2Score() >= 0 && betClient.getTeam2Score() <= 10)) {
            classLogger.warn(Const.securityMarker, "User: {} tried to update his bet with invalid score", userId);
            throw new ForbiddenException("User tried to update his bet with invalid score.");
        }

        // Check the game is in the future
        Game game = gameService.findById(gameId);

        if (game.getStartTime().toLocalDateTime().isBefore(LocalDateTime.now())) {
            classLogger.warn(Const.securityMarker, "User: {} tried to update his bet for a past game: {}", userId, gameId);
            throw new ForbiddenException("User tried to update his bet for a game in the past.");
        }

        User user = userService.findById(userId);
        BetClient updatedBet = betService.updateBet(betClient, game, user);

        return new ResponseEntity<>(updatedBet, HttpStatus.OK);
    }

    // Get group bets
    @RequestMapping(value = "/{groupId}/{gameId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<UserGroupStatsBet>> getGroupBetsForGame(@PathVariable("groupId") String groupId,
                                                                       @PathVariable("gameId") String gameId,
                                                                       @RequestParam int page)
            throws ResourceNotFoundException, ForbiddenException {
        classLogger.trace("User: {} is fetching group: {}  user bets, for game: {}",
                new Object[] { IdentityService.getUser(), groupId, gameId });

        // ** Disable this check -- Clutch requirement **
        // Check that user is in the group or group is public
//        if (!groupService.isUserInGroup(IdentityService.getUser(), groupId) && !groupService.isGroupPublic(groupId)) {
//            classLogger.warn(Const.securityMarker, "User: {} tried to get bets for a group he's not in: {}",
//                    IdentityService.getUser(), groupId);
//            throw new ForbiddenException("User tried to get bets for group he's not in.");
//        }

        // Check that game has started
        if (!gameService.isGameStarted(gameId)) {
            classLogger.warn(Const.securityMarker, "User: {} tried to get bets for a game that hasn't started: {}",
                    gameId);
            throw new ForbiddenException("User tried to get bets for a game that hasn't started");
        }

        List<UserGroupStatsBet> groupResult = new ArrayList<>();
        Pageable pageable = new PageRequest(page,Const.USERS_PER_PAGE);
        List<UserGroupStatsClient> stats = groupService.getGroupStats(pageable, groupId);
        Game game = gameService.findById(gameId);

        for (UserGroupStatsClient stat : stats) {
            User user = userService.findById(stat.getUserId());
            Optional<Bet> bet = betService.findByUserAndGame(user, game);

            BetClient betClient = null;
            if (bet.isPresent())
                betClient = new BetClient(bet.get());


            groupResult.add(new UserGroupStatsBet(stat, betClient));
        }

        return new ResponseEntity<>(groupResult, HttpStatus.OK);
    }

    // Get user bets for specific game
    @RequestMapping(value = "/{gameId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserGroupStatsBet> getUserBetsForGame(@PathVariable("gameId") String gameId)
            throws ResourceNotFoundException, ForbiddenException {
        classLogger.trace("User: {} is fetching his bets, for game: {}",
                new Object[] { IdentityService.getUser(), gameId });

        User user = userService.findById(IdentityService.getUser());
        Game game = gameService.findById(gameId);

        UserGroupStatsBet userResult = new UserGroupStatsBet();

        // Get user bet
        Optional<Bet> bet = betService.findByUserAndGame(user, game);
        if (bet.isPresent())
            userResult.setBet(new BetClient(bet.get()));
        else
            throw new ResourceNotFoundException("no bet found");

        // Generate temp stat for user
        int historyFinishedGamesCount = gameService.getCalculatedGamesCount();
        historyFinishedGamesCount =
                (historyFinishedGamesCount == 0) ? 1 : historyFinishedGamesCount; // So we wont devide by zero!
        UserGroupStatsClient stat = userGroupStatsService.getOverallUserGroupStatsClient(user, historyFinishedGamesCount);
        userResult.setStat(stat);

        return new ResponseEntity<>(userResult, HttpStatus.OK);
    }

    // Get user bets for specific game
    @RequestMapping(value = "/last", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BetClient> getUserLastGameBet() throws ResourceNotFoundException {
        String userId = IdentityService.getUser();
        User user = userService.findById(userId);

        Game lastGame = gameService.getLastGame();
        Optional<Bet> lastBet = betService.findByUserAndGame(user, lastGame);
        BetClient betClient = null;

        if (lastBet.isPresent())
            betClient = new BetClient(lastBet.get());

        return new ResponseEntity<>(betClient, HttpStatus.OK);
    }
}
