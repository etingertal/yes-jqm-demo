package com.sofuit.matayeled.stat;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.user.User;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Created by osher on 7/4/16.
 */
@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Entity
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class UserGroupStats {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @NonNull
    @ManyToOne(fetch=FetchType.LAZY)
    private User user;

    @NonNull
    @ManyToOne(fetch=FetchType.LAZY)
    private Group group;

    private Integer gameReduce = 0;

    private Integer scoreReduce = 0;

    private Integer bullseyeReduce = 0;

    private Integer hitsReduce = 0;

    @Transient
    private Integer score = 0;

    @Transient
    private Integer hitsRatio = 0;

    @Transient
    private Integer bullseye = 0;

    public UserGroupStats(String id, User user, Group group,Integer calcedScore,
                          Integer calcedHitsRatio, Integer calcedBullseye) {
        this.id = id;
        this.user = user;
        this.group = group;
        this.score = calcedScore;
        this.hitsRatio = calcedHitsRatio;
        this.bullseye = calcedBullseye;
    }
}
