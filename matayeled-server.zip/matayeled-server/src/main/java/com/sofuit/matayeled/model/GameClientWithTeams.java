package com.sofuit.matayeled.model;

import com.sofuit.matayeled.game.Game;
import com.sofuit.matayeled.game.GameClient;
import com.sofuit.matayeled.team.Team;
import lombok.Data;

/**
 * Created by etingertal on 6/7/16.
 */
@Data
public class GameClientWithTeams {

    private GameClient game;
    private Team team1;
    private Team team2;

    public GameClientWithTeams(Game game, Team team1, Team team2) {
        this.game = new GameClient(game);
        this.setTeam1(team1);
        this.setTeam2(team2);
    }

    public void setTeam1(Team team) {
        if (team != null) {
            this.team1 = new Team();
            this.team1.setId(team.getId());
            this.team1.setName(team.getName());
            this.team1.setPic(team.getPic());
        }
    }

    public void setTeam2(Team team) {
        if (team != null) {
            this.team2 = new Team();
            this.team2.setId(team.getId());
            this.team2.setName(team.getName());
            this.team2.setPic(team.getPic());
        }
    }
}


