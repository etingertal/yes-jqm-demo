package com.sofuit.matayeled.model;

import lombok.Data;

/**
 * Created by etingertal on 6/28/16.
 */
@Data
public class GameTeamsStats {

    GameClientWithTeams gameClientWithTeams;
    Integer totalBets;
    Integer team1BetsCount;
    Integer team2BetsCount;
    Integer totalBullsEyes;
}
