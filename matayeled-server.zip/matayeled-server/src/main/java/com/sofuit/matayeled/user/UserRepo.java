package com.sofuit.matayeled.user;

import com.sofuit.matayeled.scorer.Scorer;
import com.sofuit.matayeled.team.Team;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

/**
 * Created by etingertal on 4/10/16.
 */
public interface UserRepo extends CrudRepository<User, String> {

    Optional<User> findById(String userId);
    Optional<User> findByEmail(String email);
    Optional<User> findByPhone(String phone);
    Optional<User> findByConfirmationId(String confirmationId);
    Integer countByRegistrationDateGreaterThanEqual(Timestamp date);
    Optional<User> findByResetPasswordId(String resetPasswordId);
    List<User> findTop30ByFullNameLike(String fullName);
    Optional<User> findByFacebookId(String facebookId);
    List<User> findByConfirmationIdNotNull(); // TODO: DELETE AFTER
    List<User> findByWinningTeam(Team team);
    List<User> findByTopScorer(Scorer scorer);
    List<User> findByRegistrationDateLessThanAndTopScorerIsNullAndWinningTeamIsNull(Timestamp currentDate);
    List<User> findByTopScorerIsNullOrWinningTeamIsNull();

    @Query( value = "SELECT (" +
            "  SELECT COUNT(id)" +
            "  FROM UserScore AS u2" +
            "  WHERE u2.totalScore > u1.totalScore" +
            "  or u2.totalScore = u1.totalScore and u2.totalHits / (:historyFinishedGamesCount-u2.missedGames) > u1.totalHits / (:historyFinishedGamesCount-u1.missedGames)" +
            "  or u2.totalScore = u1.totalScore and u2.totalHits / (:historyFinishedGamesCount-u2.missedGames) = u1.totalHits / (:historyFinishedGamesCount-u1.missedGames) and u2.totalBullsEye > u1.totalBullsEye" +
            ")+1 AS rank " +
            "FROM UserScore AS u1 " +
            "where u1.id=:userId")
    Long getUserRank(@Param("userId") String userId, @Param("historyFinishedGamesCount") int historyFinishedGamesCount);

//    @Modifying
//    @Transactional
//    @Query("delete from User u where u.confirmationId is not null and registrationDate < CURDATE() - INTERVAL :days DAY")
//    void deleteUnconfirmedAccounts(@Param("days") int days);
}
