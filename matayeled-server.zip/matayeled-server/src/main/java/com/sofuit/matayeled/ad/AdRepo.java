package com.sofuit.matayeled.ad;

import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

/**
 * Created by etingertal on 6/17/16.
 */
public interface AdRepo extends CrudRepository<Ad, String> {

    Optional<Ad> findById(String id);

    List<Ad> findByTypeAndIsActive(String type, Boolean isActive);
}
