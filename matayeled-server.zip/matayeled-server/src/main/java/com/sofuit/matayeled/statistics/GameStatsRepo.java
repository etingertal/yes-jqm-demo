package com.sofuit.matayeled.statistics;

import com.sofuit.matayeled.game.Game;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface GameStatsRepo  extends CrudRepository<GameStats, String> {
    GameStats findTopByOrderByUpdateTimeDesc();
    GameStats findByGame(Game game);
    List<GameStats> findByOrderByUpdateTimeAsc();
}
