package com.sofuit.matayeled.benefit;

import com.sofuit.matayeled.exceptions.ForbiddenException;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/benefits")
public class BenefitController {

    private static final Logger classLogger = LoggerFactory.getLogger(BenefitController.class);

    @Autowired
    BenefitService benefitService;

    @RequestMapping(value = "", method = RequestMethod.GET)
    public ResponseEntity<List<BenefitClient>> getAllBenefits() {

        List<BenefitClient> benefitClients = new ArrayList<>();
        List<Benefit> benefits = benefitService.findAll();

        for (Benefit benefit : benefits) {
            BenefitClient bc = new BenefitClient(benefit);
            benefitClients.add(bc);
        }

        return new ResponseEntity<>(benefitClients, HttpStatus.OK);
    }

    @RequestMapping(value = "/redirect/{id}", method = RequestMethod.GET)
    public ResponseEntity<String> goToBenefit(@PathVariable("id") String id, HttpServletResponse response)
            throws ResourceNotFoundException, ForbiddenException, IOException {
        Benefit benefit = benefitService.findById(id);
        benefitService.addOneClick(benefit);

        return new ResponseEntity<>("{\"benefitId\": " + id + "}", HttpStatus.OK);
    }
}
