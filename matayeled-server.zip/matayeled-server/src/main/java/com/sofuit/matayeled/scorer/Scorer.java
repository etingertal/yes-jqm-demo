package com.sofuit.matayeled.scorer;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OrderBy;

/**
 * Created by osher on 7/4/16.
 */
@Data
@Entity
public class Scorer {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    @OrderBy("score asc")
    private String id;

    private String name;

    private String team;

    private String picUrl;

    private boolean isTopScorer = false;

    private Integer points;
}
