package com.sofuit.matayeled.model;

import com.sofuit.matayeled.group.GroupClient;
import com.sofuit.matayeled.scorer.Scorer;
import com.sofuit.matayeled.team.Team;
import com.sofuit.matayeled.user.UserClient;
import lombok.Data;

import java.sql.Timestamp;
import java.util.List;

/**
 * Created by etingertal on 4/15/16.
 */
@Data
public class UserProfile {

    private UserClient user;
    private List<GroupClient> groups;
    private List<GameWithUserBet> gamesWithBets;
    private Team winningTeam;
    private Scorer topScorer;
    private Timestamp startTime;

    public void setWinningTeam(Team team) {

        if (team != null) {
            this.winningTeam = new Team();
            this.winningTeam.setId(team.getId());
            this.winningTeam.setName(team.getName());
            this.winningTeam.setPic(team.getPic());
        } else
            this.winningTeam = null;
    }

    public void setTopScorer(Scorer scorer) {

        if (scorer != null) {
            this.topScorer = new Scorer();
            this.topScorer.setId(scorer.getId());
            this.topScorer.setPicUrl(scorer.getPicUrl());
            this.topScorer.setName(scorer.getName());
            this.topScorer.setTeam(scorer.getTeam());
        } else
            this.topScorer = null;
    }
}
