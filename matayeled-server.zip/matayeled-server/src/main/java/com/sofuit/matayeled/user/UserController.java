package com.sofuit.matayeled.user;

import com.sofuit.matayeled.bet.Bet;
import com.sofuit.matayeled.bet.BetClient;
import com.sofuit.matayeled.bet.BetService;
import com.sofuit.matayeled.config.IdentityService;
import com.sofuit.matayeled.exceptions.ForbiddenException;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.game.Game;
import com.sofuit.matayeled.game.GameClient;
import com.sofuit.matayeled.game.GameService;
import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.group.GroupClient;
import com.sofuit.matayeled.group.GroupService;
import com.sofuit.matayeled.model.GameWithUserBet;
import com.sofuit.matayeled.model.LightUser;
import com.sofuit.matayeled.model.UserProfile;
import com.sofuit.matayeled.model.UserTopScorerAndWinningTeam;
import com.sofuit.matayeled.scorer.Scorer;
import com.sofuit.matayeled.scorer.ScorerService;
import com.sofuit.matayeled.stat.UserGroupStatsClient;
import com.sofuit.matayeled.stat.UserGroupStatsService;
import com.sofuit.matayeled.team.Team;
import com.sofuit.matayeled.team.TeamService;
import com.sofuit.matayeled.utilities.Const;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Created by etingertal on 4/10/16.
 */
@RestController
@RequestMapping("/api/users")
public class UserController {

    private static final Logger classLogger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    UserService userService;

    @Autowired
    GroupService groupService;

    @Autowired
    GameService gameService;

    @Autowired
    BetService betService;

    @Autowired
    TeamService teamService;

    @Autowired
    ScorerService scorerService;

    @Autowired
    UserGroupStatsService userGroupStatsService;

    // Get my user
    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserClient> getMyUser(@Value("#{request.getAttribute('subject')}") String userId)
            throws ResourceNotFoundException {

        return this.getUser(userId);
    }

    // Get specific user
    @RequestMapping(value = "/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserClient> getUser(@PathVariable("userId") String userId) throws ResourceNotFoundException {
        // TODO: get user for log
        classLogger.trace("User: {} is fetching user with id: {}", "user", userId);
        User user = userService.findById(userId);

        return new ResponseEntity<>(userService.getUserClient(user), HttpStatus.OK);
    }

    // Update user
    @RequestMapping(value = "/{userId}", method = RequestMethod.PUT)
    public ResponseEntity<UserClient> updateUser(@RequestBody UserClient userClient)
            throws ResourceNotFoundException {
        String userId = IdentityService.getUser();
        classLogger.trace("User: {} is updating user: {}", IdentityService.getUser(), userId);

        if (!userId.equals(userClient.getId())) {
            classLogger.warn(Const.securityMarker, "User: {} is messing with id's, path userId: {} object userId: {}",
                    new Object[]{"user", userId, userClient.getId()});
            throw new IllegalArgumentException("Id's miss match");
        }

        // Check phone doesn't exist
        classLogger.info("Before checking phone controller");
        if ((userClient.getPhone() != null) && (!userClient.getPhone().trim().isEmpty())
                && (!userClient.getPhone().equals("-1"))) {
            classLogger.info("Inside checking phone controller");
            User user = null;
            String idForPhone = userService.findByPhone(userClient.getPhone()).getId();
            if (idForPhone != null && !idForPhone.isEmpty() && !idForPhone.equals(userId)) {
                classLogger.warn(Const.securityMarker, "User: {} is trying to update his phone with existing one: {}",
                        new Object[]{userId, userClient.getPhone()});
                throw new IllegalArgumentException("Phone already exists");
            }

        }

        UserClient updatedUser = userService.updateUser(userClient);
        return new ResponseEntity<>(updatedUser, HttpStatus.OK);
    }

    // Update light user
//    @RequestMapping(value = "/profile", method = RequestMethod.PUT)
//    public ResponseEntity<UserClient> updateUserProfile(@RequestBody LightUser lightUser)
//            throws ResourceNotFoundException {
//        classLogger.trace("User: {} is updating his profile data", IdentityService.getUser());
//
//        User user = userService.findById(IdentityService.getUser());
//        user.setFirstName(lightUser.getFirstName());
//        user.setLastName(lightUser.getLastName());
//
//        UserClient updatedUser = userService.updateUser(new UserClient(user));;
//        return new ResponseEntity<>(updatedUser, HttpStatus.OK);
//    }

    // Update user winningTeam
    @RequestMapping(value = "/team", method = RequestMethod.PUT)
    public ResponseEntity<UserClient> updateUserWinningTeam(@RequestParam String teamId)
            throws ResourceNotFoundException, ForbiddenException {
        classLogger.trace("User: {} is updating his winning team to: {}", IdentityService.getUser(), teamId);

        User user = userService.findById(IdentityService.getUser());

        if (((gameService.getBetsLockingGame(Boolean.TRUE).getStartTime().toLocalDateTime().isAfter(LocalDateTime.now()))) &&
                ((user.getWinningTeam() == null) || (user.getTopScorer() == null))) {
            // Temp allow update if scorer is null
        } else {
            // Check that the user set the bet before the first game (after his registeration) start
            if ((gameService.getUserFirstLockingGame(user).getStartTime().toLocalDateTime()
                    .isBefore(LocalDateTime.now())) ||
                    (gameService.getBetsLockingGame(Boolean.TRUE).getStartTime().toLocalDateTime()
                            .isBefore(LocalDateTime.now()))) {
                classLogger.warn(Const.securityMarker, "User: {} is trying to update winning team after tournament started: {}",
                        new Object[]{IdentityService.getUser(), teamId});
                throw new ForbiddenException("Trying to update winning team after tournament started");
            }
        }

        // Get user & team, will fly if not found
        Team team = teamService.findById(teamId);

        user.setWinningTeam(team);

        UserClient updatedUser = userService.updateUser(userService.getUserClient(user));;
        return new ResponseEntity<>(updatedUser, HttpStatus.OK);
    }

    // Update user topScorer
    @RequestMapping(value = "/scorer", method = RequestMethod.PUT)
    public ResponseEntity<UserClient> updateUserTopScorer(@RequestParam String scorerId)
            throws ResourceNotFoundException, ForbiddenException {
        classLogger.trace("User: {} is updating his top scorer to: {}", IdentityService.getUser(), scorerId);

        User user = userService.findById(IdentityService.getUser());

        if (((gameService.getBetsLockingGame(Boolean.TRUE).getStartTime().toLocalDateTime().isAfter(LocalDateTime.now()))) &&
                ((user.getWinningTeam() == null) || (user.getTopScorer() == null))) {
            // Temp allow update if scorer is null
        } else {
            // Check that the user set the bet before the first game (after his registeration) start
            if ((gameService.getUserFirstLockingGame(user).getStartTime().toLocalDateTime()
                    .isBefore(LocalDateTime.now())) ||
                    (gameService.getBetsLockingGame(Boolean.TRUE).getStartTime().toLocalDateTime()
                            .isBefore(LocalDateTime.now()))) {
                classLogger.warn(Const.securityMarker, "User: {} is trying to update top scorer after tournament started: {}",
                        new Object[]{IdentityService.getUser(), scorerId});
                throw new ForbiddenException("Trying to update top scorer after tournament started");
            }
        }

        // Get user & scorer, will fly if not found

        Scorer scorer = scorerService.findById(scorerId);

        user.setTopScorer(scorer);

        UserClient updatedUser = userService.updateUser(userService.getUserClient(user));;
        return new ResponseEntity<>(updatedUser, HttpStatus.OK);
    }

    // Search users
    @RequestMapping(value = "/search/{fullName}", method = RequestMethod.GET)
    public ResponseEntity<List<LightUser>> searchUsers(@PathVariable("fullName") String fullName) {
        String userId = IdentityService.getUser();
        classLogger.trace("User: {} is searching for: {}", userId, fullName);

        return new ResponseEntity<>(userService.findByFullName(fullName), HttpStatus.OK);
    }

    // Search users
    @RequestMapping(value = "/rank/{userId}", method = RequestMethod.GET)
    public ResponseEntity<String> getUserRank(@PathVariable("userId") String userId) {
        classLogger.trace("User: {} is getting his rank", userId);

        int historyFinishedGamesCount = gameService.getCalculatedGamesCount();
        historyFinishedGamesCount = (historyFinishedGamesCount == 0) ? 1 : historyFinishedGamesCount; // So we wont devide by zero!
        Long rank = userService.getUserRank(userId, historyFinishedGamesCount);
        Long total = userService.getTotalUsers();

        return new ResponseEntity<>("{\"rank\": \"" + rank + "\",\"total\": \"" + total + "\"}", HttpStatus.OK);
    }

    // Get user overall stats with rank (for groups like top50)
    @RequestMapping(value = "/stats", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserGroupStatsClient> getUserStats()
            throws ResourceNotFoundException {
        classLogger.trace("User: {} is fetching overall stats with rank", IdentityService.getUser());
        User user = userService.findById(IdentityService.getUser());

        int historyFinishedGamesCount = gameService.getCalculatedGamesCount();
        historyFinishedGamesCount =
                (historyFinishedGamesCount == 0) ? 1 : historyFinishedGamesCount; // So we wont devide by zero!

        UserGroupStatsClient userGroupStatsClient = userGroupStatsService.getOverallUserGroupStatsClient(user, historyFinishedGamesCount);
        Long rank = userService.getUserRank(user.getId(), historyFinishedGamesCount);
        userGroupStatsClient.setRank(rank.intValue());
        return new ResponseEntity<>(userGroupStatsClient, HttpStatus.OK);
    }

    // Profile user
    @RequestMapping(value = "/profile/{userId}", method = RequestMethod.GET)
    public ResponseEntity<UserProfile> getUserProfile(@PathVariable("userId") String userId)
            throws ResourceNotFoundException {
        String loggedInUser = IdentityService.getUser();
        classLogger.trace("User: {} is getting profile details of: {}", loggedInUser, userId);
        UserProfile userProfile = new UserProfile();

        User user = userService.findById(userId);

        // Set user details
        userProfile.setUser(userService.getUserClient(user));

        // Get profile groups and filter isPublic if necessary
        List<GroupClient> groupClients = new ArrayList<>();

        if (!userId.equals(Const.MONKEY_USER_ID)) {
            List<Group> userGroups = userService.getUserGroups(user, false);

            for (Group group : userGroups) {
                if (loggedInUser.equals(userId)) {
                    groupClients.add(new GroupClient(group));
                } else {
                    if (!group.isSecret())
                        groupClients.add(new GroupClient(group));
                    else if (groupService.isUserInGroup(loggedInUser, group.getId())) // Maybe the group is not public but I'm also a member
                        groupClients.add(new GroupClient(group));
                }
            }

            Group top50 = groupService.findById(Const.TOP_50_GROUP_ID);
            if (!userGroups.contains(top50))
                groupClients.add(0, new GroupClient(top50));
        }
        userProfile.setGroups(groupClients);

        // Get bets locking game time
        userProfile.setStartTime(gameService.getBetsLockingGame(Boolean.TRUE).getStartTime());

        userProfile.setTopScorer(user.getTopScorer());
        userProfile.setWinningTeam(user.getWinningTeam());

        List<Game> gameList;
        boolean isMyProfile = false;
        if (loggedInUser.equals(userId)) {
            gameList = gameService.getNextGames();

            isMyProfile = true;
        } else {
            gameList = gameService.getGamesHistory();
            User loggedUser = userService.findById(loggedInUser);

            // Hide general bets if I can still choose and looking in another user profile
            if (gameService.getUserFirstLockingGame(loggedUser).getStartTime().toLocalDateTime().isAfter(
                    LocalDateTime.now())) {
                userProfile.setTopScorer(null);
                userProfile.setWinningTeam(null);
            }
        }

        List<GameWithUserBet> clientGamesWithUserBets = new ArrayList<>();

        // Get first game date
        LocalDate firstLDT = null;
        if (gameList.size() > 0)
            firstLDT = gameList.get(0).getStartTime().toLocalDateTime().toLocalDate();

        for (Game game : gameList) {
            // Get only first date of games
            if ((game.getStartTime().toLocalDateTime().toLocalDate().compareTo(firstLDT) == 0) || (!isMyProfile)) {
                game.getStartTime().toLocalDateTime();
                GameWithUserBet gameWithUserBet = new GameWithUserBet();
                gameWithUserBet.setGame(new GameClient(game));

                Optional<Bet> currBet = betService.findByUserAndGame(user, game);

                if (currBet.isPresent()) {
                    BetClient betClient = new BetClient(currBet.get());

                    // Hide bets if neccesary
                    if ((currBet.get().getIsGenerated()) && (isMyProfile)) {
                        betClient.setTeam1Score(null);
                        betClient.setTeam2Score(null);
                    }

                    gameWithUserBet.setBet(betClient);
                } else {
                    gameWithUserBet.setBet(null);
                }

                gameWithUserBet.setTeam1(game.getTeam1());
                gameWithUserBet.setTeam2(game.getTeam2());
                clientGamesWithUserBets.add(gameWithUserBet);
            } else
                break;
        }
        userProfile.setGamesWithBets(clientGamesWithUserBets);

        return new ResponseEntity<>(userProfile, HttpStatus.OK);
    }

    // Get specific user
    @RequestMapping(value = "/betsData", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserTopScorerAndWinningTeam> getUserWithInitialBets() throws ResourceNotFoundException {
        String userId = IdentityService.getUser();
        classLogger.trace("User: {} is fetching user with id: {}", userId, userId);
        User user = userService.findById(userId);

        UserTopScorerAndWinningTeam userTopScorerAndWinningTeam = new UserTopScorerAndWinningTeam();
        userTopScorerAndWinningTeam.setUser(userService.getUserClient(user));
        userTopScorerAndWinningTeam.setTopScorer(user.getTopScorer());
        userTopScorerAndWinningTeam.setWinningTeam(user.getWinningTeam());

        return new ResponseEntity<>(userTopScorerAndWinningTeam, HttpStatus.OK);
    }
}
