package com.sofuit.matayeled.game;

import com.sofuit.matayeled.utilities.Const;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

/**
 * Created by etingertal on 4/15/16.
 */
@Data
@NoArgsConstructor
public class GameClient {

    private String id;
    private Integer hitScore;
    private Integer bullseyeScore;
    private Timestamp startTime;
    private Integer team1Score;
    private Integer team2Score;
    private String stageName;
    private Boolean isFinished;
    private Const.GameCalcStatus gameCalcStatus;

    public GameClient(Game game) {
        this.id = game.getId();
        this.hitScore = game.getHitScore();
        this.bullseyeScore = game.getBullseyeScore();
        this.startTime = game.getStartTime();
        this.team1Score = game.getTeam1Score();
        this.team2Score = game.getTeam2Score();
        this.stageName = game.getStageName();
        this.isFinished = game.getIsFinished();
        this.gameCalcStatus = game.getGameCalcStatus();
    }
}
