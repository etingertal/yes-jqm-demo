package com.sofuit.matayeled.group;

import com.sofuit.matayeled.stat.UserGroupStats;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.sofuit.matayeled.tournament.Tournament;
import com.sofuit.matayeled.user.User;
import com.sofuit.matayeled.utilities.Const;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.*;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

/**
 * Created by etingertal on 4/7/16.
 */

@Data
@NoArgsConstructor
@DynamicUpdate
@Entity
@Table(name="UserGroup")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Group {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @Column(length = Const.MAX_GROUP_NAME_LENGTH)
    private String name;

    @Column
    @Type(type="text")
    private String pic;

    private Timestamp openDate;

    @Column(length = Const.MAX_LEADER_STATUS_LENGTH)
    private String leaderStatus;

    @ManyToOne(fetch = FetchType.LAZY)
    private User leader;

    @ManyToOne(fetch = FetchType.LAZY)
    private User creator;

    @ManyToOne(fetch = FetchType.LAZY)
    private User manager;

    @Column(length = 1)
    private Const.GroupPrivacy privacy = Const.GroupPrivacy.VIEWABLE;

    @ManyToOne(fetch = FetchType.LAZY)
    private Tournament tournament;

    private Boolean betWinningTeam = true;

    private Boolean betTopScorer = true;

    private Boolean pointsCalcFromTournamentStart = true;

    private Integer promotionLevel = 0;

    public Group(User creator) {
        this.setOpenDate(new Timestamp(new Date().getTime()));
        this.setCreator(creator);
        this.setLeaderStatus("אני מספר 1!!");
    }

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name="UserGroupStats",
            joinColumns=
            @JoinColumn(name="group_id"),
            inverseJoinColumns=
            @JoinColumn(name="user_id")
    )
    private List<User> users;

    @OneToMany(mappedBy = "group", fetch = FetchType.LAZY)
    private List<UserGroupStats> usersStats;

    public boolean isSecret() {
        return (this.getPrivacy() == Const.GroupPrivacy.SECRET);
    }

    @Override
    public String toString() {
        return "Group{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", pic='" + pic + '\'' +
                ", openDate=" + openDate +
                ", leaderStatus='" + leaderStatus + '\'' +
                ", privacy=" + privacy +
                ", tournament=" + tournament +
                ", betWinningTeam=" + betWinningTeam +
                ", betTopScorer=" + betTopScorer +
                '}';
    }
}
