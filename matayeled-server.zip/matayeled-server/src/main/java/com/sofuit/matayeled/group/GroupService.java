package com.sofuit.matayeled.group;

import com.sofuit.matayeled.config.IdentityService;
import com.sofuit.matayeled.exceptions.ForbiddenException;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.game.GameService;
import com.sofuit.matayeled.invitation.InvitationService;
import com.sofuit.matayeled.stat.UserGroupStats;
import com.sofuit.matayeled.stat.UserGroupStatsClient;
import com.sofuit.matayeled.stat.UserGroupStatsService;
import com.sofuit.matayeled.tournament.TournamentRepo;
import com.sofuit.matayeled.user.User;
import com.sofuit.matayeled.user.UserService;
import com.sofuit.matayeled.utilities.Const;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by osher on 9/4/16.
 */
@Service
public class GroupService {

    private static final Logger classLogger = LoggerFactory.getLogger(GroupService.class);

    @Autowired
    TournamentRepo tournamentRepo;

    @Autowired
    InvitationService invitationService;

    @Autowired
    GroupRepo groupRepo;

    @Autowired
    UserService userService;

    @Autowired
    GameService gameService;

    @Autowired
    UserGroupStatsService userGroupStatsService;

    @PersistenceContext
    EntityManager entityManager;

    public GroupClient getGroupClient(String groupId) throws ResourceNotFoundException {
        return new GroupClient(this.findById(groupId));
    }

    @Transactional
    public GroupClient createGroup(GroupClient groupClient, String creatingUserId)
            throws ResourceNotFoundException, ForbiddenException {

        Group newGroup = new Group(userService.findById(creatingUserId));
        newGroup = this.updateGroupFromClientGroup(newGroup, groupClient, creatingUserId);

        // This field is set at creation and can not be updated, so its not handled in
        // update function.
        newGroup.setPointsCalcFromTournamentStart(groupClient.getPointsCalcFromTournamentStart());

        this.save(newGroup);

        // Add creating user to group
        this.addUsersToGroup(newGroup.getId(), new String[] { creatingUserId });

        // Add monkey to group
        this.addUsersToGroup(newGroup.getId(), new String[] { "monkey" });


        return new GroupClient(newGroup);
    }

    @Transactional
    public GroupClient updateGroup(GroupClient groupClient, String updatingUserId) throws ResourceNotFoundException, IllegalArgumentException {

        // Get group(if it does not exist we will fly)
        Group existingGroup = this.findById(groupClient.getId());

        existingGroup = updateGroupFromClientGroup(existingGroup, groupClient, updatingUserId);
        this.save(existingGroup);

        return new GroupClient(existingGroup);
    }

    @Transactional
    public GroupClient updateGroupPublicFields(GroupClient groupClient) throws ResourceNotFoundException, IllegalArgumentException {

        // Get group(if it does not exist we will fly)
        Group existingGroup = this.findById(groupClient.getId());

        existingGroup = updateGroupPublicFieldsFromClientGroup(existingGroup, groupClient);
        this.save(existingGroup);

        return new GroupClient(existingGroup);
    }

    @Transactional
    public GroupClient updateGroupStatus(String groupId, String newLeaderStatus) throws ResourceNotFoundException {

        // Get group(if it does not exist we will fly)
        Group existingGroup = this.findById(groupId);
        existingGroup.setLeaderStatus(newLeaderStatus);
        this.save(existingGroup);
        return new GroupClient(existingGroup);
    }

    @Transactional
    public List<UserGroupStatsClient> getGroupStats(Pageable pageable, String groupId) throws ResourceNotFoundException {
        // Check if we need to show scorer & winning team bets to this user
        User user = userService.findById(IdentityService.getUser());

        boolean showBets = false;
        if (gameService.getUserFirstLockingGame(user).getStartTime().toLocalDateTime().isBefore(LocalDateTime.now()))
            showBets = true;

        return userGroupStatsService.getOrderedGroupStats(groupId, pageable, showBets);
    }

    @Transactional
    public GroupClient addUsersToGroup(String groupId, String[] users) throws ResourceNotFoundException,
                                                                                ForbiddenException {
        Group group = this.findById(groupId);

        for (String userId : users) {
            User user = userService.findById(userId);
            userGroupStatsService.createUserGroupStat(user, group);
        }

        // calc group leader
        group = this.findAndSetLeader(group);

        return (new GroupClient(group));
    }

    @Transactional
    public GroupClient removeUsersFromGroup(String groupId, String[] users) throws ResourceNotFoundException{
        Group group = this.findById(groupId);

        for (String userId : users) {
            if(userId.equals(Const.MONKEY_USER_ID)) {
                continue;
            }
            if (group.getManager() != null && group.getManager().getId() != null &&
                    userId.equals(group.getManager().getId())) {
                group.setManager(null);
                group.setCreator(userService.findById(Const.MONKEY_USER_ID));
                groupRepo.save(group);
            }
            User user = userService.findById(userId);
            userGroupStatsService.removeUserGroupStat(user, group);
        }

        // calc group leader
        group = this.findAndSetLeader(group);

        return (new GroupClient(group));
    }

    @Transactional
    public void deleteGroup(String groupId) throws ResourceNotFoundException {
        Group toDelete = this.findById(groupId);

        // We need to copy the array because removeUserGroupStat changes the getUsersStats
        // which will create concurrent modification exception if we run on it.
        ArrayList<UserGroupStats> copy = new ArrayList<> (toDelete.getUsersStats());
        // Delete stats if there are any.
//        for (UserGroupStats ugs : copy) {
//            userGroupStatsService.removeUserGroupStat(ugs.getUser(), ugs.getGroup());
//        }

        // Delte invitation if exists.
        invitationService.deleteInvitation(toDelete);

        groupRepo.delete(toDelete);
    }

    public List<GroupClient> getPublicGroups(Pageable pageable, String name) throws ResourceNotFoundException {
        Page<Group> page = null;
        if (name != null && !name.isEmpty()) {
            page = groupRepo.findByPrivacyAndNameLikeOrderByPromotionLevelDesc(Const.GroupPrivacy.PUBLIC,"%" + name + "%", pageable);
        } else {
            page = groupRepo.findByPrivacyOrderByPromotionLevelDesc(Const.GroupPrivacy.PUBLIC, pageable);
        }

        List<GroupClient> result = new ArrayList<>();
        page.forEach(group -> result.add(new GroupClient(group)));
        return result;
    }

    public List<GroupClient> getUserGroups(String userId) throws ResourceNotFoundException {
        User user = userService.findById(userId);
        List<GroupClient> result = new ArrayList<>();
        userService.getUserGroups(user, false).forEach(group -> result.add(new GroupClient(group)));
        return result;
    }

    public Integer getGroupSize(String groupId) throws ResourceNotFoundException {
        Integer count=0;
        Group group = this.findById(groupId);
        if (group.getUsers() != null) {
            count = group.getUsers().size();
        }
        return count;
    }

    public boolean isUserInGroup(String userId, String groupId) throws ResourceNotFoundException {

        Group group = this.findById(groupId);
        User user = userService.findById(userId);

        return (userGroupStatsService.findByUserAndGroupIfExist(user, group) != null);
    }

    public boolean isGroupPublic(String groupId) throws ResourceNotFoundException {
        Group group = this.findById(groupId);
        return (group.getPrivacy() == Const.GroupPrivacy.PUBLIC);
    }

    public boolean isGroupSecret(String groupId) throws ResourceNotFoundException {
        Group group = this.findById(groupId);
        return group.isSecret();
    }

    public boolean isAdmin(String userId, String groupId) throws ResourceNotFoundException {
        Group group = this.findById(groupId);

        return (this.isUserInGroup(userId, groupId) && ( group.getManager() == null
                                                        || group.getManager().getId().equals(userId)));
    }

    public boolean isLeader(String userId, String groupId) throws ResourceNotFoundException {
        Group group = this.findById(groupId);
        return (group.getLeader().getId().equals(userId));
    }

    public Group save(Group group) {
        return groupRepo.save(group);
    }

    public Group findById(String groupId) throws ResourceNotFoundException {
        return groupRepo.findById(groupId).orElseThrow(() -> new ResourceNotFoundException("group id:" + groupId));
    }

    private Group updateGroupPublicFieldsFromClientGroup(Group group, GroupClient groupClient) {
        group.setName(groupClient.getName());
        group.setPic(groupClient.getPic());
        return group;
    }

    private Group updateGroupFromClientGroup(Group group, GroupClient groupClient, String userId)  throws ResourceNotFoundException {
        this.updateGroupPublicFieldsFromClientGroup(group, groupClient);
        group.setBetWinningTeam(groupClient.getBetWinningTeam());
        group.setBetTopScorer(groupClient.getBetTopScorer());

        boolean allowPrivacyChange = false;
        // If we change privacy
        if (group.getPrivacy() != groupClient.getPrivacy()) {
            // If we change to public or from public user must be the creator!
            if (group.getPrivacy() == Const.GroupPrivacy.PUBLIC ||
                groupClient.getPrivacy() == Const.GroupPrivacy.PUBLIC) {
                if (group.getCreator().getId().equals(userId)) {
                    allowPrivacyChange = true;
                } else {
                    allowPrivacyChange = false;
                }
            } else {
                allowPrivacyChange = true;
            }
        }

        if (allowPrivacyChange) {
            group.setPrivacy(groupClient.getPrivacy());
        }

        // In any case if group is public, manager must be the creator.
        if (group.getPrivacy() == Const.GroupPrivacy.PUBLIC) {
            group.setManager(group.getCreator());
        } else {
            if (groupClient.getManagerId() == null || groupClient.getManagerId().trim().isEmpty()) {
                group.setManager(null);
            } else {
                group.setManager(userService.findById(userId));
            }
        }
        group.setTournament(tournamentRepo.findOne("tournament1"));
        return group;
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public void updateGroupsLeaders()
        throws ResourceNotFoundException {

        classLogger.info("Starting Leader calculation!");
        int counter=0;
        try {
            // Get group(if it does not exist we will fly)
            Iterator<Group> groups = groupRepo.findAll().iterator();

            while (groups.hasNext()) {
                Group group = groups.next();
                findAndSetLeader(group);
                counter++;
                if (counter % 100 == 0) {
                    entityManager.flush();
                    entityManager.clear();
                    classLogger.info("Finished: {} groups.", counter);
                }

            }
        } catch (Exception e) {
            classLogger.error("Error while calcing group leaders:", e);
            throw e;
        }

        classLogger.info("Leader calculation finished");
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public Group findAndSetLeader(Group group) throws ResourceNotFoundException {

        // Get leader
        Pageable pageable = new PageRequest(0,1);
        List<UserGroupStatsClient> stat = userGroupStatsService.getOrderedGroupStats(group.getId(), pageable, false);

        if ((stat != null) && (stat.size() > 0)) {
            User user = userService.findById(stat.get(0).getUserId());
            group.setLeader(user);
            groupRepo.save(group);
        }

        return group;
    }
}
