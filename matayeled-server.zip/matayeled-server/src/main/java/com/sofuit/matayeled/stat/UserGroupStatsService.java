package com.sofuit.matayeled.stat;

import com.sofuit.matayeled.bet.Bet;
import com.sofuit.matayeled.bet.BetService;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.game.GameService;
import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.group.GroupService;
import com.sofuit.matayeled.user.*;
import com.sofuit.matayeled.utilities.Const;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Created by osher on 16/4/16.
 */
@Service
public class UserGroupStatsService {

    private static final Logger classLogger = LoggerFactory.getLogger(UserGroupStatsService.class);

    @Autowired
    UserGroupStatsRepo userGroupStatsRepo;

    @Autowired
    UserScoreRepo userScoreRepo;

    @Autowired
    GroupService groupService;

    @Autowired
    GameService gameService;

    @Autowired
    BetService betService;

    @Autowired
    UserService userService;

    @Autowired
    UserScoreService userScoreService;

    public UserGroupStats findByUserAndGroupIfExist(User user, Group group) {
        Optional<UserGroupStats> userGroupStats = userGroupStatsRepo.findByUserAndGroup(user, group);
        return userGroupStats.isPresent() ? userGroupStats.get() : null;
    }

    public List<UserGroupStatsClient> getOrderedGroupStats(String groupId, Pageable page, boolean statsWithBets) throws ResourceNotFoundException {

        Group group = groupService.findById(groupId);
        int historyFinishedGamesCount = gameService.getCalculatedGamesCount();
        historyFinishedGamesCount = (historyFinishedGamesCount == 0) ? 1 : historyFinishedGamesCount; // So we wont devide by zero!
        Page<Object[]> stats = userGroupStatsRepo.getOrderedGroupStats(group, historyFinishedGamesCount, page);
        List<UserGroupStatsClient> statsClient = new ArrayList<>();

        final boolean fstatsWithBets = statsWithBets;

        stats.forEach(stat -> statsClient.add(new UserGroupStatsClient(stat, fstatsWithBets)));
        return statsClient;
    }

    @Transactional
    public UserGroupStats createUserGroupStat(User user, Group group) {
        UserGroupStats userGroupStats = this.findByUserAndGroupIfExist(user, group);

        if (userGroupStats == null) {
            userGroupStats = new UserGroupStats(user, group);
            userGroupStats = this.calcReduce(userGroupStats);
            this.save(userGroupStats);

            ArrayList<UserGroupStats> list;
            if (group.getUsersStats() == null) {
                list = new ArrayList<>();
                group.setUsersStats(list);
            }
            group.getUsersStats().add(userGroupStats);
            groupService.save(group);
        }
        return userGroupStats;
    }

    @Transactional
    public void removeUserGroupStat(User user, Group group) {
        UserGroupStats userGroupStats = this.findByUserAndGroupIfExist(user, group);
        if (userGroupStats != null) {
            userGroupStatsRepo.delete(userGroupStats);
            group.getUsersStats().remove(userGroupStats);
        }
    }

    @Transactional
    private UserGroupStats save(UserGroupStats userGroupStats) {
        return userGroupStatsRepo.save(userGroupStats);
    }

    private UserGroupStats calcReduce(UserGroupStats userGroupStats) {

        // Group score calc start from group open date.
        if(!userGroupStats.getGroup().getPointsCalcFromTournamentStart()) {

            List<Bet> irrelevantBetsForUser = betService.getBetsByUserAndGameStartTimeLessThanEqual(
                                                userGroupStats.getUser(),
                                                userGroupStats.getGroup().getOpenDate());

            if (irrelevantBetsForUser != null && irrelevantBetsForUser.size() > 0) {

                int gameReduce = 0;
                int scoreReduce = 0;
                int hitsReduce = 0;
                int bullsEyeReduce = 0;

                for (Bet currBet : irrelevantBetsForUser) {
                    gameReduce += 1;
                    if (currBet.getScore() != 0) {
                        scoreReduce += currBet.getScore();
                        hitsReduce += 1;
                        if (currBet.getIsBullsEye()) {
                            bullsEyeReduce += 1;
                        }
                    }
                }

                userGroupStats.setGameReduce(gameReduce);
                userGroupStats.setScoreReduce(scoreReduce);
                userGroupStats.setHitsReduce(hitsReduce);
                userGroupStats.setBullseyeReduce(bullsEyeReduce);
            }
        }

        return userGroupStats;
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public void updateTop50() throws ResourceNotFoundException {

        classLogger.info("Starting Top50 calculation!");
        try {
            // Get Top50 group & remove all stats
            Group group = groupService.findById(Const.TOP_50_GROUP_ID);
            userGroupStatsRepo.deleteByGroup(group);

            // Recalc Top50
            Pageable pageable = new PageRequest(0,50);
            int historyFinishedGamesCount = gameService.getCalculatedGamesCount();
            historyFinishedGamesCount =
                    (historyFinishedGamesCount == 0) ? 1 : historyFinishedGamesCount; // So we wont devide by zero!
            Page<Object[]> top50 = userScoreRepo.getTop50(historyFinishedGamesCount, pageable);

            for (Object[] rec : top50) {
                User currUser = (User) rec[0];

                UserGroupStats userGroupStats = new UserGroupStats();
                userGroupStats.setUser(currUser);
                userGroupStats.setGroup(group);
                userGroupStatsRepo.save(userGroupStats);
            }
        } catch (Exception e) {
            classLogger.error("Error while calcing Top50:", e);
            throw e;
        }

        classLogger.info("Top50 calculation finished");
    }

    public UserGroupStatsClient getOverallUserGroupStatsClient(User user, int historyFinishedGamesCount)
        throws ResourceNotFoundException {
        // Generate temp stat for user
        UserScore userScore = userScoreService.findById(user.getId());

        UserGroupStatsClient stat = new UserGroupStatsClient();
        stat.setUserId(user.getId());
        stat.setUserFirstName(user.getFirstName());
        stat.setUserLastName(user.getLastName());
        stat.setUserPic(user.getPic());
        stat.setScore(userScore.getTotalScore());
        stat.setHitsRatio(userScore.getTotalHits() /
                historyFinishedGamesCount-userScore.getMissedGames() * 100.0);
        stat.setBullseye(userScore.getTotalBullsEye());

        if (user.getTopScorer() != null)
            stat.setTopScorerPic(user.getTopScorer().getPicUrl());
        else
            stat.setTopScorerPic(null);

        if (user.getWinningTeam() != null)
            stat.setWinningTeamPic(user.getWinningTeam().getPic());
        else
            stat.setWinningTeamPic(null);

        return stat;
    }
}
