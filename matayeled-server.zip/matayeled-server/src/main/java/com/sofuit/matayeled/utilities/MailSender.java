package com.sofuit.matayeled.utilities;

import com.sofuit.matayeled.user.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

/**
 * Created by osher on 24/4/16.
 */
@Component
@Scope("singleton")
public class MailSender {

    private static final Logger classLogger = LoggerFactory.getLogger(MailSender.class);

    @Autowired
    private Configuration conf;

    private static final String CONFIRMATION_BODY = "שלום %s!\n" +
            "ברוך הבא למשחק מהאתהילד!?\n" +
            "על מנת להשלים את הרשמתך יש ללחוץ על הקישור: %s";
    private static final String PASS_RESET_BODY = "שלום %s!\n" +
            "ביקשת לאפס את סיסמת הכניסה ל- מהאתהילד!?\n" +
            "על מנת לאפס את סיסמתך, יש ללחוץ על הקישור: %s" +
            "\n\nבמידה ולא ביקשת איפוס סיסמא, נא התעלם ממייל זה";
    private static final String CONFIRMATION_SUBJECT = "אישור הרשמה לmatayeled.co.il";
    private static final String PASS_RESET_SUBJECT = "איפוס סיסמא לmatayeled.co.il";
    private static final int PORT = 587;

    public boolean sendConfirmationMail(User user) {
        String body = String.format(CONFIRMATION_BODY, user.getFirstName() + " " + user.getLastName(),
                conf.getConfirmationLinkPrefix() + user.getConfirmationId());
        return (sendMail(user.getEmail(), CONFIRMATION_SUBJECT, body));
    }

    public void sendResetPasswordMail(User user) {
        String body = String.format(PASS_RESET_BODY, user.getFirstName() + " " + user.getLastName(),
                conf.getResetPassLinkPrefix() + user.getResetPasswordId());
        sendMail(user.getEmail(), PASS_RESET_SUBJECT, body);
    }

    public boolean sendMail(String address, String mailSubject, String mailBody)  {
        // Create a Properties object to contain connection configuration information.
        Properties props = System.getProperties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.port", PORT);

        // Set properties indicating that we want to use STARTTLS to encrypt the connection.
        // The SMTP session will begin on an unencrypted connection, and then the client
        // will issue a STARTTLS command to upgrade to an encrypted connection.
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.starttls.required", "true");

        // Create a Session object to represent a mail session with the specified properties.
        Session session;

        Transport transport = null;

        // Send the message.
        try {
            session = Session.getDefaultInstance(props);
            // Create a message with the specified information.
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(conf.getMailFrom()));
            msg.setRecipient(Message.RecipientType.TO, new InternetAddress(address));
            msg.setSubject(mailSubject, "UTF-8");
            msg.setContent(mailBody,"text/plain;charset=UTF-8");

            // Create a transport.
            transport = session.getTransport();

            // Connect to Amazon SES using the SMTP username and password you specified above.
            transport.connect(conf.getSmtpHost(), conf.getSmtpUser(), conf.getSmtpPassword());

            // Send the email.
            transport.sendMessage(msg, msg.getAllRecipients());
            classLogger.debug("Confirmation mail sent!");
            return true; // Success
        }
        catch (MessagingException ex) {
            classLogger.error("Confirmation email was not sent! address: " + address, ex);
            return false; // Failure
        }
        finally
        {
            if (transport != null) {
                try {
                    // Close and terminate the connection.
                    transport.close();
                } catch(Exception ex) {
                    classLogger.error("Error closing the mail transport.",ex);
                }
            }
        }
    }
}