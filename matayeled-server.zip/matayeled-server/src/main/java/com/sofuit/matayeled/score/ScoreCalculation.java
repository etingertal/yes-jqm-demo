package com.sofuit.matayeled.score;

import com.sofuit.matayeled.bet.BetService;
import com.sofuit.matayeled.game.Game;
import com.sofuit.matayeled.game.GameClient;
import com.sofuit.matayeled.game.GameService;
import com.sofuit.matayeled.group.GroupService;
import com.sofuit.matayeled.scorer.Scorer;
import com.sofuit.matayeled.stat.UserGroupStatsService;
import com.sofuit.matayeled.team.Team;
import com.sofuit.matayeled.user.UserRepo;
import com.sofuit.matayeled.user.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by osher on 14/6/16.
 */
@Service
public class ScoreCalculation {

    private static final Logger classLogger = LoggerFactory.getLogger(ScoreCalculation.class);

    @Autowired
    GameService gameService;

    @Autowired
    UserService userService;

    @Autowired
    BetService betService;

    @Autowired
    GroupService groupService;

    @Autowired
    UserGroupStatsService userGroupStatsService;

    @Autowired
    UserRepo userRepo;

    @Transactional
    public void updateAndCalc(List<GameClient> games) throws Exception {

        // Update games & get back the finished ones
        List<Game> finishedGames = gameService.updateGames(games);

        // Print whats updating.
        try {
            if (finishedGames != null) {
                for (Game currGame : finishedGames) {
                    classLogger.info("Game updated to finish - id: {}", currGame.getId());
                }
            }
        } catch (Exception e) {
            classLogger.error("Exception while printing updated games details. will continue as normal!", e);
        }

        if (finishedGames != null && finishedGames.size() > 0) {
            try {
                // Calc bets
                betService.updateBetsScores(finishedGames);

                // Update users scores
                userService.calcScore(finishedGames);

                // Update Top50
                userGroupStatsService.updateTop50();

                // Update groups leaders
                groupService.updateGroupsLeaders();
            } catch (Exception e) {
                // Write error
                gameService.updateGamesWithCalcError(finishedGames);
                throw e;
            }
            // Update games, calculation finished
            gameService.updateGameWithCalculationFinish(finishedGames);
        }
    }

    @Transactional
    public void updateWinningTeam(Team team) throws Exception {
        try {
            userService.updateFinalWinningTeam(team, team.getPoints());

            // Update Top50
            userGroupStatsService.updateTop50();

            // Update groups leaders
            groupService.updateGroupsLeaders();

        } catch (Exception e) {
            classLogger.error("Exception while printing updated games details. will continue as normal!", e);
        }
    }

    @Transactional
    public void updateTopScorer(Scorer scorer) throws Exception {
        try {
            userService.updateFinalTopScorer(scorer, scorer.getPoints());

            // Update Top50
            userGroupStatsService.updateTop50();

            // Update groups leaders
            groupService.updateGroupsLeaders();

        } catch (Exception e) {
            classLogger.error("Exception while printing updated games details. will continue as normal!", e);
        }
    }
}
