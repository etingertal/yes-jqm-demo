package com.sofuit.matayeled.exceptions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Created by osher on 9/4/16.
 */
@ControllerAdvice
class GlobalControllerExceptionHandler {

    private static final Logger classLogger = LoggerFactory.getLogger(GlobalControllerExceptionHandler.class);

    @ResponseStatus(HttpStatus.NOT_FOUND)  // 404
    @ExceptionHandler(ResourceNotFoundException.class)
    public void handleNotFound() {
        // TODO: get user and resourceto log
        classLogger.warn("User: {} tried to access nonexistent resource: {}", "user", "resource");
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)  // 400
    @ExceptionHandler(IllegalArgumentException.class)
    public void handleillegalArg() {
        // Get user and data to log
        classLogger.warn("User: {} sent invalid data to resource");
    }

    @ResponseStatus(HttpStatus.FORBIDDEN)  // 403
    @ExceptionHandler(ForbiddenException.class)
    public void handleForbidden() {
        // Get user and data to log
        classLogger.warn("User: {} tried doing forbidden action");
    }

    @ResponseStatus(HttpStatus.CONFLICT)  // 409
    @ExceptionHandler(ConflictException.class)
    public void handleConfilict() {
        // Get user and data to log
        classLogger.warn("User: {} got conflict");
    }
}