package com.sofuit.matayeled.admin;

import com.sofuit.matayeled.bet.Bet;
import com.sofuit.matayeled.bet.BetRepo;
import com.sofuit.matayeled.bet.BetService;
import com.sofuit.matayeled.config.IdentityService;
import com.sofuit.matayeled.exceptions.ForbiddenException;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.game.Game;
import com.sofuit.matayeled.game.GameRepo;
import com.sofuit.matayeled.game.GameService;
import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.group.GroupRepo;
import com.sofuit.matayeled.group.GroupService;
import com.sofuit.matayeled.score.ScoreCalculation;
import com.sofuit.matayeled.scorer.Scorer;
import com.sofuit.matayeled.scorer.ScorerRepo;
import com.sofuit.matayeled.scorer.ScorerService;
import com.sofuit.matayeled.stat.UserGroupStats;
import com.sofuit.matayeled.stat.UserGroupStatsRepo;
import com.sofuit.matayeled.stat.UserGroupStatsService;
import com.sofuit.matayeled.team.Team;
import com.sofuit.matayeled.team.TeamRepo;
import com.sofuit.matayeled.team.TeamService;
import com.sofuit.matayeled.tournament.TournamentRepo;
import com.sofuit.matayeled.user.*;
import com.sofuit.matayeled.utilities.Const;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Random;

/**
 * Created by etingertal on 6/7/16.
 */
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private static final Logger classLogger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    ScoreCalculation scoreCalculation;

    @Autowired
    UserRepo userRepo;

    @Autowired
    UserService userService;

    @Autowired
    BetRepo betRepo;

    @Autowired
    BetService betService;

    @Autowired
    GameRepo gameRepo;

    @Autowired
    GroupRepo groupRepo;

    @Autowired
    TeamRepo teamRepo;

    @Autowired
    TeamService teamService;

    @Autowired
    TournamentRepo tournamentRepo;

    @Autowired
    GameService gameService;

    @Autowired
    GroupService groupService;

    @Autowired
    UserGroupStatsService userGroupStatsService;

    @Autowired
    UserGroupStatsRepo userGroupStatsRepo;

    @Autowired
    UserScoreService userScoreService;

    @Autowired
    UserScoreRepo userScoreRepo;

    @Autowired
    ScorerRepo scorerRepo;

    @Autowired
    ScorerService scorerService;

    @RequestMapping(value = "/time", method = RequestMethod.GET)
    public ResponseEntity<String> getServerTime()
        throws ForbiddenException, ResourceNotFoundException {

        adminOrThrow();

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
        LocalDateTime localDateTime = LocalDateTime.now();

        return new ResponseEntity<>("{\"time\": \"" + dateTimeFormatter.format(localDateTime) + "\"}", HttpStatus.OK);
    }

    @RequestMapping(value = "/top50", method = RequestMethod.POST)
    public ResponseEntity<String> updateTop50()
        throws ResourceNotFoundException, ForbiddenException {

        adminOrThrow();

        User user = userService.findById(IdentityService.getUser());

        userGroupStatsService.updateTop50();

        return new ResponseEntity<>("{\"status\": \"ok\"}", HttpStatus.OK);
    }

    // Add bets so we can change them later to add some points for laters
    @RequestMapping(value = "/bets/init/{userId}", method = RequestMethod.POST)
    public ResponseEntity<String> initUserBetsForSpecificGames(@PathVariable("userId") String userId, @RequestBody List<String> gameIds)
            throws ResourceNotFoundException, ForbiddenException {
        adminOrThrow();

        User user = userService.findById(userId);
        int betCounter = 0;
        classLogger.info("Start Generate Bets for user: {}", user.getId());
        for (String gameId : gameIds) {

            if (user.getConfirmationId() == null) {

                Random rand = new Random();
                Game game = gameService.findById(gameId);
                Optional<Bet> bet = betService.findByUserAndGame(user, game);

                if (!bet.isPresent()) {
                    Bet currBet = new Bet();
                    currBet.setId(null);
                    currBet.setUser(user);
                    currBet.setGame(game);
                    currBet.setTeam1Score(rand.nextInt(5));
                    currBet.setTeam2Score(rand.nextInt(5));
                    currBet.setIsGenerated(Boolean.TRUE);
                    betRepo.save(currBet);
                    betCounter++;
                }
            }
        }

        UserScore userScore = userScoreService.findById(user.getId());

        if (userScore.getMissedGames() > betCounter) {
            userScore.setMissedGames(userScore.getMissedGames() - betCounter);
            userScoreRepo.save(userScore);
        }

        classLogger.info("Finished Generate Bets for user: {}", user.getId());

        return new ResponseEntity<>("ok", HttpStatus.OK);
    }

    // Generates bets for all registered users without (Must be run one-time before tournament)
    @RequestMapping(value = "/bets/generate", method = RequestMethod.POST)
    public ResponseEntity<String> initBetsForAllRegisteredUsers()
            throws ResourceNotFoundException, ForbiddenException {
        adminOrThrow();

        // Get all relevant users
        List<User> users = userRepo.findByConfirmationIdNotNull();

        int counter=0;
        for(User currUser : users) {
            List<Bet> bets = betRepo.findByUser(currUser);

            if (bets.size() == 0) {
                List<Game> games = gameRepo.findByStartTimeGreaterThanEqualOrderByStartTimeAsc(currUser.getRegistrationDate());
                classLogger.info("Starting Generate Bets for user: {}", counter);

                betService.tempBetGenerator(currUser, games);

                classLogger.info("Finished Generate Bets for user: {}", counter);

            } else {
                classLogger.info("user {} skipped", counter);
            }
            counter++;
        }

        classLogger.info("Generated Bets for {} users", counter);

        return new ResponseEntity<>("ok", HttpStatus.OK);
    }

    @Transactional
    @RequestMapping(value = "/user/bets/generateScorerAndWinningTeamBets", method = RequestMethod.POST)
    public ResponseEntity<String> generateScorerAndWinningTeamBets() throws ResourceNotFoundException, ForbiddenException {

        adminOrThrow();

        List<User> users = userService.findByTopScorerIsNullOrWinningTeamIsNull();
        classLogger.info("Got {} users to generate bets for.", users.size());

        List<Scorer> scorers = scorerService.getScorers();
        List<Team> teams = teamService.getTeams();

        for (User user : users) {

            // If user doesnt have winning team generate it.
            if(user.getWinningTeam() == null) {
                Team team = teams.get(new Random().nextInt(teams.size()));
                user.setWinningTeam(team);
                classLogger.info("Drawed win team for user: {}, team: {}", user.getFullName(), team.getName());
            }

            // If user doesnt have top scorer generate it.
            if(user.getTopScorer() == null) {
                Scorer scorer = scorers.get(new Random().nextInt(scorers.size()));
                user.setTopScorer(scorer);
                classLogger.info("Drawed scorer for user: {}, scorer: {}", user.getFullName(), scorer.getName());
            }

            userRepo.save(user);
        }
        classLogger.info("Finish scorere and team bets generating");
        return new ResponseEntity<>("ok", HttpStatus.OK);
    }

   /*@RequestMapping(value = "/user/bets/init", method = RequestMethod.POST)
    public ResponseEntity<String> generateScorerAndWinningTeamBets()
            throws ResourceNotFoundException, ForbiddenException {

        adminOrThrow();

        List<User> users = userService.getUsersWithoutFinalBetsButLocked();
        classLogger.info("Got {} users to generate bets.", users.size());

        int userCount = 1;
        for (User user : users) {
            classLogger.info("{}: Generate scorer and winning team to: {}.", userCount++, user.getId());

            // Get random scorer & winning team
            Random rand = new Random();
            // TODO: Change max
            int randScorer = rand.nextInt(36) + 1;

            Scorer scorer = new Scorer();
            scorer.setId("scorer" + ((randScorer < 10) ? "0" + randScorer : randScorer));

            // TODO: Change max
            int randTeam = rand.nextInt(32) + 1;

            Team team = new Team();
            team.setId("team" + randTeam);

            user.setTopScorer(scorer);
            user.setWinningTeam(team);
            userRepo.save(user);
            classLogger.info("Finished scorer and winning team to: {}.", user.getId());
        }

        return new ResponseEntity<>("ok", HttpStatus.OK);
    }*/

    // Before run:
    // Option 1 - Init bets for game without bets and check missedGames (only if needed) - when someone ask to add score
    // Option 2 - Change the relevant bet, and run - when someone ask to change mistake on his bet
    @RequestMapping(value = "/initAndRecalcUser/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> initAndRecalcUser(@PathVariable("userId") String userId)
            throws ResourceNotFoundException, ForbiddenException {

        adminOrThrow();

        try {
            // Init user
            User user = userService.findById(userId);
            UserScore userScore = userScoreService.findById(userId);
            userScore.setTotalBullsEye(0);
//            userScore.setHitsRatio(0.0);
            userScore.setTotalScore(0);
            userScore.setTotalHits(0);
            userScore = userScoreRepo.save(userScore);
//            User updatedUser = userRepo.save(user);

            // Init user bets
            List<Bet> userBets = betRepo.findByUser(user);
            for (Bet bet : userBets) {
                bet.setIsBullsEye(Boolean.FALSE);
                bet.setScore(0);
                betRepo.save(bet);
            }

            // Aggregators for current user
            Integer scoreKeeper = 0;
            Integer hitsCounter = 0;
            Integer bullseyeCounter = 0;

            List<Game> games = gameRepo.findByIsFinished(true);

            for (Game game : games) {

                Optional<Bet> optBet = betService.findByUserAndGame(user, game);
                Bet gameBet;
                if (optBet.isPresent()) {
                    gameBet = optBet.get();

                    if (gameBet.getScore() == 0) {
                        if (gameBet.getTeam1Score() == game.getTeam1Score() &&
                                gameBet.getTeam2Score() == game.getTeam2Score()) {

                            // Bullseye
                            gameBet.setScore(game.getBullseyeScore());
                            gameBet.setIsBullsEye(true);
                            scoreKeeper += game.getBullseyeScore();
                            bullseyeCounter++;
                            hitsCounter++;
                        } else if (((gameBet.getTeam1Score() - gameBet.getTeam2Score()) == 0 &&
                                (game.getTeam1Score() - game.getTeam2Score()) == 0)
                                || (((gameBet.getTeam1Score() - gameBet.getTeam2Score()) != 0 &&
                                (game.getTeam1Score() - game.getTeam2Score()) != 0) &&
                                ((gameBet.getTeam1Score() - gameBet.getTeam2Score()) < 0 ==
                                        ((game.getTeam1Score() - game.getTeam2Score()) < 0)))) {
                            // Hit
                            gameBet.setScore(game.getHitScore());
                            scoreKeeper += game.getHitScore();
                            hitsCounter++;
                        }

                        betService.save(gameBet);
                    }
                }
            }

            // Update user score
            userScore.setTotalBullsEye(userScore.getTotalBullsEye() + bullseyeCounter);
            userScore.setTotalScore(userScore.getTotalScore() + scoreKeeper);
            userScore.setTotalHits(userScore.getTotalHits() + hitsCounter);
            userRepo.save(user);

            // Recalc user reduces
            this.recalcUserReduce(user);

        } catch(Exception e) {
            classLogger.error("Error in score calc for user: {}", userId, e);
            throw e;
        }

        classLogger.info("Finished user score calculation for user: {}", userId);

        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    public ResponseEntity<Void> recalcUserReduce(User user) throws ResourceNotFoundException, ForbiddenException {

        adminOrThrow();

        classLogger.info("Reduce calculation started for user: {}", user.getId());

        try {

            List<Group> groups = user.getGroups();
            int counter = 0;

            for (Group group : groups) {

                if (!group.getPointsCalcFromTournamentStart()) {

                    Optional<UserGroupStats> userGroupStatsOp = userGroupStatsRepo.findByUserAndGroup(user, group);

                    if (userGroupStatsOp.isPresent()) {

                        UserGroupStats userGroupStats = userGroupStatsOp.get();

                        List<Bet> irrelevantBetsForUser = betService.getBetsByUserAndGameStartTimeLessThanEqual(
                                userGroupStats.getUser(),
                                userGroupStats.getGroup().getOpenDate());

                        if (irrelevantBetsForUser != null && irrelevantBetsForUser.size() > 0) {

                            int gameReduce = 0;
                            int scoreReduce = 0;
                            int hitsReduce = 0;
                            int bullsEyeReduce = 0;

                            for (Bet currBet : irrelevantBetsForUser) {
                                gameReduce += 1;
                                if (currBet.getScore() != 0) {
                                    scoreReduce += currBet.getScore();
                                    hitsReduce += 1;
                                    if (currBet.getIsBullsEye()) {
                                        bullsEyeReduce += 1;
                                    }
                                }
                            }

                            userGroupStats.setGameReduce(gameReduce);
                            userGroupStats.setScoreReduce(scoreReduce);
                            userGroupStats.setHitsReduce(hitsReduce);
                            userGroupStats.setBullseyeReduce(bullsEyeReduce);
                            userGroupStatsRepo.save(userGroupStats);

                            classLogger.info("done with: {}", ++counter);
                        }
                    }
                }
            }

            classLogger.info("Reduce calculation finished");
        } catch(Exception e) {
            classLogger.error("Error in recude calc for user: {}", user.getId(), e);
            throw e;
        }

        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    @RequestMapping(value = "/winningTeam/{teamId}", method = RequestMethod.POST)
    public ResponseEntity<Void> setFinalWinningTeam(@PathVariable("teamId") String teamId)
            throws Exception {

        adminOrThrow();

        Optional<Team> winner = teamRepo.findById(teamId);

        if (winner.isPresent()) {
            scoreCalculation.updateWinningTeam(winner.get());

        } else {
            throw new ResourceNotFoundException("no team with id: " + teamId);
        }

        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    @RequestMapping(value = "/topScorer/{scorerId}", method = RequestMethod.POST)
    public ResponseEntity<Void> setFinalTopScorer(@PathVariable("scorerId") String scorerId)
            throws Exception {

        adminOrThrow();

        Optional<Scorer> scorer = scorerRepo.findById(scorerId);

        if (scorer.isPresent()) {
            scoreCalculation.updateTopScorer(scorer.get());

        } else {
            throw new ResourceNotFoundException("no scorer with id: " + scorerId);
        }

        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    private void adminOrThrow() throws ResourceNotFoundException, ForbiddenException{

        User user = userService.findById(IdentityService.getUser());

        // Only admins allowed
        if (!(user.getRole() != null && user.getRole().equals(Const.ROLE_ADMIN))) {
            throw new ForbiddenException("Nono");
        }


    }
}
