package com.sofuit.matayeled.user;

import com.sofuit.matayeled.bet.Bet;
import com.sofuit.matayeled.bet.BetService;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.game.Game;
import com.sofuit.matayeled.game.GameRepo;
import com.sofuit.matayeled.game.GameService;
import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.model.LightUser;
import com.sofuit.matayeled.scorer.Scorer;
import com.sofuit.matayeled.team.Team;
import com.sofuit.matayeled.utilities.Const;
import com.sofuit.matayeled.utilities.MailSender;
import org.mindrot.jbcrypt.BCrypt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Created by etingertal on 4/10/16.
 */
@Service
public class UserService {

    private static final Logger classLogger = LoggerFactory.getLogger(UserService.class);

    @Autowired
    private UserScoreService userScoreService;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private MailSender mailSender;

    @Autowired
    private BetService betService;

    @Autowired
    private GameService gameService;

    @Autowired
    private GameRepo gameRepo;

    @PersistenceContext
    EntityManager entityManager;

    public User findById(String userId) throws ResourceNotFoundException {
        return userRepo.findById(userId).orElseThrow(() -> new ResourceNotFoundException("user id:" + userId));
    }

    public User findByEmail(String userMail) throws ResourceNotFoundException {
        return userRepo.findByEmail(userMail).orElseThrow(() -> new ResourceNotFoundException("user mail:" + userMail));
    }

    public User findByPhone(String phone) throws ResourceNotFoundException {
        return userRepo.findByPhone(phone).orElseThrow(() -> new ResourceNotFoundException("user phone:" + phone));
    }

    public User findByFacebookId(String facebookId) throws ResourceNotFoundException {
        return userRepo.findByFacebookId(facebookId).orElseThrow(() -> new ResourceNotFoundException("user FB id:" + facebookId));
    }

    public List<LightUser> findByFullName(String fullName) {
        List<LightUser> resUsers = new ArrayList<>();
        userRepo.findTop30ByFullNameLike("%" + fullName + "%").forEach(user -> resUsers.add(new LightUser(user)));

        return resUsers;
    }

    public User findByConfirmationId(String confirmationId) throws ResourceNotFoundException {
        return userRepo.findByConfirmationId(confirmationId).orElseThrow(() ->
                new ResourceNotFoundException("user confirmation:" + confirmationId));
    }

    public User findByResetPasswordId(String resetPasswordId) throws ResourceNotFoundException {
        return userRepo.findByResetPasswordId(resetPasswordId).orElseThrow(() ->
                new ResourceNotFoundException("user reset password id:" + resetPasswordId));
    }

    public Long getUserRank(String userId, int historyFinishedGamesCount) {
        return userRepo.getUserRank(userId, historyFinishedGamesCount);
    }

    public Long getTotalUsers() {
        return Long.valueOf(userRepo.count());
    }

    @Transactional
    public UserClient registerNewUser(UserClient userClient, boolean isFBUser)  throws ResourceNotFoundException {

        User newUser = userClient.convertToUser(null);

        // Hash a password for the first time
        String hashed = BCrypt.hashpw(userClient.getPassword(), BCrypt.gensalt());
        newUser.setPassword(hashed);

        // Set confirmation id
        if (isFBUser) {
            newUser.setConfirmationId(null);
        } else {
            newUser.setConfirmationId(UUID.randomUUID().toString());

            // Send confirmation mail
            this.sendConfirmationMail(newUser);
        }

        newUser = userRepo.save(newUser);

        // TODO: These 2 lines should be transacted with the user registration
        betService.initBetsForUser(newUser.getId());
        userScoreService.createUserScore(newUser.getId());

        return getUserClient(newUser);
    }

    public  User sendConfirmationMail(User user) {
        boolean mailSent = mailSender.sendConfirmationMail(user);

        if (!mailSent) {
            // Try one more time if failed.
            mailSent = mailSender.sendConfirmationMail(user);
        }

        if (!mailSent) {
            classLogger.warn("Registration mail failed 2 times to send for user: {} setting mail send to 0, it was: {}",
                    user.getEmail(), user.getMailsSentCount());
            user.setMailsSentCount(0);
        }else {
            user.setMailsSentCount(user.getMailsSentCount() + 1);
            user.setLastMailSent(new Timestamp(new Date().getTime()));
        }
        userRepo.save(user);
        return user;
    }

    @Transactional
    public User sendResetPasswordMail(User user) {

        // TODO: Part of the hack in resetPassword in AuthController
        // Set FB Id as null
        user.setFacebookId(null);

        user.setResetPasswordId(UUID.randomUUID().toString());

        // Send mail
        mailSender.sendResetPasswordMail(user);

        user.setLastResetPasswordSent(Timestamp.valueOf(LocalDateTime.now()));

        return userRepo.save(user);
    }

    @Transactional
    public UserClient updateUser(UserClient userClient) throws ResourceNotFoundException, IllegalArgumentException {

        // Get user (if it does not exist we will fly)
        User existingUser = this.findById(userClient.getId());
        if ((userClient.getFirstName() != null) && (!userClient.getFirstName().trim().isEmpty()))
            existingUser.setFirstName(userClient.getFirstName().trim());
        if ((userClient.getLastName() != null) && (!userClient.getLastName().trim().isEmpty()))
            existingUser.setLastName(userClient.getLastName().trim());
        // Update full name with the new or existing values
        existingUser.setFullName(existingUser.getFirstName().trim() + " " + existingUser.getLastName().trim());

        if ((userClient.getUserPic() != null) && (!userClient.getUserPic().isEmpty()))
            existingUser.setPic(userClient.getUserPic());
        if ((userClient.getPhone() != null) && (!userClient.getPhone().trim().isEmpty())) {
            existingUser.setPhone(userClient.getPhone().trim());
            classLogger.info("Update phone: " + userClient.getPhone().trim() + ", for user: " + userClient.getEmail());
        }

        //User newUser = userClient.convertToUser(existingUser);

        //TODO: handle password update..
        return getUserClient(userRepo.save(existingUser));
    }

    public List<Group> getUserGroups(User user, boolean filterPrivate) {
        List<Group> userGroups = user.getGroups();

        if (filterPrivate)
            userGroups.removeIf(g -> g.getPrivacy() == Const.GroupPrivacy.SECRET);

        return userGroups;
    }

    public boolean verifyUserPass(String userMail, String password) throws ResourceNotFoundException {
        User user = this.findByEmail(userMail);

        if (BCrypt.checkpw(password, user.getPassword())) {
            return true;
        } else {
            return false;
        }
    }

    public UserClient confirmUser(String confirmationId) throws ResourceNotFoundException {
        UserClient res = null;

        User user = this.findByConfirmationId(confirmationId);
        if (user.getConfirmationId() != null) {
            user.setConfirmationId(null);
            User temp = userRepo.save(user);
            res =  getUserClient(temp);
        }

        return res;
    }

    public User resetPassword(User user, String newPassword) throws ResourceNotFoundException {

        user.setResetPasswordId(null);

        // Hash a password for the first time
        String hashed = BCrypt.hashpw(newPassword, BCrypt.gensalt());
        user.setPassword(hashed);

        return userRepo.save(user);
    }

    public boolean isUserVerified(String userMail) throws ResourceNotFoundException {
        User user = this.findByEmail(userMail);

        if (user.getConfirmationId() == null) {
            return true;
        } else {
            return false;
        }
    }

    public List<User> getUsersWithoutFinalBetsButLocked() {

        List<User> users = new ArrayList<>();
        Pageable pageable = new PageRequest(0,1);
        Page<Game> lastGames =
                gameRepo.findByStartTimeLessThanEqualOrderByStartTimeDesc(Timestamp.valueOf(LocalDateTime.now()), pageable);

        if (lastGames.getSize() > 0) {
            Game lastGame = lastGames.getContent().get(0);
            users = userRepo.findByRegistrationDateLessThanAndTopScorerIsNullAndWinningTeamIsNull(lastGame.getStartTime());
        }

        return users;
    }

    public List<User> findByTopScorerIsNullOrWinningTeamIsNull() {

        return userRepo.findByTopScorerIsNullOrWinningTeamIsNull();
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public void calcScore(List<Game> games) throws Exception {

        classLogger.info("Starting user score calculation!");
        int counter=0;
        try {
            // Get all users
            Iterator<User> iterator = userRepo.findAll().iterator();

            while (iterator.hasNext()) {
                User currUser = iterator.next();

                // Aggregators for current user
                Integer scoreKeeper = 0;
                Integer hitsCounter = 0;
                Integer bullseyeCounter = 0;

                for (Game game : games) {
                    Optional<Bet> optBet = betService.findByUserAndGame(currUser, game);
                    if (optBet.isPresent()) {
                        Bet gameBet = optBet.get();

                        if (gameBet.getScore() != 0) {
                            scoreKeeper += gameBet.getScore();

                            if (gameBet.getIsBullsEye()) {
                                bullseyeCounter++;
                                hitsCounter++;
                            } else {
                                hitsCounter++;
                            }
                        }
                    }
                }

                // Update user score
                UserScore userScore = userScoreService.findById(currUser.getId());
                userScore.setTotalBullsEye(userScore.getTotalBullsEye() + bullseyeCounter);
                userScore.setTotalScore(userScore.getTotalScore() + scoreKeeper);
                userScore.setTotalHits(userScore.getTotalHits() + hitsCounter);
                userScoreService.save(userScore);
                counter++;
                if (counter % 500 == 0) {
                    entityManager.flush();
                    entityManager.clear();
                    classLogger.info("Finished: {} users!", counter);
                }
            }
        } catch(Exception e) {
            classLogger.error("Error in user score calculation:", e);
            throw e;
        }

        classLogger.info("Finished user score calculation.");
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public void updateFinalWinningTeam(Team team, Integer teamPoints) throws Exception {

        classLogger.info("Starting final winning team update!");
        int counter=0;
        try {
            // Get all users
            List<User> users = userRepo.findByWinningTeam(team);

            for (User currUser : users) {

                // Update user score
                UserScore userScore = userScoreService.findById(currUser.getId());
                userScore.setTotalScore(userScore.getTotalScore() + teamPoints);
                userScoreService.save(userScore);
                counter++;
                if (counter % 500 == 0) {
                    entityManager.flush();
                    entityManager.clear();
                    classLogger.info("Finished: {} users!", counter);
                }
            }
        } catch(Exception e) {
            classLogger.error("Error in final winning team update:", e);
            throw e;
        }

        classLogger.info("Finished final winning team update.");
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public void updateFinalTopScorer(Scorer scorer, Integer scorerPoints) throws Exception {

        classLogger.info("Starting final top scorer update!");
        int counter=0;
        try {
            // Get all users
            List<User> users = userRepo.findByTopScorer(scorer);

            for (User currUser : users) {

                // Update user score
                UserScore userScore = userScoreService.findById(currUser.getId());
                userScore.setTotalScore(userScore.getTotalScore() + scorerPoints);
                userScoreService.save(userScore);
                counter++;
                if (counter % 500 == 0) {
                    entityManager.flush();
                    entityManager.clear();
                    classLogger.info("Finished: {} users!", counter);
                }
            }
        } catch(Exception e) {
            classLogger.error("Error in final top scorer update:", e);
            throw e;
        }

        classLogger.info("Finished final top scorer update.");
    }

    public UserClient getUserClient(User user) throws ResourceNotFoundException{
        return new UserClient(user, userScoreService.findById(user.getId()));
    }

//    public void deleteUnconfirmedAccounts(Integer days) {
//        userRepo.deleteUnconfirmedAccounts(days);
//    }
}
