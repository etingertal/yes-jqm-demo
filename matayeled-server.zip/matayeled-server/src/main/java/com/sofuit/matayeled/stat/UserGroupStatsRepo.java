package com.sofuit.matayeled.stat;

import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.user.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

/**
 * Created by osher on 16/4/16.
 */
public interface UserGroupStatsRepo extends PagingAndSortingRepository<UserGroupStats, String> {

    Optional<UserGroupStats> findByUserAndGroup(User user, Group group);
    Long deleteByGroup(Group group);

    @Query( value = "select gs.id,gs.user,gs.group,(us.totalScore-gs.scoreReduce) AS calcedScore, (((us.totalHits-gs.hitsReduce)/(:historyGameCount-(us.missedGames+gs.gameReduce)))*100) AS calcedHitsRatio, (us.totalBullsEye-gs.bullseyeReduce) AS calcedBullseye from UserGroupStats AS gs, UserScore AS us where gs.user.id = us.id and gs.group=:group order by calcedScore desc, calcedHitsRatio desc, calcedBullseye desc",
            countQuery = "select count(gs.id) from UserGroupStats AS gs, UserScore AS us where gs.user.id = us.id and gs.group=:group and  -1 <> :historyGameCount")
    Page<Object[]> getOrderedGroupStats(@Param("group") Group group, @Param("historyGameCount") int historyGameCount, Pageable page);
}
