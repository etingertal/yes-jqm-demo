package com.sofuit.matayeled.model;

import lombok.Data;

/**
 * Created by etingertal on 4/28/16.
 */
@Data
public class UserLogin {

    private String userMail;
    private String password;
}
