package com.sofuit.matayeled.group;

import com.sofuit.matayeled.config.IdentityService;
import com.sofuit.matayeled.exceptions.ForbiddenException;
import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.model.LightUser;
import com.sofuit.matayeled.stat.UserGroupStatsClient;
import com.sofuit.matayeled.utilities.Const;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/api/groups")
public class GroupController {

    private static final Logger classLogger = LoggerFactory.getLogger(GroupController.class);

    @Autowired
    GroupService groupService;

    // Get my groups
    @RequestMapping(value = "", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<GroupClient>> getMyGroup() throws ResourceNotFoundException {
        classLogger.trace("User: {} is fetching his groups", IdentityService.getUser());
        List<GroupClient> myGroups = groupService.getUserGroups(IdentityService.getUser());

        GroupClient top50 = new GroupClient(groupService.findById(Const.TOP_50_GROUP_ID));
        if (!myGroups.contains(top50))
            myGroups.add(0, top50);

        return new ResponseEntity<>(myGroups, HttpStatus.OK);
    }

    // Get public groups
    @RequestMapping(value = "/public", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<GroupClient>> getPublicGroups(@RequestParam int page, @RequestParam String name) throws ResourceNotFoundException {
        classLogger.trace("User: {} is fetching public groups", IdentityService.getUser());
        Pageable pageable = new PageRequest(page,Const.GROUPS_PER_PAGE, new Sort("openDate"));
        return new ResponseEntity<>(groupService.getPublicGroups(pageable, name), HttpStatus.OK);
    }

    // Get specific group
    @RequestMapping(value = "/{groupId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GroupClient> getGroup(@PathVariable("groupId") String groupId) throws ResourceNotFoundException {
        classLogger.trace("User: {} is fetching group with id: {}", IdentityService.getUser(), groupId);
        if (groupService.isUserInGroup(IdentityService.getUser(), groupId) || !groupService.isGroupSecret(groupId)) {
            GroupClient groupClient = groupService.getGroupClient(groupId);
            return new ResponseEntity<>(groupClient, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
    }

    // am I in group
    @RequestMapping(value = "/{groupId}/friends/{userId}", method = RequestMethod.GET)
    public ResponseEntity<Boolean> amIInGroup(@PathVariable String groupId) throws ResourceNotFoundException {

        return new ResponseEntity<>(groupService.isUserInGroup(IdentityService.getUser(), groupId), HttpStatus.OK);
    }

    // Create new group
    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<GroupClient> createGroup(@RequestBody GroupClient group,
                                            UriComponentsBuilder ucBuilder) throws  ResourceNotFoundException,
                                                                                    ForbiddenException {
        classLogger.trace("Creating new group for user: {} with name: {}", IdentityService.getUser(), group.getName());

        // Prevent injections
        group.setId(null); // When creating new group id must be null
        validateClientGroup(group);

        // Create group
        GroupClient groupClient = groupService.createGroup( group,
                                                            IdentityService.getUser());

        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/group/{id}").buildAndExpand(groupClient.getId()).toUri());
        return new ResponseEntity<>(groupClient, headers, HttpStatus.CREATED);
    }

    // Update group
    @RequestMapping(value = "/{groupId}", method = RequestMethod.PUT)
    public ResponseEntity<GroupClient> updateGroup(@PathVariable("groupId") String groupId,
                                                   @RequestBody GroupClient groupClient)
            throws ResourceNotFoundException, ForbiddenException {
        classLogger.trace("User: {} is updating group: {}", IdentityService.getUser(), groupId);

        if (!groupId.equals(groupClient.getId())) {
            classLogger.warn(Const.securityMarker, "User: {} is messing with id's, path groupId: {} object groupId: {}",
                    new Object[] { IdentityService.getUser(), groupId, groupClient.getId() });
            throw new IllegalArgumentException("Id's miss match");
        }

        if (groupId.equals(Const.TOP_50_GROUP_ID)) {
            classLogger.warn(Const.securityMarker, "User: {} is trying to update group: {}",
                    IdentityService.getUser(), groupId );
            throw new IllegalArgumentException("User is trying to update group");
        }

        // If public group only admin can edit anything!
        if (groupService.isGroupPublic(groupId)) {
            isAdminOrThrow(groupId);
        } else {
            // For non public group some fields are editable by any member.
            isUserInGroupOrThrow(groupId);
        }

        validateClientGroup(groupClient);

        if (groupService.isAdmin(IdentityService.getUser(), groupId)) {
            groupClient = groupService.updateGroup(groupClient, IdentityService.getUser());
        } else {
            groupClient = groupService.updateGroupPublicFields(groupClient);
        }

        return new ResponseEntity<>(groupClient, HttpStatus.OK);
    }

    // Update group leader status
    @RequestMapping(value = "/{groupId}", method = RequestMethod.PATCH)
    public ResponseEntity<GroupClient> setLeaderStatus(@PathVariable("groupId") String groupId,
                                                   @RequestBody String leaderStatus)
            throws ResourceNotFoundException, ForbiddenException {
        classLogger.trace("User: {} is updating group leader status: {}", IdentityService.getUser(), groupId);

        this.isUserGroupLeaderOrThrow(groupId);

        if (leaderStatus.length() > Const.MAX_LEADER_STATUS_LENGTH) {
            classLogger.warn(Const.securityMarker, "User: {} tried to set to long leader status",
                    new Object[] { IdentityService.getUser() });
            throw new ForbiddenException("User tried to set to long staus");
        }

        GroupClient groupClient = groupService.updateGroupStatus(groupId, leaderStatus);
        return new ResponseEntity<>(groupClient, HttpStatus.OK);
    }

    // Get specific group stats
    @RequestMapping(value = "/{groupId}/stats", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<UserGroupStatsClient>> getGroupUserStats(@PathVariable("groupId") String groupId, @RequestParam int page)
            throws ResourceNotFoundException {
        classLogger.trace("User: {} is fetching group with stats for group id: {}", IdentityService.getUser(), groupId);
        Pageable pageable = new PageRequest(page,Const.USERS_PER_PAGE);
        return new ResponseEntity<>(groupService.getGroupStats(pageable, groupId), HttpStatus.OK);
    }

    // Get specific group users
    @RequestMapping(value = "/{groupId}/users", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<LightUser>> getGroupUsers(@PathVariable("groupId") String groupId)
            throws ResourceNotFoundException {

        List<LightUser> users = new ArrayList<>();
        classLogger.trace("User: {} is fetching group users for group id: {}", IdentityService.getUser(), groupId);

        Group group = groupService.findById(groupId);
        group.getUsers().forEach(u -> users.add(new LightUser(u)));
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    // Add users to group
    @RequestMapping(value = "/{groupId}/friends", method = RequestMethod.POST)
    public ResponseEntity<GroupClient> addGroupFriends( @PathVariable("groupId") String groupId,
                                                        @RequestBody String[] users)
            throws   ResourceNotFoundException, ForbiddenException {

        classLogger.trace("User: {} is adding users to group: {}", IdentityService.getUser(), groupId);

        // If user in not joining a public group, then he adds users to a group hes in, so he
        // must be a memeber in that group
        if (!(groupService.isGroupPublic(groupId) && users != null && users.length == 1 &&
                users[0].toString().equals(IdentityService.getUser()))) {
            this.isUserInGroupOrThrow(groupId);
        }

        if (users.length > Const.MAX_USERS_PER_REQUEST) {
            classLogger.warn(Const.securityMarker, "User: {} tried to add more then allowed: {} users in request, for group: {}",
                    new Object[] { IdentityService.getUser(), Const.MAX_USERS_PER_REQUEST, groupId });
            throw new ForbiddenException("User tried to add too many users in one request.");
        }

        GroupClient groupClient = groupService.addUsersToGroup(groupId, users);

        return new ResponseEntity<>(groupClient, HttpStatus.OK);
    }

    // Remove users from group
    @RequestMapping(value = "/{groupId}/friends", method = RequestMethod.DELETE)
    public ResponseEntity<GroupClient> removeGroupFriends(@PathVariable("groupId") String groupId,
                                                          @RequestBody String[] users)
            throws   ResourceNotFoundException, ForbiddenException {

        classLogger.trace("User: {} is removing users from group: {}", IdentityService.getUser(), groupId);

        if (users.length > Const.MAX_USERS_PER_REQUEST) {
            classLogger.warn(Const.securityMarker, "User: {} tried to remove more then allowed: {} users in request, for group: {}",
                    new Object[] { IdentityService.getUser(), Const.MAX_USERS_PER_REQUEST, groupId });
            throw new ForbiddenException("User tried to remove too many users from group.");
        }

        // For leaving the group i don't need to be admin, if i remove someone else
        // i must be an admin
        if (!(users != null && users.length == 1 && users[0].toString().equals(IdentityService.getUser()))) {
            this.isAdminOrThrow(groupId);
        }

        GroupClient groupClient = groupService.removeUsersFromGroup(groupId, users);

        // If only monkey left, delete group
        if (groupService.getGroupSize(groupId) == 1) {
            groupService.deleteGroup(groupId);
            groupClient = null;
        }

        return new ResponseEntity<>(groupClient, HttpStatus.OK);
    }

    private void validateClientGroup(GroupClient groupClient) throws IllegalArgumentException {
        String picStartWith = "data:image/jpeg;base64,";
        String leagleBase64 = "[A-Za-z0-9+/=]*";

        if (groupClient.getName() == null || groupClient.getName().isEmpty()) {
            classLogger.warn(Const.securityMarker, "User: {} sent a group with empty name", IdentityService.getUser());
            throw new IllegalArgumentException("Group with empty name");
        } else if  (groupClient.getName().length() > Const.MAX_GROUP_NAME_LENGTH) {
            classLogger.warn(Const.securityMarker, "User: {} sent a group with too long name", IdentityService.getUser());
            throw new IllegalArgumentException("Group with too long name");
        }

        String pic = groupClient.getPic();
        if(pic != null && !pic.isEmpty()) {
            if (!pic.startsWith(picStartWith) ||
                !pic.substring(picStartWith.length(), pic.length()).matches(leagleBase64)) {
                classLogger.warn(Const.securityMarker, "User: {} sent a group with non base64 pic: {}",
                        IdentityService.getUser(), groupClient.getPic());
                throw new IllegalArgumentException("Group pic nad request");
            }
        }
    }

    private void isAdminOrThrow(String groupId) throws ResourceNotFoundException, ForbiddenException {
        if (!groupService.isAdmin(IdentityService.getUser(), groupId)) {
            classLogger.warn(Const.securityMarker, "User: {} is trying to change group he is not admin in, id: {}",
                    IdentityService.getUser(), groupId);
            throw new ForbiddenException("User is trying to change group he is not admin at.");
        }
    }

    private void isUserInGroupOrThrow(String groupId) throws ResourceNotFoundException, ForbiddenException {
        if (!groupService.isUserInGroup(IdentityService.getUser(), groupId)) {
            classLogger.warn(Const.securityMarker, "User: {} is trying to change group he is not a member in, id: {}",
                    IdentityService.getUser(), groupId);
            throw new ForbiddenException("User is trying to change group he is not a member in.");
        }
    }

    private void isUserGroupLeaderOrThrow(String groupId) throws ResourceNotFoundException, ForbiddenException {
        if (!groupService.isLeader(IdentityService.getUser(), groupId)) {
            classLogger.warn(Const.securityMarker, "User: {} is not the leader but trying to change leader status for group id: {}",
                    IdentityService.getUser(), groupId);
            throw new ForbiddenException("User is not the leader but trying to change group leader status.");
        }
    }
}
