package com.sofuit.matayeled.ad;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by etingertal on 6/17/16.
 */
@Data
@NoArgsConstructor
public class AdClient {

    private String id;

    private String pic;

    private String type;

    private String url;

    public AdClient(Ad ad) {
        if (ad != null) {
            this.setId(ad.getId());
            this.setPic(ad.getPic());
            this.setType(ad.getType());
        }
    }
}
