package com.sofuit.matayeled.exceptions;

/**
 * Created by etingertal on 5/7/16.
 */
public class ConflictException extends Exception {
    public ConflictException(String message) {
        super(message);
    }
}
