package com.sofuit.matayeled.stat;

import com.sofuit.matayeled.group.Group;
import com.sofuit.matayeled.scorer.Scorer;
import com.sofuit.matayeled.team.Team;
import com.sofuit.matayeled.user.User;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by osher on 16/4/16.
 */
@Data
@NoArgsConstructor
public class UserGroupStatsClient {

    private String id;
    private String userId;
    private String userFirstName;
    private String userLastName;
    private String userPic;
    private String groupId;
    private Integer score = 0;
    private Integer bullseye = 0;
    private Double hitsRatio = 0.0;
    private String topScorerPic = null;
    private String winningTeamPic = null;
    private Integer rank = null;

    public UserGroupStatsClient(Object[] stateAsObj, boolean withBets) {

        User user = (User)stateAsObj[1];
        Group group = (Group)stateAsObj[2];

        this.id = (String)stateAsObj[0];
        this.userId = user.getId();
        this.userFirstName = user.getFirstName();
        this.userLastName = user.getLastName();
        this.userPic = user.getPic();
        if (withBets) {
            Scorer userScorer = user.getTopScorer();
            this.topScorerPic = userScorer == null ? null : userScorer.getPicUrl();
            Team userWinTeam = user.getWinningTeam();
            this.winningTeamPic = userWinTeam == null ? null : userWinTeam.getPic();
        }
        this.groupId = group.getId();
        this.score = (Integer)stateAsObj[3];
        if (stateAsObj[4] != null) {
            this.hitsRatio = Double.parseDouble(stateAsObj[4].toString());
        } else {
            this.hitsRatio = 0.0;
        }
        this.bullseye = (Integer)stateAsObj[5];
    }
}
