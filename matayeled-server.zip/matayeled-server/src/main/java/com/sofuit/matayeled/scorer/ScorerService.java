package com.sofuit.matayeled.scorer;

import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by etingertal on 5/9/16.
 */
@Service
public class ScorerService {

    @Autowired
    ScorerRepo scorerRepo;

    public Scorer findById(String scorerId) throws ResourceNotFoundException {
        return scorerRepo.findById(scorerId).orElseThrow(() -> new ResourceNotFoundException("scorer id:" + scorerId));
    }

    public List<Scorer> getScorers() {
        List<Scorer> scorers = new ArrayList<>();
        scorerRepo.findAll().forEach(scorers::add);
        return scorers;
    }
}
