package com.sofuit.matayeled.utilities;

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;

/**
 * Created by osher on 9/4/16.
 */
public class Const {

    public static final Marker securityMarker = MarkerFactory.getMarker("SECURITY");

    public static final int MAX_USERS_PER_REQUEST = 200;

    public static final String MONKEY_USER_ID = "monkey";

    public static final String ROLE_ADMIN = "ADMIN";

    public static final int MAX_LEADER_STATUS_LENGTH = 25;

    public static final int MAX_GROUP_NAME_LENGTH = 25;

    public static final int DAYS_TO_CONFIRM_ACCOUNT = 2;

    public static final int GROUPS_PER_PAGE = 20;

    public static final String PROMOS_TYPE = "PROMO";

    public static final int USERS_PER_PAGE = 20;

    public static final String TOP_50_GROUP_ID = "top50";

    public enum GroupPrivacy {
        SECRET, VIEWABLE, PUBLIC;
    }

    public enum GameCalcStatus {
        CALCULATING, CALCULATION_FINISHED, CALCULATION_ERROR;
    }
}
