package com.sofuit.matayeled.bet;

import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.game.Game;
import com.sofuit.matayeled.game.GameService;
import com.sofuit.matayeled.user.User;
import com.sofuit.matayeled.user.UserClient;
import com.sofuit.matayeled.user.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.Random;

/**
 * Created by etingertal on 4/12/16.
 */
@Service
public class BetService {

    private static final Logger classLogger = LoggerFactory.getLogger(BetService.class);

    @Autowired
    UserService userService;

    @Autowired
    BetRepo betRepo;

    @Autowired
    GameService gameService;

    @PersistenceContext
    EntityManager entityManager;

    public Optional<Bet> findByUserAndGame(User user, Game game) {
        return betRepo.findByUserAndGame(user, game);
    }

    public List<Bet> findByUser(User user) {
        return betRepo.findByUser(user);
    }

    // Create or update the bets (Scenario: User insert new bets or change existing bets)
    public BetClient updateBet(BetClient betClient, Game game, User user) {

        Optional<Bet> existingBet = betRepo.findByUserAndGame(user, game);

        // Create new bet for this user and game
        Bet betToUpdate = null;
        if (existingBet.isPresent()) {
            // Update existing bet for this user and game
            betToUpdate = existingBet.get();
            betToUpdate.setTeam1Score(betClient.getTeam1Score());
            betToUpdate.setTeam2Score(betClient.getTeam2Score());
        } else {
            betToUpdate = betClient.convertToBet(game, user);
            betToUpdate.setId(null);
        }

        // Mark bet as user bet and not generated
        betToUpdate.setIsGenerated(Boolean.FALSE);

        return new BetClient(betRepo.save(betToUpdate));
    }

    @Transactional
    public int initBetsForUser(String id) throws ResourceNotFoundException {
        int counter = 0;
        Random rand = new Random();

        // Convert to user and keep id
        User user = userService.findById(id);

        List<Bet> bets = betRepo.findByUser(user);

        if (bets.size() == 0) {
            List<Game> nextGames = gameService.getNextGames();

            for (Game nextGame : nextGames) {
                Bet currBet = new Bet();
                currBet.setId(null);
                currBet.setUser(user);
                currBet.setGame(nextGame);
                currBet.setTeam1Score(rand.nextInt(5));
                currBet.setTeam2Score(rand.nextInt(5));
                currBet.setIsGenerated(Boolean.TRUE);
                betRepo.save(currBet);
                counter++;
            }
        }

        return counter;
    }

    // TODO: DELETE!!!
    @Transactional(propagation = Propagation.REQUIRED)
    public void tempBetGenerator(User currUser, List<Game> nextGames) {
        // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        //   THIS FUNC COUNT THAT YOU CHECK THE BETS IS EMPTY FOR USER!!!!
        // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        Random rand = new Random();
            for (Game nextGame : nextGames) {
                Bet currBet = new Bet();
                currBet.setId(null);
                currBet.setUser(currUser);
                currBet.setGame(nextGame);
                currBet.setTeam1Score(rand.nextInt(5));
                currBet.setTeam2Score(rand.nextInt(5));
                currBet.setIsGenerated(Boolean.TRUE);
                betRepo.save(currBet);
            }

            entityManager.flush();
            entityManager.clear();
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateBetsScores(List<Game> games) {

        classLogger.info("Starting game bets calculation!");
        try {

            for (Game currGame : games) {
                List<Bet> bets = betRepo.findByGame(currGame);

                if (!currGame.getIsBetsCalculated()) {
                    for (Bet currBet : bets) {
                        if (currBet.getScore() == 0) {
                            boolean betChanged = false;
                            if (currBet.getTeam1Score() == currGame.getTeam1Score() &&
                                    currBet.getTeam2Score() == currGame.getTeam2Score()) {

                                // Bullseye
                                currBet.setScore(currGame.getBullseyeScore());
                                currBet.setIsBullsEye(true);
                                betChanged = true;
                            } else if (((currBet.getTeam1Score() - currBet.getTeam2Score()) == 0 &&
                                    (currGame.getTeam1Score() - currGame.getTeam2Score()) == 0)
                                    || (((currBet.getTeam1Score() - currBet.getTeam2Score()) != 0 &&
                                    (currGame.getTeam1Score() - currGame.getTeam2Score()) != 0) &&
                                    ((currBet.getTeam1Score() - currBet.getTeam2Score()) < 0 ==
                                            ((currGame.getTeam1Score() - currGame.getTeam2Score()) < 0)))) {
                                // Hit
                                currBet.setScore(currGame.getHitScore());
                                betChanged = true;
                            }

                            if (betChanged) {
                                betRepo.save(currBet);
                            }
                        }
                    }
                    gameService.updateGameWithBetCalculated(currGame);
                }
            }
        } catch (Exception e) {
            classLogger.error("Error while calcing game bets: ", e);
            throw e;
        }

        classLogger.info("Finished game bets calculation!");
    }

    public List<Bet> getBetsByUserAndGameStartTimeLessThanEqual(User user, Timestamp time) {
        return betRepo.findBetsByUserAndGameStartTimeLessThanEqual(user, time);
    }

    public Bet save(Bet bet) {
        return betRepo.save(bet);
    }
}
