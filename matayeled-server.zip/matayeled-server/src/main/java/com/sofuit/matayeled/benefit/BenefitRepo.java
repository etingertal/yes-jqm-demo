package com.sofuit.matayeled.benefit;

import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface BenefitRepo extends CrudRepository<Benefit, String> {

    Optional<Benefit> findById(String id);
}
