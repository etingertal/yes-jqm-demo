package com.sofuit.matayeled.config;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by osher on 23/4/16.
 */
@Component
public class JwtFilter extends GenericFilterBean {

    private final Logger classLogger = LoggerFactory.getLogger(JwtFilter.class);

    private static Boolean injectTestUser = null;

    private static String securityKey = null;

    @Override
    public void doFilter(final ServletRequest req, final ServletResponse res, final FilterChain chain)
            throws IOException, IllegalArgumentException, ServletException {

        final HttpServletRequest request = (HttpServletRequest) req;

        // Because we are in a GenericFilterBean we can't use @Autowired for configuration (we are not
        // in any spring context) so we need to bring configurations this way (1 time after app starts)
        if (securityKey == null) {
            classLogger.debug("Initializing configurations for JwtFilter");
            ServletContext servletContext = request.getServletContext();
            WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
            Environment env = webApplicationContext.getEnvironment();

            // Set securityKey
            securityKey = env.getProperty("matayeled.securityKey");

            // Set injectTestUser
            if (env.getProperty("SITE_URL") != null &&
                    (env.getProperty("SITE_URL").contains("localhost") ||
                            env.getProperty("SITE_URL").contains("127.0.0.1"))) {
                injectTestUser = true;
            } else {
                injectTestUser = false;
            }
        }

        final String authHeader = request.getHeader("Authorization");

        // Case header doesn't look like  jwt token.
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            // If injectTestUser is true, set default user.
            if (injectTestUser) {
                classLogger.warn("We are at injectTestUser mode! user will be set to default if no token was sent by client!");
                IdentityService.setUser("user1");
            } else {
                // If not injectTestUser and no auth header send UNAUTHORIZED response.
                HttpServletResponse response = (HttpServletResponse) res;
                response.sendError(HttpStatus.UNAUTHORIZED.value());
                return;
            }
        } else {
            final String token = authHeader.substring(7); // The part after "Bearer "

            try {
                // Try and get the user from token
                final String userId = Jwts.parser().setSigningKey(securityKey).parseClaimsJws(token).getBody().getSubject();
                final Object fbAccessToken = Jwts.parser().setSigningKey(securityKey).parseClaimsJws(token).getBody().get("fbAccessToken");
                IdentityService.setUser(userId);

                if (fbAccessToken != null)
                    FBAccessTokenService.setFBAccessToken(fbAccessToken.toString());

            } catch (final SignatureException e) {
                throw new IllegalArgumentException("Invalid token.");
            }
        }
        chain.doFilter(req, res);
    }

    @Override
    public void destroy() {
        IdentityService.removeUser();
    }

}

