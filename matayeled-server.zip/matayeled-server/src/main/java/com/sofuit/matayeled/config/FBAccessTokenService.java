package com.sofuit.matayeled.config;

/**
 * Created by etingertal on 4/30/16.
 */
public class FBAccessTokenService {

    private static final ThreadLocal<String> FB_ACCESS_TOKEN = new ThreadLocal<String>() {
        @Override
        protected String initialValue() {
            return "empty";
        }
    };

    public static void setFBAccessToken(String subject) {
        FB_ACCESS_TOKEN.set(subject);
    }

    public static String getFBAccessToken() {
        return FB_ACCESS_TOKEN.get();
    }

    public static void removeFBAccessToken() {
        FB_ACCESS_TOKEN.remove();
    }
}
