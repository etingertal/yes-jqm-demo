package com.sofuit.matayeled.statistics;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.sofuit.matayeled.game.Game;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class GameStats {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @OneToOne(fetch = FetchType.LAZY)
    private Game game;

    Integer totalBets;

    Integer team1BetsCount;

    Integer team2BetsCount;

    Integer totalBullsEyes;

    private Timestamp updateTime;
}
