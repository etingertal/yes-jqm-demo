package com.sofuit.matayeled.game;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.sofuit.matayeled.team.Team;
import com.sofuit.matayeled.tournament.Tournament;
import com.sofuit.matayeled.utilities.Const;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by etingertal on 4/7/16.
 */
@Entity
@Data
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Game {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    private Team team1;

    @ManyToOne(fetch = FetchType.LAZY)
    private Team team2;

    private Integer hitScore = 0;

    private Integer bullseyeScore = 0;

    private Timestamp startTime;

    private Integer team1Score = 0;

    private Integer team2Score = 0;

    private String stageName;

    private Boolean isLocking = false;

    private Boolean isFinished = false;

    private Boolean isBetsCalculated = false;

    private Const.GameCalcStatus gameCalcStatus = Const.GameCalcStatus.CALCULATING;

    @ManyToOne(fetch = FetchType.LAZY)
    private Tournament tournament;
}
