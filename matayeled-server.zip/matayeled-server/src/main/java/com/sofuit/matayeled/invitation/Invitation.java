package com.sofuit.matayeled.invitation;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.sofuit.matayeled.group.Group;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Created by etingertal on 4/24/16.
 */
@Entity
@Data
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Invitation {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    private String link;

    @ManyToOne(fetch = FetchType.LAZY)
    private Group assignedGroup; // If null then it should be invitation to register the game generally

    private Integer clicksCounter = 0;
}
