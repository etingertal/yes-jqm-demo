package com.sofuit.matayeled.user;

import com.sofuit.matayeled.exceptions.ResourceNotFoundException;
import com.sofuit.matayeled.game.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by osher on 18/6/16.
 */
@Service
public class UserScoreService {

    @Autowired
    UserScoreRepo userScoreRepo;

    @Autowired
    GameService gameService;

    public UserScore findById(String userId) throws ResourceNotFoundException {
        return userScoreRepo.findById(userId).orElseThrow(() -> new ResourceNotFoundException("userScore id:" + userId));
    }

    @Transactional
    public UserScore createUserScore(String id) {

        // Set missed game count
        Integer count = gameService.getHistoryGamesCount();

        UserScore uscore = new UserScore();
        uscore.setId(id);
        uscore.setTotalBullsEye(0);
        uscore.setTotalHits(0);
        uscore.setTotalScore(0);
        uscore.setMissedGames(count);
        return userScoreRepo.save(uscore);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public UserScore save(UserScore uscore) {
        return userScoreRepo.save(uscore);
    }
}
